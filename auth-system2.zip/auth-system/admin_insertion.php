<?php
// Include database connection
require 'db.php';  // Ensure db.php has the correct PDO connection to your database

// Define admin account details
$username = 'admin'; // Username for the admin
$password = 'adminpassword'; // Plain text password (it will be hashed)
$email = 'admin@example.com'; // Admin email
$role = 'admin'; // Set the role as admin
$department = 'IT'; // Department for the admin
$jobRole = 'System Administrator'; // Job role for the admin
$approved = 1;  // Admin is automatically approved

// Hash the password using bcrypt
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);

// Check if the admin account exists
$stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
$stmt->execute(['username' => $username]);

$message = "";
$redirect = false;

if ($stmt->rowCount() > 0) {
    // Admin account exists, update it
    $stmt = $pdo->prepare("UPDATE users SET password = :password, email = :email, role = :role, 
                          department = :department, job_role = :job_role, approved = :approved 
                          WHERE username = :username");
    $stmt->execute([
        'password' => $hashedPassword,
        'email' => $email,
        'role' => $role,
        'department' => $department,
        'job_role' => $jobRole,
        'approved' => $approved,
        'username' => $username
    ]);
    $message = "Admin account updated successfully!";
    $redirect = true;
} else {
    // Admin account does not exist, insert it
    $stmt = $pdo->prepare("INSERT INTO users (username, password, email, role, department, job_role, approved) 
                          VALUES (:username, :password, :email, :role, :department, :job_role, :approved)");
    $stmt->execute([
        'username' => $username,
        'password' => $hashedPassword,
        'email' => $email,
        'role' => $role,
        'department' => $department,
        'job_role' => $jobRole,
        'approved' => $approved
    ]);
    $message = "Admin account created successfully!";
    $redirect = true;
}

// Redirect to login page immediately after execution
header('Location: login.php');
exit();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Setup - Bradford Council</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #004A87; /* Bradford Council blue */
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            width: 100%;
            text-align: center;
        }
        h1 {
            color: #004A87; /* Bradford Council blue */
        }
        .logo {
            max-width: 200px;
            margin-bottom: 20px;
        }
        .message {
            padding: 15px;
            margin: 20px 0;
            border-radius: 4px;
            background-color: #e8f5e9;
            color: #4CAF50;
        }
        .button {
            display: inline-block;
            background-color: #8DC63F; /* Bradford Council green */
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            margin-top: 20px;
        }
    </style>
    <?php if ($redirect): ?>
    <meta http-equiv="refresh" content="3;url=login.php">
    <?php endif; ?>
</head>
<body>
    <div class="container">
        <img src="images/bradford_council_logo.png" alt="Bradford Council Logo" class="logo">
        <h1>Bradford Council Asset Management System</h1>
        <div class="message">
            <?php echo $message; ?>
        </div>
        <?php if ($redirect): ?>
            <p>You will be redirected to the login page in 3 seconds...</p>
            <a href="login.php" class="button">Login Now</a>
        <?php else: ?>
            <a href="login.php" class="button">Go to Login</a>
        <?php endif; ?>
    </div>
</body>
</html>
