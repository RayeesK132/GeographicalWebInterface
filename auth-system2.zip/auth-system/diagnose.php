<?php
// Force error display
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include database connection
require 'db.php';

echo "<h1>PHP Diagnostic Tool</h1>";
echo "<p>This script will help diagnose issues with your admin dashboard.</p>";

// Check PHP version
echo "<h2>PHP Environment</h2>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p>Server Software: " . $_SERVER['SERVER_SOFTWARE'] . "</p>";

// Check session functionality
echo "<h2>Session Test</h2>";
session_start();
$_SESSION['test'] = 'Session test value';
echo "<p>Session started and test value set. Refresh page to confirm persistence.</p>";
echo "<p>Current session ID: " . session_id() . "</p>";
echo "<p>Test value: " . ($_SESSION['test'] ?? 'Not set') . "</p>";

// Check database connection
echo "<h2>Database Connection Test</h2>";
try {
    echo "<p>Attempting to include db.php...</p>";
    echo "<p>db.php included successfully.</p>";
    
    echo "<p>Testing database connection...</p>";
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->query("SELECT 1");
    echo "<p style='color:green'>Database connection successful!</p>";
    
    echo "<p>Database info: " . $pdo->getAttribute(PDO::ATTR_SERVER_VERSION) . "</p>";
    
    // Check for required tables
    $requiredTables = ['users', 'assets', 'logs'];
    echo "<h3>Checking Required Tables</h3>";
    echo "<ul>";
    foreach ($requiredTables as $table) {
        try {
            $result = $pdo->query("SHOW TABLES LIKE '$table'");
            $exists = $result->rowCount() > 0;
            echo "<li>Table '$table': " . ($exists ? 
                "<span style='color:green'>Exists</span>" : 
                "<span style='color:red'>Missing</span>") . "</li>";
            
            if ($exists) {
                $count = $pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
                echo " - Records: $count";
            }
        } catch (Exception $e) {
            echo "<li>Error checking table '$table': " . $e->getMessage() . "</li>";
        }
    }
    echo "</ul>";
    
    // Check for admin user
    echo "<h3>Checking Admin User</h3>";
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin'");
        $stmt->execute();
        $adminCount = $stmt->fetchColumn();
        
        if ($adminCount > 0) {
            echo "<p style='color:green'>Admin user exists ($adminCount found)</p>";
            $stmt = $pdo->prepare("SELECT id, username, email FROM users WHERE role = 'admin'");
            $stmt->execute();
            $admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo "<ul>";
            foreach ($admins as $admin) {
                echo "<li>ID: {$admin['id']}, Username: {$admin['username']}, Email: {$admin['email']}</li>";
            }
            echo "</ul>";
        } else {
            echo "<p style='color:red'>No admin user found</p>";
            echo "<p>Consider running the <a href='run_db_update.php'>database update script</a> to create one.</p>";
        }
    } catch (Exception $e) {
        echo "<p>Error checking admin user: " . $e->getMessage() . "</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color:red'>Database error: " . $e->getMessage() . "</p>";
    echo "<p>Check your database connection settings in db.php</p>";
}

// Check file permissions
echo "<h2>File System Checks</h2>";
$criticalFiles = [
    'db.php', 
    'login.php', 
    'admin-dashboard.php', 
    'user-management.php'
];

echo "<h3>Critical Files</h3>";
echo "<ul>";
foreach ($criticalFiles as $file) {
    if (file_exists($file)) {
        echo "<li>$file: <span style='color:green'>Exists</span>";
        echo " (Size: " . filesize($file) . " bytes, ";
        echo "Last modified: " . date("Y-m-d H:i:s", filemtime($file)) . ")";
        echo "</li>";
    } else {
        echo "<li>$file: <span style='color:red'>Missing</span></li>";
    }
}
echo "</ul>";

// Provide links to key pages
echo "<h2>Navigation Links</h2>";
echo "<ul>";
echo "<li><a href='login.php'>Login Page</a></li>";
echo "<li><a href='simple-admin.php'>Simple Admin Dashboard</a></li>";
echo "<li><a href='user-management.php'>User Management</a></li>";
echo "<li><a href='run_db_update.php'>Database Update Tool</a></li>";
echo "</ul>";

// Display PHP information
echo "<h2>PHP Information</h2>";
echo "<a href='#' onclick='document.getElementById(\"phpinfo\").style.display=\"block\"; return false;'>Show PHP Info</a>";
echo "<div id='phpinfo' style='display:none'>";
ob_start();
phpinfo();
$phpinfo = ob_get_contents();
ob_end_clean();
// Strip the styling from phpinfo and only show the main content
$phpinfo = preg_replace('%^.*<body>(.*)</body>.*$%ms', '$1', $phpinfo);
// Remove the styling
$phpinfo = str_replace('<div class="center">', '<div>', $phpinfo);
echo $phpinfo;
echo "</div>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Diagnostics</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <?php dbStatusStyles(); ?>
    <style>
        /* ...existing styles... */
    </style>
</head>
<body>
    <div class="container">
        <h1>System Diagnostics</h1>
        
        <!-- Database Connection Status Indicator -->
        <?php renderDbStatusBar(); ?>
        
        <!-- ...existing content... -->
    </div>
</body>
</html>
