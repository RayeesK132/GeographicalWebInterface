<?php
    // Enable error reporting for debugging
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    session_start();

    // Include database connection with improved error handling
    require 'db.php';

    // Check if admin is logged in
    if (! isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
        header('Location: login.php');
        exit();
    }

    // Default sort column and order
    $sortColumn = isset($_GET['sort']) ? $_GET['sort'] : 'username';
    $sortOrder  = isset($_GET['order']) ? $_GET['order'] : 'ASC';
    $search     = isset($_GET['search']) ? $_GET['search'] : '';

    // Initialize users array to prevent undefined variable error
    $users = [];

    // Fetch all users with filter if search is set
    try {
        // Modified query to handle potential GROUP BY issues with strict SQL mode
        if (! empty($search)) {
            $query = "SELECT u.* FROM users u
                  WHERE u.username LIKE :search
                     OR u.email LIKE :search2
                     OR u.role LIKE :search3
                     OR u.department LIKE :search4";
        } else {
            // If no search term, fetch all users
            $query = "SELECT u.* FROM users u";
        }

        // Add order by clause
        $query .= " ORDER BY " . $sortColumn . " " . $sortOrder;

        $stmt = $pdo->prepare($query);

        if (! empty($search)) {
            $searchParam = "%" . $search . "%";
            $stmt->bindValue(':search', $searchParam, PDO::PARAM_STR);
            $stmt->bindValue(':search2', $searchParam, PDO::PARAM_STR);
            $stmt->bindValue(':search3', $searchParam, PDO::PARAM_STR);
            $stmt->bindValue(':search4', $searchParam, PDO::PARAM_STR);
        }

        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($users === false) {
            // Handle query error
            $error = "Error fetching users data";
            $users = []; // Ensure users is an empty array
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
        $users = []; // Ensure users is an empty array
    }

    // Get roles for dropdown
    $roles = ['user', 'admin', 'manager', 'staff'];

    // Get departments for dropdown
    try {
        $stmt        = $pdo->query("SELECT DISTINCT department FROM users WHERE department IS NOT NULL ORDER BY department");
        $departments = $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        $departments = [];
    }

    // Handle user actions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['action'])) {
            switch ($_POST['action']) {
                case 'update':
                    // Update user
                    $userId     = $_POST['user_id'];
                    $username   = $_POST['username'];
                    $email      = $_POST['email'];
                    $role       = $_POST['role'];
                    $department = $_POST['department'];
                    $status     = isset($_POST['status']) ? 1 : 0;

                    try {
                        // Check if department is empty and set to NULL if it is
                        if (empty($department)) {
                            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, role = ?, department = NULL, active = ? WHERE id = ?");
                            $stmt->execute([$username, $email, $role, $status, $userId]);
                        } else {
                            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, role = ?, department = ?, active = ? WHERE id = ?");
                            $stmt->execute([$username, $email, $role, $department, $status, $userId]);
                        }
                        $success = "User updated successfully!";
                    } catch (PDOException $e) {
                        $error = "Error updating user: " . $e->getMessage();
                    }
                    break;

                case 'delete':
                    // Delete user
                    $userId = $_POST['user_id'];

                    try {
                        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                        $stmt->execute([$userId]);
                        $success = "User deleted successfully!";
                    } catch (PDOException $e) {
                        $error = "Error deleting user: " . $e->getMessage();
                    }
                    break;

                case 'create':
                    // Create user
                    $username   = $_POST['username'];
                    $email      = $_POST['email'];
                    $password   = password_hash($_POST['password'], PASSWORD_DEFAULT);
                    $role       = $_POST['role'];
                    $department = $_POST['department'];
                    $status     = isset($_POST['status']) ? 1 : 0;
                    $approved   = isset($_POST['auto_approve']) ? 1 : 0;

                    try {
                        // First, check if the 'approved' column exists in the users table
                        $columnExists = false;
                        $checkStmt    = $pdo->query("SHOW COLUMNS FROM users LIKE 'approved'");
                        if ($checkStmt->rowCount() > 0) {
                            $columnExists = true;
                        }

                        // Prepare SQL statement based on whether approved column exists
                        if ($columnExists) {
                            if (empty($department)) {
                                $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, department, active, approved) VALUES (?, ?, ?, ?, NULL, ?, ?)");
                                $stmt->execute([$username, $email, $password, $role, $status, $approved]);
                            } else {
                                $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, department, active, approved) VALUES (?, ?, ?, ?, ?, ?, ?)");
                                $stmt->execute([$username, $email, $password, $role, $department, $status, $approved]);
                            }
                        } else {
                            // If approved column doesn't exist, don't include it in the query
                            if (empty($department)) {
                                $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, department, active) VALUES (?, ?, ?, ?, NULL, ?)");
                                $stmt->execute([$username, $email, $password, $role, $status]);
                            } else {
                                $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, department, active) VALUES (?, ?, ?, ?, ?, ?)");
                                $stmt->execute([$username, $email, $password, $role, $department, $status]);
                            }
                        }

                        // Create a direct login link if auto-approved
                        if ($approved) {
                            $loginLink = "login.php?username=" . urlencode($username) . "&auto=1";
                            $success   = "User created successfully! <a href='$loginLink' target='_blank'>Login as this user</a>";
                        } else {
                            $success = "User created successfully! This user will need approval before they can log in.";
                        }
                    } catch (PDOException $e) {
                        $error = "Error creating user: " . $e->getMessage();
                    }
                    break;
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Bradford Council</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        /* Database Status Bar Styles */
        .db-status-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #ddd;
        }
        .db-status-indicator {
            display: flex;
            align-items: center;
            font-weight: bold;
        }
        .db-status-indicator i {
            margin-right: 6px;
            font-size: 16px;
        }
        .db-status-indicator.connected {
            color: #28a745;
        }
        .db-status-indicator.disconnected {
            color: #dc3545;
        }
        .db-info {
            display: flex;
            gap: 20px;
            font-size: 14px;
            color: #666;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .panel {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            overflow: hidden;
        }
        .panel-header {
            background-color: #004A87;
            color: white;
            padding: 15px 20px;
            font-size: 1.2em;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .panel-title {
            margin: 0;
        }
        .user-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .user-table th, .user-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .user-table th {
            background-color: #f8f9fa;
            font-weight: bold;
            cursor: pointer;
        }
        .user-table th:hover {
            background-color: #e9ecef;
        }
        .user-table tr:hover {
            background-color: #f1f1f1;
        }
        .user-table .actions {
            display: flex;
            gap: 10px;
        }
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.2s;
        }
        .btn-primary {
            background-color: #004A87;
            color: white;
        }
        .btn-primary:hover {
            background-color: #003366;
        }
        .btn-success {
            background-color: #28a745;
            color: white;
        }
        .btn-success:hover {
            background-color: #218838;
        }
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .search-bar {
            display: flex;
            padding: 10px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #ddd;
            align-items: center;
            margin-bottom: 15px;
        }
        .search-bar input {
            flex: 1;
            padding: 8px 12px;
            border: 1px solid #ced4da;
            border-radius: 4px 0 0 4px;
        }
        .search-bar button {
            padding: 8px 15px;
            border: 1px solid #004A87;
            background-color: #004A87;
            color: white;
            border-radius: 0 4px 4px 0;
            cursor: pointer;
        }
        .search-bar button:hover {
            background-color: #003366;
        }
        .toggle-container {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            gap: 20px;
        }
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 30px;
        }
        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }
        .toggle-slider:before {
            position: absolute;
            content: "";
            height: 22px;
            width: 22px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }
        input:checked + .toggle-slider {
            background-color: #004A87;
        }
        input:checked + .toggle-slider:before {
            transform: translateX(30px);
        }
        .toggle-label {
            font-size: 14px;
            font-weight: bold;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 20px;
            border-radius: 8px;
            width: 50%;
            max-width: 500px;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }
        .modal-title {
            margin: 0;
            font-size: 1.5em;
        }
        .close {
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .form-check {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        .form-check input {
            margin-right: 10px;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="panel">
            <div class="panel-header">
                <h2 class="panel-title">User Management</h2>
                <button class="btn btn-success" onclick="openCreateModal()">Add New User</button>
            </div>
            <div class="search-bar">
                <input type="text" id="searchInput" placeholder="Search by username, email, role, or department..." value="<?php echo htmlspecialchars($search); ?>">
                <button onclick="searchUsers()"><i class="fas fa-search"></i></button>
            </div>
            <div class="panel-body">
                <?php if (isset($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
<?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                <table class="user-table" id="userTable">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Department</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo htmlspecialchars($user['role']); ?></td>
                                <td><?php echo htmlspecialchars($user['department'] ?? 'N/A'); ?></td>
                                <td><?php echo $user['active'] ? 'Active' : 'Inactive'; ?></td>
                                <td class="actions">
                                    <button class="btn btn-primary" onclick="openEditModal(<?php echo htmlspecialchars(json_encode($user)); ?>)">Edit</button>
                                    <button class="btn btn-danger" onclick="confirmDelete(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username']); ?>')">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php if (empty($users)): ?>
                    <p class="text-center">No users found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Create User Modal -->
    <div id="createModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Add New User</h3>
                <span class="close" onclick="closeModal('createModal')">&times;</span>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="create">
                <div class="form-group">
                    <label for="create_username">Username:</label>
                    <input type="text" id="create_username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="create_email">Email:</label>
                    <input type="email" id="create_email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="create_password">Password:</label>
                    <input type="password" id="create_password" name="password" required>
                </div>
                <div class="form-group">
                    <label for="create_role">Role:</label>
                    <select id="create_role" name="role" required>
                        <?php foreach ($roles as $role): ?>
                            <option value="<?php echo $role; ?>"><?php echo ucfirst($role); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="create_department">Department:</label>
                    <select id="create_department" name="department">
                        <option value="">Select Department</option>
                        <?php foreach ($departments as $dept): ?>
                            <option value="<?php echo htmlspecialchars($dept); ?>"><?php echo htmlspecialchars($dept); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-check">
                    <input type="checkbox" id="create_status" name="status" checked>
                    <label for="create_status">Active</label>
                </div>
                <div class="form-check">
                    <input type="checkbox" id="create_auto_approve" name="auto_approve">
                    <label for="create_auto_approve">Auto Approve</label>
                </div>
                <button type="submit" class="btn btn-success">Create User</button>
                <button type="button" class="btn btn-secondary" onclick="closeModal('createModal')">Cancel</button>
            </form>
        </div>
    </div>

    <!-- Edit User Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Edit User</h3>
                <span class="close" onclick="closeModal('editModal')">&times;</span>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="update">
                <input type="hidden" id="edit_user_id" name="user_id">
                <div class="form-group">
                    <label for="edit_username">Username:</label>
                    <input type="text" id="edit_username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="edit_email">Email:</label>
                    <input type="email" id="edit_email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="edit_role">Role:</label>
                    <select id="edit_role" name="role" required>
                        <?php foreach ($roles as $role): ?>
                            <option value="<?php echo $role; ?>"><?php echo ucfirst($role); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="edit_department">Department:</label>
                    <select id="edit_department" name="department">
                        <option value="">Select Department</option>
                        <?php foreach ($departments as $dept): ?>
                            <option value="<?php echo htmlspecialchars($dept); ?>"><?php echo htmlspecialchars($dept); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-check">
                    <input type="checkbox" id="edit_status" name="status">
                    <label for="edit_status">Active</label>
                </div>
                <button type="submit" class="btn btn-primary">Update User</button>
                <button type="button" class="btn btn-secondary" onclick="closeModal('editModal')">Cancel</button>
            </form>
        </div>
    </div>

    <!-- Delete User Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Confirm Delete</h3>
                <span class="close" onclick="closeModal('deleteModal')">&times;</span>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" id="delete_user_id" name="user_id">
                <p>Are you sure you want to delete user <strong id="delete_username"></strong>? This action cannot be undone.</p>
                <button type="submit" class="btn btn-danger">Delete User</button>
                <button type="button" class="btn btn-secondary" onclick="closeModal('deleteModal')">Cancel</button>
            </form>
        </div>
    </div>

    <script>
        function openEditModal(user) {
            document.getElementById('edit_user_id').value = user.id;
            document.getElementById('edit_username').value = user.username;
            document.getElementById('edit_email').value = user.email;
            document.getElementById('edit_role').value = user.role;
            document.getElementById('edit_department').value = user.department || '';
            document.getElementById('edit_status').checked = user.active == 1;
            document.getElementById('editModal').style.display = 'block';
        }

        function openCreateModal() {
            document.getElementById('createModal').style.display = 'block';
        }

        function confirmDelete(userId, username) {
            document.getElementById('delete_user_id').value = userId;
            document.getElementById('delete_username').textContent = username;
            document.getElementById('deleteModal').style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function searchUsers() {
            const searchInput = document.getElementById('searchInput').value;
            window.location.href = `?search=${encodeURIComponent(searchInput)}`;
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                closeModal(event.target.id);
            }
        }

        // Enter key in search triggers search
        document.getElementById('searchInput').addEventListener('keydown', function(event) {
            if (event.key === 'Enter') {
                searchUsers();
            }
        });
    </script>
</body>
</html>
