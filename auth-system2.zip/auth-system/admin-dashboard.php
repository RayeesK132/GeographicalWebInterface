<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Include database connection
require 'db.php';

// Dashboard statistics
$statistics = [];

try {
    // User statistics
    $stmt = $pdo->query("SELECT COUNT(*) as total_users FROM users");
    $statistics['total_users'] = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(*) as active_users FROM users WHERE active = 1");
    $statistics['active_users'] = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT role, COUNT(*) as count FROM users GROUP BY role");
    $statistics['users_by_role'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Asset statistics
    $stmt = $pdo->query("SELECT COUNT(*) as total_assets FROM assets");
    $statistics['total_assets'] = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT asset_type, COUNT(*) as count FROM assets GROUP BY asset_type");
    $statistics['assets_by_type'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Activity statistics
    $stmt = $pdo->query("SELECT COUNT(*) as total_logs FROM logs");
    $statistics['total_logs'] = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT DATE(timestamp) as date, COUNT(*) as count FROM logs GROUP BY DATE(timestamp) ORDER BY date DESC LIMIT 7");
    $statistics['activity_by_day'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Recent actions
    $stmt = $pdo->query("SELECT username, action, timestamp FROM logs ORDER BY timestamp DESC LIMIT 10");
    $statistics['recent_actions'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// Handle system configuration updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'update_settings':
            // Process settings update
            $settings = [
                'site_name' => $_POST['site_name'] ?? 'Bradford Council Asset Management',
                'default_lat' => floatval($_POST['default_lat'] ?? 53.796030),
                'default_lng' => floatval($_POST['default_lng'] ?? -1.759390),
                'default_zoom' => intval($_POST['default_zoom'] ?? 13),
                'max_upload_size' => intval($_POST['max_upload_size'] ?? 5),
                'maintenance_mode' => isset($_POST['maintenance_mode']) ? 1 : 0
            ];
            
            try {
                // Save to config table or file
                // This is a simplified version - in a real application you'd 
                // save these settings to a configuration table or file
                $success = "System settings updated successfully.";
            } catch (Exception $e) {
                $error = "Error updating settings: " . $e->getMessage();
            }
            break;
            
        case 'clear_logs':
            // Clear system logs
            try {
                $stmt = $pdo->prepare("DELETE FROM logs WHERE timestamp < DATE_SUB(NOW(), INTERVAL ? DAY)");
                $days = intval($_POST['days'] ?? 30);
                $stmt->execute([$days]);
                $success = "System logs older than $days days have been cleared.";
            } catch (PDOException $e) {
                $error = "Error clearing logs: " . $e->getMessage();
            }
            break;
    }
}

// Get system information
$systemInfo = [
    'php_version' => PHP_VERSION,
    'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
    'database_type' => $pdo->getAttribute(PDO::ATTR_DRIVER_NAME),
    'database_version' => $pdo->getAttribute(PDO::ATTR_SERVER_VERSION),
    'max_upload_size' => ini_get('upload_max_filesize'),
    'max_post_size' => ini_get('post_max_size'),
    'memory_limit' => ini_get('memory_limit'),
    'execution_time' => ini_get('max_execution_time') . ' seconds'
];

// Default settings
$defaultSettings = [
    'site_name' => 'Bradford Council Asset Management',
    'default_lat' => 53.796030,
    'default_lng' => -1.759390,
    'default_zoom' => 13,
    'max_upload_size' => 5,
    'maintenance_mode' => 0
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Bradford Council</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <?php dbStatusStyles(); ?>
    <style>
        :root {
            --primary-color: #004A87;
            --secondary-color: #8DC63F;
            --dark-color: #333333;
            --light-color: #f4f4f4;
            --danger-color: #dc3545;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --info-color: #17a2b8;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: var(--dark-color);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .dashboard-header {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .dashboard-title {
            margin: 0;
            color: var(--primary-color);
            font-size: 24px;
        }

        .user-info {
            display: flex;
            align-items: center;
        }

        .user-info img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .dashboard-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .card-header {
            background-color: var(--primary-color);
            color: white;
            padding: 15px 20px;
            font-size: 18px;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-body {
            padding: 20px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .stat-card {
            background-color: var(--light-color);
            border-radius: 6px;
            padding: 15px;
            text-align: center;
        }

        .stat-number {
            font-size: 28px;
            font-weight: bold;
            margin: 10px 0;
            color: var(--primary-color);
        }

        .stat-label {
            font-size: 14px;
            color: #666;
        }

        .chart-container {
            height: 250px;
            position: relative;
        }

        .activity-list {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .activity-item {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
            display: flex;
            align-items: center;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 36px;
            height: 36px;
            background-color: var(--light-color);
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-right: 15px;
        }

        .activity-content {
            flex: 1;
        }

        .activity-username {
            font-weight: bold;
            margin-right: 5px;
        }

        .activity-action {
            color: #666;
        }

        .activity-time {
            font-size: 12px;
            color: #999;
        }

        .dashboard-full {
            grid-column: 1 / -1;
        }

        .nav-tabs {
            display: flex;
            margin: 0;
            padding: 0;
            list-style: none;
            border-bottom: 2px solid #eee;
        }

        .nav-tabs li {
            margin-right: 5px;
        }

        .nav-tabs a {
            display: block;
            padding: 10px 15px;
            text-decoration: none;
            color: #666;
            border-radius: 4px 4px 0 0;
        }

        .nav-tabs a.active {
            background-color: var(--primary-color);
            color: white;
        }

        .tab-content {
            padding: 20px 0;
        }

        .tab-pane {
            display: none;
        }

        .tab-pane.active {
            display: block;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .form-check {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        .form-check input {
            margin-right: 10px;
        }

        .btn {
            display: inline-block;
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            background-color: var(--primary-color);
            color: white;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-secondary {
            background-color: #6c757d;
        }

        .btn-success {
            background-color: var(--success-color);
        }

        .btn-danger {
            background-color: var(--danger-color);
        }

        .btn-warning {
            background-color: var(--warning-color);
            color: #333;
        }

        .btn-info {
            background-color: var(--info-color);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th, table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        table th {
            background-color: #f8f9fa;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .system-info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }

        .system-info-item {
            padding: 10px;
            background-color: #f8f9fa;
            border-radius: 4px;
        }

        .system-info-label {
            font-weight: bold;
            margin-right: 5px;
        }

        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
        }

        .badge-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .badge-success {
            background-color: var(--success-color);
            color: white;
        }

        .badge-danger {
            background-color: var(--danger-color);
            color: white;
        }

        .badge-warning {
            background-color: var(--warning-color);
            color: #333;
        }

        .badge-info {
            background-color: var(--info-color);
            color: white;
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }

        .maintenance-banner {
            background-color: #fff3cd;
            color: #856404;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
            text-align: center;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="panel">
            <div class="panel-header">
                <h2 class="panel-title">Admin Dashboard</h2>
                <div>
                    <a href="logout.php" class="btn btn-primary">Logout</a>
                </div>
            </div>
            
            <!-- Database Connection Status Indicator -->
            <?php renderDbStatusBar(); ?>
            
            <?php if (isset($defaultSettings['maintenance_mode']) && $defaultSettings['maintenance_mode']): ?>
            <div class="maintenance-banner">
                <i class="fas fa-exclamation-triangle"></i> System is currently in maintenance mode. Only administrators can access the site.
            </div>
            <?php endif; ?>

            <div class="dashboard-header">
                <h1 class="dashboard-title">Admin Dashboard</h1>
                <div class="user-info">
                    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['username']); ?>&background=random" alt="User Avatar">
                    <div>
                        <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
                        <div><small>Administrator</small></div>
                    </div>
                </div>
            </div>

            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="dashboard-grid">
                <!-- Users Statistics Card -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <span>User Statistics</span>
                        <a href="user-management.php" class="btn btn-secondary" style="font-size: 12px; padding: 5px 10px;">Manage Users</a>
                    </div>
                    <div class="card-body">
                        <div class="stats-grid">
                            <div class="stat-card">
                                <div class="stat-number"><?php echo $statistics['total_users'] ?? 0; ?></div>
                                <div class="stat-label">Total Users</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-number"><?php echo $statistics['active_users'] ?? 0; ?></div>
                                <div class="stat-label">Active Users</div>
                            </div>
                        </div>
                        <div class="chart-container" style="margin-top: 20px;">
                            <canvas id="userRolesChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Asset Statistics Card -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <span>Asset Statistics</span>
                        <a href="asset-management.php" class="btn btn-secondary" style="font-size: 12px; padding: 5px 10px;">Manage Assets</a>
                    </div>
                    <div class="card-body">
                        <div class="stats-grid">
                            <div class="stat-card">
                                <div class="stat-number"><?php echo $statistics['total_assets'] ?? 0; ?></div>
                                <div class="stat-label">Total Assets</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-number"><?php echo count($statistics['assets_by_type'] ?? []); ?></div>
                                <div class="stat-label">Asset Types</div>
                            </div>
                        </div>
                        <div class="chart-container" style="margin-top: 20px;">
                            <canvas id="assetTypesChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity Card -->
                <div class="dashboard-card">
                    <div class="card-header">
                        <span>Recent Activity</span>
                    </div>
                    <div class="card-body">
                        <ul class="activity-list">
                            <?php if (!empty($statistics['recent_actions'])): ?>
                                <?php foreach ($statistics['recent_actions'] as $action): ?>
                                    <li class="activity-item">
                                        <div class="activity-icon">
                                            <i class="fas fa-user"></i>
                                        </div>
                                        <div class="activity-content">
                                            <span class="activity-username"><?php echo htmlspecialchars($action['username']); ?></span>
                                            <span class="activity-action"><?php echo htmlspecialchars($action['action']); ?></span>
                                            <span class="activity-time"><?php echo htmlspecialchars($action['timestamp']); ?></span>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <li class="activity-item">No recent activity found.</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>