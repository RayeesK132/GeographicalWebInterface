<?php
// Auth0 Configuration
// Get these values from your Auth0 Application settings
define('AUTH0_DOMAIN', 'your-auth0-domain.auth0.com');
define('AUTH0_CLIENT_ID', 'your-auth0-client-id');
define('AUTH0_CLIENT_SECRET', 'your-auth0-client-secret');
define('AUTH0_CALLBACK_URL', 'http://localhost/auth-system/auth0-callback.php');
define('AUTH0_AUDIENCE', 'https://' . AUTH0_DOMAIN . '/userinfo');
define('AUTH0_SCOPE', 'openid profile email');

// Bradford Council Branding
define('BRADFORD_PRIMARY_COLOR', '#004A87'); // Bradford Council blue
define('BRADFORD_SECONDARY_COLOR', '#8DC63F'); // Bradford Council green
define('BRADFORD_LOGO_PATH', 'images/bradford_council_logo.png');

// Departments List
define('DEPARTMENTS', [
    'IT' => 'Information Technology',
    'HR' => 'Human Resources',
    'Finance' => 'Finance Department',
    'Planning' => 'Planning Department',
    'Housing' => 'Housing Department',
    'Education' => 'Education Department',
    'Social' => 'Social Services',
    'Health' => 'Health Services',
    'Environment' => 'Environmental Services',
    'Other' => 'Other Department'
]);
?>
