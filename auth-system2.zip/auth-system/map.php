<?php
session_start();
require 'db.php';
require_once 'functions.php';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

// Get user's role and job category
$role = $_SESSION['role'] ?? 'user';
$userId = $_SESSION['user_id'] ?? 0;

// Fetch user's map preferences
try {
    $stmt = $pdo->prepare("SELECT us.*, ms.style_json, ms.name as style_name 
                          FROM user_settings us 
                          JOIN map_styles ms ON us.preferred_map_style = ms.id 
                          WHERE us.user_id = ?");
    $stmt->execute([$userId]);
    $userSettings = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$userSettings) {
        // Create default settings if none exist
        $stmt = $pdo->prepare("INSERT INTO user_settings (user_id) VALUES (?)");
        $stmt->execute([$userId]);
        
        $stmt = $pdo->prepare("SELECT us.*, ms.style_json, ms.name as style_name 
                              FROM user_settings us 
                              JOIN map_styles ms ON us.preferred_map_style = ms.id 
                              WHERE us.user_id = ?");
        $stmt->execute([$userId]);
        $userSettings = $stmt->fetch(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    $userSettings = [
        'preferred_map_style' => 1,
        'default_location_lat' => 53.796030,
        'default_location_lng' => -1.759390,
        'default_zoom' => 13,
        'style_json' => '{"baseLayer": "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", "attribution": "&copy; OpenStreetMap contributors"}',
        'style_name' => 'Standard'
    ];
}

// Get all available map styles
try {
    $stmt = $pdo->query("SELECT * FROM map_styles ORDER BY name");
    $mapStyles = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $mapStyles = [];
}

// Handle AJAX request to update user settings
if (isset($_POST['action']) && $_POST['action'] === 'update_settings') {
    $mapStyleId = filter_input(INPUT_POST, 'map_style', FILTER_VALIDATE_INT);
    $defaultLat = filter_input(INPUT_POST, 'default_lat', FILTER_VALIDATE_FLOAT);
    $defaultLng = filter_input(INPUT_POST, 'default_lng', FILTER_VALIDATE_FLOAT);
    $defaultZoom = filter_input(INPUT_POST, 'default_zoom', FILTER_VALIDATE_INT);
    
    if ($mapStyleId) {
        try {
            $stmt = $pdo->prepare("UPDATE user_settings SET 
                                  preferred_map_style = ?,
                                  default_location_lat = ?,
                                  default_location_lng = ?,
                                  default_zoom = ?
                                  WHERE user_id = ?");
            $stmt->execute([$mapStyleId, $defaultLat, $defaultLng, $defaultZoom, $userId]);
            
            // Return success response
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'message' => 'Settings updated successfully']);
            exit();
        } catch (PDOException $e) {
            // Return error response
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Failed to update settings: ' . $e->getMessage()]);
            exit();
        }
    }
}

// Handle AJAX request to fetch assets
if (isset($_GET['fetchAssets'])) {
    // Existing asset fetching code...
    exit();
}

// Get professional areas for filter
$professionalAreas = [
    'General' => 'All Assets',
    'Planning' => 'Urban Planning Assets',
    'Environmental' => 'Environmental Assets',
    'Transportation' => 'Transportation Assets',
    'Housing' => 'Housing Assets',
    'Education' => 'Education Assets',
    'Health' => 'Health Services Assets'
];

// Get all available asset types
try {
    $stmt = $pdo->query("SELECT DISTINCT asset_type FROM assets WHERE asset_type IS NOT NULL ORDER BY asset_type");
    $assetTypes = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $assetTypes = ['generic'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interactive Map - Bradford Council</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <?php dbStatusStyles(); ?>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: 'Arial', sans-serif;
            overflow-x: hidden;
        }
        
        /* Main layout */
        #map {
            height: 100vh;
            width: 100%;
            position: absolute;
            top: 0;
            left: 0;
            z-index: 0;
        }
        
        /* Top search bar */
        .search-container {
            position: absolute;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            width: 60%;
            max-width: 700px;
            z-index: 1000;
            display: flex;
            background-color: white;
            border-radius: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            padding: 8px 16px;
            transition: all 0.3s ease;
        }
        
        .search-container input {
            flex: 1;
            border: none;
            outline: none;
            padding: 8px;
            border-radius: 25px;
            font-size: 16px;
        }
        
        .search-container button {
            background: none;
            border: none;
            color: #004A87;
            cursor: pointer;
            padding: 8px;
            font-size: 18px;
        }
        
        /* Filter navigation panel */
        .filter-panel {
            position: absolute;
            top: 0;
            right: 0;
            width: 300px;
            height: 100vh;
            background-color: white;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            z-index: 1001;
            transform: translateX(300px);
            transition: transform 0.3s ease;
            overflow-y: auto;
        }
        
        .filter-panel.visible {
            transform: translateX(0);
        }
        
        .filter-toggle {
            position: absolute;
            top: 70px;
            right: 10px;
            z-index: 1002;
            width: 40px;
            height: 40px;
            background-color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
            cursor: pointer;
            font-size: 18px;
        }
        
        .filter-section {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .filter-section h3 {
            margin-top: 0;
            color: #004A87;
            font-size: 16px;
        }
        
        /* Asset controls */
        .asset-controls {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1000;
            display: flex;
            gap: 10px;
            background-color: white;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }
        
        .asset-controls button {
            background-color: #004A87;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .asset-controls button:hover {
            background-color: #003366;
        }
        
        /* Form elements */
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
            font-size: 14px;
        }
        
        .form-control {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        /* Map style options */
        .map-style-options {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .map-style-option {
            width: calc(50% - 5px);
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            cursor: pointer;
            text-align: center;
        }
        
        .map-style-option.active {
            border-color: #004A87;
            background-color: rgba(0, 74, 135, 0.1);
        }
        
        .map-style-name {
            font-weight: bold;
            font-size: 12px;
            color: #004A87;
        }
        
        /* Layer toggles */
        .layer-control {
            display: flex;
            align-items: center;
            margin-bottom: 8px;
        }
        
        .layer-control input {
            margin-right: 8px;
        }
        
        .layer-icon {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        
        /* Mode indicator */
        .mode-indicator {
            position: absolute;
            bottom: 80px;
            left: 10px;
            background-color: rgba(0, 74, 135, 0.8);
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            z-index: 999;
        }
        
        /* Buttons */
        .btn {
            display: inline-block;
            padding: 8px 16px;
            background-color: #004A87;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
        }
        
        .btn-block {
            display: block;
            width: 100%;
            text-align: center;
            margin-top: 10px;
        }
        
        .btn-secondary {
            background-color: #8DC63F;
        }
        
        /* Mini toolbar */
        .mini-toolbar {
            position: absolute;
            bottom: 20px;
            right: 10px;
            z-index: 1000;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .tool-button {
            width: 40px;
            height: 40px;
            background-color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
            cursor: pointer;
            font-size: 16px;
            color: #004A87;
        }
        
        .tool-button:hover {
            background-color: #f0f0f0;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .search-container {
                width: 90%;
                top: 5px;
            }
            
            .filter-panel {
                width: 80%;
            }
            
            .asset-controls {
                flex-direction: column;
                left: 10px;
                transform: none;
                bottom: 70px;
            }
            
            .map-style-option {
                width: 100%;
            }
        }
        
        /* Hide attribution */
        .leaflet-control-attribution {
            display: none !important;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="panel">
            <div class="panel-header">
                <h2 class="panel-title">Interactive Map</h2>
                <div>
                    <a href="logout.php" class="btn btn-primary">Logout</a>
                </div>
            </div>
            
            <!-- Database Connection Status Indicator -->
            <?php renderDbStatusBar(); ?>
            
            <!-- Main Map Container -->
            <div id="map"></div>
            
            <!-- Top Search Bar -->
            <div class="search-container">
                <input type="text" id="searchInput" placeholder="Search for locations or assets...">
                <button id="searchButton"><i class="fas fa-search"></i></button>
            </div>
            
            <!-- Filter Toggle Button -->
            <div class="filter-toggle" id="filterToggle">
                <i class="fas fa-sliders-h"></i>
            </div>
            
            <!-- Filter Panel -->
            <div class="filter-panel" id="filterPanel">
                <div class="filter-section">
                    <h3>Map Settings</h3>
                    <div class="form-group">
                        <label for="professionalArea">Professional View</label>
                        <select id="professionalArea" class="form-control">
                            <?php foreach ($professionalAreas as $value => $label): ?>
                                <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button id="applyProfessionalFilter" class="btn btn-block">Apply Filter</button>
                </div>
                <div class="filter-section">
                    <h3>Map Style</h3>
                    <div class="map-style-options">
                        <?php foreach ($mapStyles as $style): ?>
                            <div class="map-style-option <?php echo ($style['id'] == $userSettings['preferred_map_style']) ? 'active' : ''; ?>" 
                                 data-style-id="<?php echo $style['id']; ?>" 
                                 data-style-json='<?php echo $style['style_json']; ?>'
                                 title="<?php echo $style['description']; ?>">
                                <div class="map-style-name"><?php echo $style['name']; ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="filter-section">
                    <h3>Layer Visibility</h3>
                    <div class="layer-control">
                        <input type="checkbox" id="showBuildings" checked>
                        <div class="layer-icon" style="background-color: #1976D2;"></div>
                        <label for="showBuildings">Buildings</label>
                    </div>
                    <div class="layer-control">
                        <input type="checkbox" id="showParks" checked>
                        <div class="layer-icon" style="background-color: #43A047;"></div>
                        <label for="showParks">Parks</label>
                    </div>
                    <div class="layer-control">
                        <input type="checkbox" id="showSchools" checked>
                        <div class="layer-icon" style="background-color: #FF9800;"></div>
                        <label for="showSchools">Schools</label>
                    </div>
                    <div class="layer-control">
                        <input type="checkbox" id="showHealthcare" checked>
                        <div class="layer-icon" style="background-color: #E53935;"></div>
                        <label for="showHealthcare">Healthcare</label>
                    </div>
                    <div class="layer-control">
                        <input type="checkbox" id="showInfrastructure" checked>
                        <div class="layer-icon" style="background-color: #607D8B;"></div>
                        <label for="showInfrastructure">Infrastructure</label>
                    </div>
                    <div class="layer-control">
                        <input type="checkbox" id="showLandmarks" checked>
                        <div class="layer-icon" style="background-color: #FFC107;"></div>
                        <label for="showLandmarks">Landmarks</label>
                    </div>
                    <div class="layer-control">
                        <input type="checkbox" id="showOthers" checked>
                        <div class="layer-icon" style="background-color: #795548;"></div>
                        <label for="showOthers">Others</label>
                    </div>
                </div>
                <div class="filter-section">
                    <h3>Default View Settings</h3>
                    <div class="form-group">
                        <label for="defaultZoom">Default Zoom Level: <span id="zoomValue"><?php echo $userSettings['default_zoom']; ?></span></label>
                        <input type="range" id="defaultZoom" class="form-control" min="5" max="18" value="<?php echo $userSettings['default_zoom']; ?>">
                    </div>
                    <button id="saveCurrentView" class="btn btn-secondary btn-block">Save Current View</button>
                    <button id="saveSettings" class="btn btn-block">Save All Settings</button>
                </div>
                <div class="filter-section">
                    <a href="<?php echo $role === 'admin' ? 'admin-dashboard.php' : 'dashboard.php'; ?>" class="btn btn-block">Back to Dashboard</a>
                </div>
            </div>
                    
            <!-- Asset Control Buttons -->
            <div class="asset-controls">
                <button id="addAssetBtn"><i class="fas fa-plus"></i> Add Asset</button>
                <button id="editAssetBtn"><i class="fas fa-edit"></i> Edit Asset</button>
                <button id="removeAssetBtn"><i class="fas fa-trash"></i> Remove Asset</button>
            </div>
            
            <!-- Current Mode Indicator -->
            <div class="mode-indicator">
                <i class="fas fa-map-marked-alt"></i> <span id="currentMode"><?php echo $userSettings['style_name']; ?> Mode</span>
            </div>
            
            <!-- Mini Toolbar -->
            <div class="mini-toolbar">
                <div class="tool-button" id="zoomIn" title="Zoom In"><i class="fas fa-plus"></i></div>
                <div class="tool-button" id="zoomOut" title="Zoom Out"><i class="fas fa-minus"></i></div>
                <div class="tool-button" id="resetView" title="Reset View"><i class="fas fa-home"></i></div>
                <div class="tool-button" id="measureDistance" title="Measure Distance"><i class="fas fa-ruler"></i></div>
                <div class="tool-button" id="fullscreenToggle" title="Toggle Fullscreen"><i class="fas fa-expand"></i></div>
            </div>
        </div>
    </div>
    
    <!-- JavaScript -->
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.js"></script>
    <script>
        // Initialize the map
        const defaultSettings = <?php echo json_encode($userSettings); ?>;
        const mapStyles = <?php echo json_encode($mapStyles); ?>;
        
        // Parse style JSON from the user's preferred style
        const styleJson = JSON.parse(defaultSettings.style_json);
        
        // Initialize map with user's preferred settings and remove attribution
        const map = L.map('map', {
            attributionControl: false // Remove attribution control
        }).setView(
            [defaultSettings.default_location_lat, defaultSettings.default_location_lng], 
            defaultSettings.default_zoom
        );
        
        // Initialize the base tile layer without attribution
        let baseLayer = L.tileLayer(styleJson.baseLayer, {
            attribution: '' // Empty attribution
        }).addTo(map);
        
        // Layer groups for different asset types
        const layers = {
            buildings: L.layerGroup().addTo(map),
            parks: L.layerGroup().addTo(map),
            schools: L.layerGroup().addTo(map),
            healthcare: L.layerGroup().addTo(map),
            infrastructure: L.layerGroup().addTo(map),
            landmarks: L.layerGroup().addTo(map),
            shops: L.layerGroup().addTo(map),
            others: L.layerGroup().addTo(map)
        };
        
        // Track user position and routing control
        let userPosition = null;
        let routeControl = null;
        let assetMarkers = [];
        let assetData = [];
        let selectedAsset = null;
        let isAddingAsset = false;
        let isEditingAsset = false;
        let isRemovingAsset = false;
        
        // Toggle filter panel
        document.getElementById('filterToggle').addEventListener('click', function() {
            const filterPanel = document.getElementById('filterPanel');
            filterPanel.classList.toggle('visible');
            this.innerHTML = filterPanel.classList.contains('visible')
                ? '<i class="fas fa-times"></i>'
                : '<i class="fas fa-sliders-h"></i>';
        });
        
        document.getElementById('searchButton').addEventListener('click', function() {
            const searchValue = document.getElementById('searchInput').value;
            if (searchValue.trim() !== '') {
                searchLocation(searchValue);
            }
        });
        
        document.getElementById('searchInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const searchValue = this.value;
                if (searchValue.trim() !== '') {
                    searchLocation(searchValue);
                }
            }
        });
        
        function searchLocation(query) {
            // Use Nominatim for geocoding
            fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    if (data && data.length > 0) {
                        const result = data[0];
                        map.setView([result.lat, result.lon], 15);
                        L.marker([result.lat, result.lon])
                            .addTo(map)
                            .bindPopup(result.display_name)
                            .openPopup();
                    } else {
                        // Search in assets
                        searchInAssets(query);
                    }
                })
                .catch(error => {
                    console.error("Error searching location:", error);
                    // Fallback to asset search
                    searchInAssets(query);
                });
        }
        
        function searchInAssets(query) {
            const found = assetData.find(asset => 
                asset.name.toLowerCase().includes(query.toLowerCase()) ||
                (asset.description && asset.description.toLowerCase().includes(query.toLowerCase()))
            );
            
            if (found) {
                map.setView([found.latitude, found.longitude], 16);
                // Find corresponding marker and open popup
                for (const layer in layers) {
                    layers[layer].eachLayer(marker => {
                        if (marker.getLatLng().lat === parseFloat(found.latitude) && 
                            marker.getLatLng().lng === parseFloat(found.longitude)) {
                            marker.openPopup();
                        }
                    });
                }
            } else {
                alert("No locations or assets found matching your search.");
            }
        }
        
        // Load assets from the database
        function loadAssets(professionalFilter = null) {
            // Clear all layers and reset asset tracking
            Object.values(layers).forEach(layer => layer.clearLayers());
            assetMarkers = [];
            assetData = [];
            
            // Fetch assets from the database
            fetch('save-asset.php')
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! Status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success && data.assets && data.assets.length > 0) {
                        // Filter assets by professional area if needed
                        let assetsToDisplay = data.assets;
                        if (professionalFilter && professionalFilter !== 'General') {
                            assetsToDisplay = data.assets.filter(asset => 
                                asset.department === professionalFilter || 
                                asset.asset_type === professionalFilter.toLowerCase()
                            );
                        }
                        
                        // Display the assets
                        assetsToDisplay.forEach(asset => {
                            assetData.push(asset);
                            
                            const marker = L.marker([asset.latitude, asset.longitude], {
                                icon: getAssetIcon(asset.asset_type)
                            });
                            
                            marker.bindPopup(`
                                <div style="min-width: 200px;">
                                    <h3 style="margin: 0 0 10px 0; color: #004A87;">${asset.name}</h3>
                                    <p><strong>Type:</strong> ${asset.asset_type || 'Generic'}</p>
                                    <p><strong>Department:</strong> ${asset.department || 'N/A'}</p>
                                    <p><strong>Owner:</strong> ${asset.owner || 'N/A'}</p>
                                    ${asset.description ? `<p><strong>Description:</strong> ${asset.description}</p>` : ''}
                                    <button onclick="getDirectionsTo(${asset.latitude}, ${asset.longitude})" 
                                            style="background-color: #004A87; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer; margin-top: 10px;">
                                        Get Directions
                                    </button>
                                </div>
                            `);
                            
                            // Store reference to the asset id with the marker
                            marker.assetId = asset.id;
                            
                            // Add marker to appropriate layer and tracking arrays
                            addMarkerToLayer(marker, asset.asset_type);
                            assetMarkers.push(marker);
                            
                            // Add click handler for selecting assets
                            marker.on('click', function() {
                                if (isEditingAsset || isRemovingAsset) {
                                    selectedAsset = this;
                                    if (isRemovingAsset) {
                                        if (confirm('Are you sure you want to delete this asset?')) {
                                            removeSelectedAsset();
                                        }
                                    } else if (isEditingAsset) {
                                        startEditAsset(this.assetId);
                                    }
                                }
                            });
                        });
                    } else {
                        console.log("No assets found.");
                    }
                })
                .catch(error => console.error("Error loading assets:", error));
        }
        
        // Get custom icon based on asset type
        function getAssetIcon(type) {
            // Define icon colors based on asset type
            const iconColors = {
                'building': '#1976D2',
                'park': '#43A047',
                'school': '#FF9800',
                'healthcare': '#E53935',
                'infrastructure': '#607D8B',
                'generic': '#795548'
            };
            const color = iconColors[type?.toLowerCase()] || '#004A87';
            
            return L.divIcon({
                className: 'asset-marker',
                html: `<div style="background-color: ${color}; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white;"></div>`,
                iconSize: [16, 16],
                iconAnchor: [8, 8]
            });
        }
        
        // Add marker to appropriate layer based on asset type
        function addMarkerToLayer(marker, type) {
            switch(type?.toLowerCase()) {
                case 'building':
                    layers.buildings.addLayer(marker);
                    break;
                case 'park':
                    layers.parks.addLayer(marker);
                    break;
                case 'school':
                    layers.schools.addLayer(marker);
                    break;
                case 'healthcare':
                    layers.healthcare.addLayer(marker);
                    break;
                case 'infrastructure':
                    layers.infrastructure.addLayer(marker);
                    break;
                default:
                    // Add to all layers for generic or unknown types
                    Object.values(layers).forEach(layer => layer.addLayer(marker));
            }
        }
        
        // Function to get directions to an asset without revealing user location
        function getDirectionsTo(lat, lng) {
            const destination = `${lat},${lng}`;
            const googleMapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${destination}`;
            
            if (confirm("Would you like to get directions to this location?")) {
                window.open(googleMapsUrl, '_blank');
            }
        }
        
        // Replace previous navigateToAsset function with this privacy-focused version
        function navigateToAsset(lat, lng) {
            getDirectionsTo(lat, lng);
        }
        
        // Layer control event listeners
        document.getElementById('showBuildings').addEventListener('change', function() {
            if (this.checked) {
                map.addLayer(layers.buildings);
            } else {
                map.removeLayer(layers.buildings);
            }
        });
        
        document.getElementById('showParks').addEventListener('change', function() {
            if (this.checked) {
                map.addLayer(layers.parks);
            } else {
                map.removeLayer(layers.parks);
            }
        });
        
        document.getElementById('showSchools').addEventListener('change', function() {
            if (this.checked) {
                map.addLayer(layers.schools);
            } else {
                map.removeLayer(layers.schools);
            }
        });
        
        document.getElementById('showHealthcare').addEventListener('change', function() {
            if (this.checked) {
                map.addLayer(layers.healthcare);
            } else {
                map.removeLayer(layers.healthcare);
            }
        });
        
        document.getElementById('showInfrastructure').addEventListener('change', function() {
            if (this.checked) {
                map.addLayer(layers.infrastructure);
            } else {
                map.removeLayer(layers.infrastructure);
            }
        });
        
        document.querySelectorAll('.map-style-option').forEach(option => {
            option.addEventListener('click', function() {
                // Remove active class from all options
                document.querySelectorAll('.map-style-option').forEach(opt => {
                    opt.classList.remove('active');
                });
                
                // Add active class to selected option
                this.classList.add('active');
                
                // Get style JSON from data attribute
                const styleId = this.getAttribute('data-style-id');
                const styleJson = JSON.parse(this.getAttribute('data-style-json'));
                
                // Update the map style
                map.removeLayer(baseLayer);
                baseLayer = L.tileLayer(styleJson.baseLayer, {
                    attribution: styleJson.attribution
                }).addTo(map);
                
                // Update the mode badge
                const styleName = this.querySelector('.map-style-name').textContent;
                document.getElementById('currentMode').textContent = styleName + ' Mode';
            });
        });
        
        // Professional filter button click event
        document.getElementById('applyProfessionalFilter').addEventListener('click', function() {
            const professionalArea = document.getElementById('professionalArea').value;
            loadAssets(professionalArea);
            // Optionally close the filter panel after applying
            document.getElementById('filterPanel').classList.remove('visible');
            document.getElementById('filterToggle').innerHTML = '<i class="fas fa-sliders-h"></i>';
        });
        
        // Save current view as default
        document.getElementById('saveCurrentView').addEventListener('click', function() {
            const center = map.getCenter();
            const zoom = map.getZoom();
            
            document.getElementById('defaultZoom').value = zoom;
            alert('Current view saved. Click "Save All Settings" to persist these changes.');
        });
        
        // Save all settings button
        document.getElementById('saveSettings').addEventListener('click', function() {
            const activeStyle = document.querySelector('.map-style-option.active');
            const mapStyleId = activeStyle.getAttribute('data-style-id');
            const center = map.getCenter();
            const zoom = map.getZoom();
            
            // Prepare data for AJAX request
            const formData = new FormData();
            formData.append('action', 'update_settings');
            formData.append('map_style', mapStyleId);
            formData.append('default_lat', center.lat);
            formData.append('default_lng', center.lng);
            formData.append('default_zoom', zoom);
            
            // Send AJAX request
            fetch('map.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Settings saved successfully!');
                } else {
                    alert('Error saving settings: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while saving settings.');
            });
        });
        
        // Default zoom slider
        const zoomSlider = document.getElementById('defaultZoom');
        const zoomValue = document.getElementById('zoomValue');
        
        zoomSlider.addEventListener('input', function() {
            zoomValue.textContent = this.value;
        });
        
        // Mini toolbar functionality
        document.getElementById('zoomIn').addEventListener('click', function() {
            map.zoomIn();
        });
        
        document.getElementById('zoomOut').addEventListener('click', function() {
            map.zoomOut();
        });
        
        document.getElementById('resetView').addEventListener('click', function() {
            map.setView(
                [defaultSettings.default_location_lat, defaultSettings.default_location_lng], 
                defaultSettings.default_zoom
            );
        });
        
        document.getElementById('fullscreenToggle').addEventListener('click', function() {
            const mapElement = document.getElementById('map');
            if (!document.fullscreenElement) {
                if (mapElement.requestFullscreen) {
                    mapElement.requestFullscreen();
                } else if (mapElement.mozRequestFullScreen) {
                    mapElement.mozRequestFullScreen();
                } else if (mapElement.webkitRequestFullscreen) {
                    mapElement.webkitRequestFullscreen();
                } else if (mapElement.msRequestFullscreen) {
                    mapElement.msRequestFullscreen();
                }
                this.innerHTML = '<i class="fas fa-compress"></i>';
            } else {
                if (document.exitFullscreen) {
                    document.exitFullscreen();
                } else if (document.mozCancelFullScreen) {
                    document.mozCancelFullScreen();
                } else if (document.webkitExitFullscreen) {
                    document.webkitExitFullscreen();
                } else if (document.msExitFullscreen) {
                    document.msExitFullscreen();
                }
                this.innerHTML = '<i class="fas fa-expand"></i>';
            }
        });
        
        // Measure distance tool
        let measuring = false;
        let measurePoints = [];
        let measureLayer = null;
        
        document.getElementById('measureDistance').addEventListener('click', function() {
            if (!measuring) {
                measuring = true;
                measurePoints = [];
                this.style.backgroundColor = '#8DC63F';
                alert('Click on the map to start measuring. Click multiple points to measure distance between them. Right-click to finish.');
                map.on('click', onMapClickMeasure);
                map.on('contextmenu', finishMeasuring);
            } else {
                finishMeasuring();
            }
        });
        
        function onMapClickMeasure(e) {
            if (measuring) {
                measurePoints.push(e.latlng);
                
                if (measureLayer) {
                    map.removeLayer(measureLayer);
                }
                
                if (measurePoints.length > 1) {
                    measureLayer = L.polyline(measurePoints, {
                        color: '#8DC63F',
                        weight: 3,
                        opacity: 0.7,
                        dashArray: '5, 10'
                    }).addTo(map);
                    
                    let totalDistance = 0;
                    for (let i = 1; i < measurePoints.length; i++) {
                        totalDistance += measurePoints[i-1].distanceTo(measurePoints[i]);
                    }
                    
                    measureLayer.bindPopup(`Total distance: ${(totalDistance / 1000).toFixed(2)} km`).openPopup();
                }
            }
        }
        
        function finishMeasuring() {
            measuring = false;
            document.getElementById('measureDistance').style.backgroundColor = '';
            map.off('click', onMapClickMeasure);
            map.off('contextmenu', finishMeasuring);
        }
        
        // Asset management functions
        document.getElementById('addAssetBtn').addEventListener('click', function() {
            resetAssetModes();
            isAddingAsset = true;
            this.style.backgroundColor = '#8DC63F';
            alert('Click on the map to place a new asset.');
            map.once('click', function(e) {
                showAddAssetForm(e.latlng);
            });
        });
        
        document.getElementById('editAssetBtn').addEventListener('click', function() {
            resetAssetModes();
            isEditingAsset = true;
            this.style.backgroundColor = '#8DC63F';
            alert('Click on an existing asset to edit it.');
        });
        
        document.getElementById('removeAssetBtn').addEventListener('click', function() {
            resetAssetModes();
            isRemovingAsset = true;
            this.style.backgroundColor = '#8DC63F';
            alert('Click on an asset to remove it.');
        });
        
        function resetAssetModes() {
            isAddingAsset = false;
            isEditingAsset = false;
            isRemovingAsset = false;
            selectedAsset = null;
            document.getElementById('addAssetBtn').style.backgroundColor = '#004A87';
            document.getElementById('editAssetBtn').style.backgroundColor = '#004A87';
            document.getElementById('removeAssetBtn').style.backgroundColor = '#004A87';
        }
        
        function showAddAssetForm(latlng) {
            // Create a popup with a form
            const popup = L.popup()
                .setLatLng(latlng)
                .setContent(`
                    <div style="min-width: 250px;">
                        <h3 style="margin: 0 0 10px 0; color: #004A87;">Add New Asset</h3>
                        <form id="addAssetForm">
                            <div style="margin-bottom: 10px;">
                                <label style="display: block; margin-bottom: 5px;">Name:</label>
                                <input type="text" id="assetName" style="width: 100%; padding: 5px;">
                            </div>
                            <div style="margin-bottom: 10px;">
                                <label style="display: block; margin-bottom: 5px;">Type:</label>
                                <select id="assetType" style="width: 100%; padding: 5px;">
                                    <option value="generic">Generic</option>
                                    <option value="building">Building</option>
                                    <option value="park">Park</option>
                                    <option value="school">School</option>
                                    <option value="healthcare">Healthcare</option>
                                    <option value="infrastructure">Infrastructure</option>
                                </select>
                            </div>
                            <div style="margin-bottom: 10px;">
                                <label style="display: block; margin-bottom: 5px;">Department:</label>
                                <input type="text" id="assetDepartment" style="width: 100%; padding: 5px;">
                            </div>
                            <div style="margin-bottom: 10px;">
                                <label style="display: block; margin-bottom: 5px;">Description:</label>
                                <textarea id="assetDescription" style="width: 100%; padding: 5px; height: 60px;"></textarea>
                            </div>
                            <input type="hidden" id="assetLat" value="${latlng.lat}">
                            <input type="hidden" id="assetLng" value="${latlng.lng}">
                            <button type="button" onclick="saveNewAsset()" style="background-color: #004A87; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Save Asset</button>
                            <button type="button" onclick="cancelAddAsset()" style="background-color: #ccc; color: #333; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; margin-left: 5px;">Cancel</button>
                        </form>
                    </div>
                `)
                .openOn(map);
        }
        
        // Function to add a new asset
        function saveNewAsset() {
            const name = document.getElementById('assetName').value;
            const type = document.getElementById('assetType').value;
            const department = document.getElementById('assetDepartment').value;
            const description = document.getElementById('assetDescription').value;
            const lat = document.getElementById('assetLat').value;
            const lng = document.getElementById('assetLng').value;
            
            if (!name) {
                alert('Asset name is required.');
                return;
            }
            
            // Debug log
            console.log("Adding asset with data:", {
                name, lat, lng, type, department, description
            });
            
            // Create form data
            const formData = new FormData();
            formData.append('name', name);
            formData.append('latitude', lat);
            formData.append('longitude', lng);
            formData.append('asset_type', type);
            formData.append('department', department);
            formData.append('description', description);
            
            // Send to the dedicated save-asset.php endpoint
            fetch('save-asset.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log("Server response:", data);
                if (data.success) {
                    alert('Asset added successfully!');
                    map.closePopup();
                    resetAssetModes();
                    loadAssets(); // Reload assets to show the new one
                } else {
                    alert('Error adding asset: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while adding the asset: ' + error.message);
            });
        }
        
        function cancelAddAsset() {
            map.closePopup();
            resetAssetModes();
        }
        
        function startEditAsset(assetId) {
            // Find the asset data
            const asset = assetData.find(a => a.id === assetId);
            if (!asset) {
                alert('Asset not found.');
                return;
            }
            
            // Create a popup with the edit form
            const popup = L.popup()
                .setLatLng([asset.latitude, asset.longitude])
                .setContent(`
                    <div style="min-width: 250px;">
                        <h3 style="margin: 0 0 10px 0; color: #004A87;">Edit Asset</h3>
                        <form id="editAssetForm">
                            <div style="margin-bottom: 10px;">
                                <label style="display: block; margin-bottom: 5px;">Name:</label>
                                <input type="text" id="editAssetName" value="${asset.name}" style="width: 100%; padding: 5px;">
                            </div>
                            <div style="margin-bottom: 10px;">
                                <label style="display: block; margin-bottom: 5px;">Type:</label>
                                <select id="editAssetType" style="width: 100%; padding: 5px;">
                                    <option value="generic" ${asset.asset_type === 'generic' ? 'selected' : ''}>Generic</option>
                                    <option value="building" ${asset.asset_type === 'building' ? 'selected' : ''}>Building</option>
                                    <option value="park" ${asset.asset_type === 'park' ? 'selected' : ''}>Park</option>
                                    <option value="school" ${asset.asset_type === 'school' ? 'selected' : ''}>School</option>
                                    <option value="healthcare" ${asset.asset_type === 'healthcare' ? 'selected' : ''}>Healthcare</option>
                                    <option value="infrastructure" ${asset.asset_type === 'infrastructure' ? 'selected' : ''}>Infrastructure</option>
                                </select>
                            </div>
                            <div style="margin-bottom: 10px;">
                                <label style="display: block; margin-bottom: 5px;">Department:</label>
                                <input type="text" id="editAssetDepartment" value="${asset.department || ''}" style="width: 100%; padding: 5px;">
                            </div>
                            <div style="margin-bottom: 10px;">
                                <label style="display: block; margin-bottom: 5px;">Description:</label>
                                <textarea id="editAssetDescription" style="width: 100%; padding: 5px; height: 60px;">${asset.description || ''}</textarea>
                            </div>
                            <input type="hidden" id="editAssetId" value="${asset.id}">
                            <button type="button" onclick="updateAsset()" style="background-color: #004A87; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Update Asset</button>
                            <button type="button" onclick="cancelEditAsset()" style="background-color: #ccc; color: #333; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; margin-left: 5px;">Cancel</button>
                        </form>
                    </div>
                `)
                .openOn(map);
        }
        
        function updateAsset() {
            const id = document.getElementById('editAssetId').value;
            const name = document.getElementById('editAssetName').value;
            const type = document.getElementById('editAssetType').value;
            const department = document.getElementById('editAssetDepartment').value;
            const description = document.getElementById('editAssetDescription').value;
            
            if (!name) {
                alert('Asset name is required.');
                return;
            }
            
            // Debug
            console.log("Updating asset:", {
                id, name, type, department, description
            });
            
            // Create form data
            const formData = new FormData();
            formData.append('action', 'updateAsset');
            formData.append('id', id);
            formData.append('name', name);
            formData.append('asset_type', type);
            formData.append('department', department);
            formData.append('description', description);
            
            // Send to server
            fetch('map_api.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log("Server response:", data);
                if (data.success) {
                    alert('Asset updated successfully!');
                    map.closePopup();
                    resetAssetModes();
                    loadAssets(); // Reload assets to show the updated one
                } else {
                    alert('Error updating asset: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating the asset: ' + error.message);
            });
        }
        
        function cancelEditAsset() {
            map.closePopup();
            resetAssetModes();
        }
        
        function removeSelectedAsset() {
            if (!selectedAsset) {
                alert('No asset selected.');
                return;
            }
            
            // Create form data
            const formData = new FormData();
            formData.append('action', 'deleteAsset');
            formData.append('id', selectedAsset.assetId);
            
            // Debug
            console.log("Deleting asset:", selectedAsset.assetId);
            
            // Send to server
            fetch('map_api.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log("Server response:", data);
                if (data.success) {
                    alert('Asset deleted successfully!');
                    map.closePopup();
                    resetAssetModes();
                    loadAssets(); // Reload assets to reflect the deletion
                } else {
                    alert('Error deleting asset: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while deleting the asset: ' + error.message);
            });
        }
        
        // Modified user location handling - only store locally, don't display on the shared map
        function getUserLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    (position) => {
                        // Store position but don't display a marker
                        userPosition = {
                            lat: position.coords.latitude,
                            lng: position.coords.longitude
                        };
                        
                        // Optionally center the map on user's location without showing a marker
                        // Uncomment the next line if you want the map to center on user's location initially
                        // map.setView([userPosition.lat, userPosition.lng], map.getZoom());
                        
                        console.log("Location services enabled");
                    },
                    (error) => {
                        console.log("Error getting location: ", error);
                    }
                );
            }
        }
        
        // Initialize when the window loads
        window.onload = function() {
            loadAssets();
            getUserLocation();
        };
    </script>
</body>
</html>
