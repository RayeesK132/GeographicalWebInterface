<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>MySQL Connection Diagnostics</h1>";

// Check if .htaccess might be causing issues
echo "<h2>Step 0: Checking Apache Configuration</h2>";
if (!in_array('mod_rewrite', apache_get_modules())) {
    echo "<p style='color: orange;'><strong>WARNING:</strong> mod_rewrite is not enabled in Apache, which may affect .htaccess functionality.</p>";
    echo "<p>To enable mod_rewrite:</p>";
    echo "<ol>";
    echo "<li>Open <code>C:\xampp\apache\conf\httpd.conf</code></li>";
    echo "<li>Find and uncomment: <code>LoadModule rewrite_module modules/mod_rewrite.so</code></li>";
    echo "<li>Restart Apache</li>";
    echo "</ol>";
} else {
    echo "<p style='color: green;'><strong>GOOD:</strong> Apache mod_rewrite is enabled.</p>";
}

if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/.htaccess')) {
    echo "<p style='color: blue;'><strong>INFO:</strong> Root .htaccess file exists.</p>";
} else {
    echo "<p style='color: blue;'><strong>INFO:</strong> No root .htaccess file found. This is fine if you haven't created one.</p>";
}

if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/auth-system/.htaccess')) {
    echo "<p style='color: blue;'><strong>INFO:</strong> auth-system/.htaccess file exists.</p>";
} else {
    echo "<p style='color: blue;'><strong>INFO:</strong> No auth-system/.htaccess file found. This is fine if you haven't created one.</p>";
}

// Step 1: Check if the MySQL service is running
echo "<h2>Step 1: Checking if MySQL service is running</h2>";
$host = 'localhost';
$port = 3306; // Default MySQL port

// Try to connect directly to the MySQL server
$connection = @fsockopen($host, $port, $errno, $errstr, 5);
if (!$connection) {
    echo "<p style='color: red;'><strong>ERROR:</strong> Cannot connect to MySQL on $host:$port - $errstr ($errno)</p>";
    echo "<p style='color: red;'><strong>CAUSE:</strong> The MySQL service is likely not running.</p>";
    echo "<h3>How to fix:</h3>";
    echo "<ol>";
    echo "<li>Open XAMPP Control Panel</li>";
    echo "<li>Click the 'Start' button next to MySQL</li>";
    echo "<li>If it doesn't start, check the XAMPP error logs</li>";
    echo "<li>Refresh this page after starting MySQL</li>";
    echo "</ol>";
    
    echo "<img src='https://www.apachefriends.org/images/xampp-control-panel.jpg' alt='XAMPP Control Panel' style='max-width: 600px; border: 1px solid #ccc;'>";
} else {
    echo "<p style='color: green;'><strong>SUCCESS:</strong> MySQL server is running and accessible on $host:$port</p>";
    fclose($connection);
    
    // Step 2: Check MySQL credentials
    echo "<h2>Step 2: Checking MySQL credentials</h2>";
    try {
        // Get credentials from db.php if possible
        if (file_exists('db.php')) {
            include 'db.php';
            echo "<p>Using credentials from db.php</p>";
        } else {
            // Default XAMPP credentials
            $username = 'root';
            $password = '';
            $dbname = 'auth_system';
            echo "<p>Using default XAMPP credentials (username: root, password: empty)</p>";
        }
        
        // Try to connect with PDO
        $dsn = "mysql:host=$host;port=$port";
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_TIMEOUT => 5
        ];
        
        $pdo = new PDO($dsn, $username, $password, $options);
        echo "<p style='color: green;'><strong>SUCCESS:</strong> Connected to MySQL server successfully!</p>";
        
        // Step 3: Check if database exists
        echo "<h2>Step 3: Checking if database exists</h2>";
        $stmt = $pdo->query("SHOW DATABASES LIKE '$dbname'");
        if ($stmt->rowCount() > 0) {
            echo "<p style='color: green;'><strong>SUCCESS:</strong> Database '$dbname' exists!</p>";
            
            // Connect to the specific database
            $pdo = new PDO("mysql:host=$host;port=$port;dbname=$dbname", $username, $password, $options);
            
            // Step 4: Check key tables
            echo "<h2>Step 4: Checking key tables</h2>";
            $tables = ['users', 'assets', 'logs'];
            foreach ($tables as $table) {
                try {
                    $stmt = $pdo->query("SELECT 1 FROM $table LIMIT 1");
                    echo "<p style='color: green;'><strong>SUCCESS:</strong> Table '$table' exists and is accessible.</p>";
                } catch (PDOException $e) {
                    echo "<p style='color: orange;'><strong>WARNING:</strong> Table '$table' does not exist or is not accessible.</p>";
                }
            }
        } else {
            echo "<p style='color: red;'><strong>ERROR:</strong> Database '$dbname' does not exist!</p>";
            echo "<h3>How to fix:</h3>";
            echo "<ol>";
            echo "<li>Visit <a href='setup-database.php'>setup-database.php</a> to create the database</li>";
            echo "<li>Or manually create the database using phpMyAdmin at <a href='http://localhost/phpmyadmin/' target='_blank'>http://localhost/phpmyadmin/</a></li>";
            echo "</ol>";
        }
        
    } catch (PDOException $e) {
        echo "<p style='color: red;'><strong>ERROR:</strong> " . $e->getMessage() . "</p>";
        
        if (strpos($e->getMessage(), 'Access denied') !== false) {
            echo "<h3>How to fix authentication issues:</h3>";
            echo "<ol>";
            echo "<li>Check your username and password in db.php</li>";
            echo "<li>For default XAMPP installation, username should be 'root' with an empty password</li>";
            echo "<li>If you've set a password, make sure it's correct in db.php</li>";
            echo "<li>You can reset MySQL password through XAMPP Control Panel → Shell → mysql -u root</li>";
            echo "</ol>";
        }
    }
}

echo "<h2>Additional Troubleshooting Steps:</h2>";
echo "<ol>";
echo "<li>Make sure no other service is using port 3306</li>";
echo "<li>Check XAMPP MySQL logs in C:\\xampp\\mysql\\data\\[hostname].err</li>";
echo "<li>Restart your computer</li>";
echo "<li>Reinstall XAMPP if persistent issues occur</li>";
echo "</ol>";
?>
