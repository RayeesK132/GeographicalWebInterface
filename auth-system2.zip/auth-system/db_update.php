<?php
// Include database connection
require 'db.php';

try {
    // Update assets table to include asset_type, department, and description
    $pdo->exec("ALTER TABLE assets 
                ADD COLUMN IF NOT EXISTS asset_type VARCHAR(50) DEFAULT 'generic',
                ADD COLUMN IF NOT EXISTS department VARCHAR(100) DEFAULT NULL,
                ADD COLUMN IF NOT EXISTS description TEXT DEFAULT NULL");
    
    // Update users table to include department, job_role, and professional_area fields
    $pdo->exec("ALTER TABLE users 
                ADD COLUMN IF NOT EXISTS department VARCHAR(100) DEFAULT NULL,
                ADD COLUMN IF NOT EXISTS job_role VARCHAR(100) DEFAULT NULL,
                ADD COLUMN IF NOT EXISTS professional_area VARCHAR(100) DEFAULT 'General',
                ADD COLUMN IF NOT EXISTS auth0_id VARCHAR(255) DEFAULT NULL");
    
    // Create map_styles table if it doesn't exist
    $pdo->exec("CREATE TABLE IF NOT EXISTS map_styles (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                description TEXT DEFAULT NULL,
                style_json TEXT NOT NULL,
                professional_use VARCHAR(100) DEFAULT NULL,
                is_default TINYINT(1) DEFAULT 0
              )");
    
    // Insert default map styles if not already present
    $checkStyles = $pdo->query("SELECT COUNT(*) FROM map_styles");
    if ($checkStyles->fetchColumn() == 0) {
        $pdo->exec("INSERT INTO map_styles (name, description, style_json, professional_use, is_default) VALUES
                    ('Standard', 'The default map style', '{\"baseLayer\": \"https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png\", \"attribution\": \"&copy; OpenStreetMap contributors\"}', 'General', 1),
                    ('Urban Planning', 'High contrast style for urban planning', '{\"baseLayer\": \"https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png\", \"attribution\": \"&copy; CartoDB and OpenStreetMap contributors\"}', 'Planning', 0),
                    ('Environmental', 'Terrain-focused style for environmental planning', '{\"baseLayer\": \"https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png\", \"attribution\": \"&copy; OpenTopoMap and OpenStreetMap contributors\"}', 'Environmental', 0),
                    ('Transportation', 'Focus on roads and transport networks', '{\"baseLayer\": \"https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png\", \"attribution\": \"&copy; CartoDB and OpenStreetMap contributors\"}', 'Transportation', 0),
                    ('Dark Mode', 'Low-light professional mode', '{\"baseLayer\": \"https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png\", \"attribution\": \"&copy; CartoDB and OpenStreetMap contributors\"}', 'Night Work', 0)");
    }
    
    // Create user_settings table if it doesn't exist
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                preferred_map_style INT DEFAULT 1,
                default_location_lat DECIMAL(10,6) DEFAULT 53.796030,
                default_location_lng DECIMAL(10,6) DEFAULT -1.759390,
                default_zoom INT DEFAULT 13,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (preferred_map_style) REFERENCES map_styles(id)
              )");

    // Insert default settings for existing users if not already present
    $stmt = $pdo->query("SELECT id FROM users");
    $userIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    foreach ($userIds as $userId) {
        $check = $pdo->prepare("SELECT COUNT(*) FROM user_settings WHERE user_id = ?");
        $check->execute([$userId]);
        
        if ($check->fetchColumn() == 0) {
            $stmt = $pdo->prepare("INSERT INTO user_settings (user_id) VALUES (?)");
            $stmt->execute([$userId]);
        }
    }
    
    // Create Auth0 settings table if it doesn't exist
    $pdo->exec("CREATE TABLE IF NOT EXISTS auth0_config (
                id INT AUTO_INCREMENT PRIMARY KEY,
                domain VARCHAR(255) NOT NULL,
                client_id VARCHAR(255) NOT NULL,
                client_secret VARCHAR(255) NOT NULL,
                callback_url VARCHAR(255) NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
              )");
    
    // Let's create this script to update any database issues
    
    // First, let's check if the 'approved' column exists in the users table
    $columnExists = false;
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'approved'");
    if ($stmt->rowCount() > 0) {
        $columnExists = true;
    }
    
    // If the 'approved' column doesn't exist, add it
    if (!$columnExists) {
        $pdo->exec("ALTER TABLE users ADD COLUMN approved TINYINT(1) NOT NULL DEFAULT 1");
        echo "<p>Added 'approved' column to users table.</p>";
    } else {
        echo "<p>'approved' column already exists in users table.</p>";
    }
    
    // Check for other common database issues
    
    // 1. Make sure department column exists in users table
    $columnExists = false;
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'department'");
    if ($stmt->rowCount() > 0) {
        $columnExists = true;
    }
    
    if (!$columnExists) {
        $pdo->exec("ALTER TABLE users ADD COLUMN department VARCHAR(100) DEFAULT NULL");
        echo "<p>Added 'department' column to users table.</p>";
    } else {
        echo "<p>'department' column already exists in users table.</p>";
    }
    
    // 2. Make sure active column exists in users table
    $columnExists = false;
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'active'");
    if ($stmt->rowCount() > 0) {
        $columnExists = true;
    }
    
    if (!$columnExists) {
        $pdo->exec("ALTER TABLE users ADD COLUMN active TINYINT(1) NOT NULL DEFAULT 1");
        echo "<p>Added 'active' column to users table.</p>";
    } else {
        echo "<p>'active' column already exists in users table.</p>";
    }
    
    echo "<p style='color: green; font-weight: bold;'>Database update completed successfully!</p>";
    echo "<p><a href='user-management.php'>Return to User Management</a></p>";
    
} catch (PDOException $e) {
    echo "<p style='color: red; font-weight: bold;'>Database update failed: " . $e->getMessage() . "</p>";
    
    // Debug information
    echo "<p>If you're seeing 'Invalid parameter number' errors, please check:</p>";
    echo "<ul>";
    echo "<li>That you're using the correct number of placeholders (?) in your SQL queries</li>";
    echo "<li>That your execute() method is receiving the correct number of parameters</li>";
    echo "<li>That your SQL queries are properly formatted</li>";
    echo "</ul>";
}
?>
