<?php
require 'vendor/autoload.php';

use League\OAuth2\Client\Provider\GenericProvider;

$provider = new GenericProvider([
    'clientId'                => 'your-client-id',
    'clientSecret'            => 'your-client-secret',
    'redirectUri'             => 'http://yourdomain.com/sso-login.php',
    'urlAuthorize'            => 'https://provider.com/oauth2/authorize',
    'urlAccessToken'          => 'https://provider.com/oauth2/token',
    'urlResourceOwnerDetails' => 'https://provider.com/oauth2/resource'
]);

if (!isset($_GET['code'])) {
    $authorizationUrl = $provider->getAuthorizationUrl();
    $_SESSION['oauth2state'] = $provider->getState();
    header('Location: ' . $authorizationUrl);
    exit();
} elseif (empty($_GET['state']) || ($_GET['state'] !== $_SESSION['oauth2state'])) {
    unset($_SESSION['oauth2state']);
    exit('Invalid state');
} else {
    try {
        $accessToken = $provider->getAccessToken('authorization_code', [
            'code' => $_GET['code']
        ]);

        $resourceOwner = $provider->getResourceOwner($accessToken);
        $user = $resourceOwner->toArray();

        // Log the user in or create an account
        $_SESSION['username'] = $user['email'];
        header('Location: dashboard.php');
        exit();
    } catch (Exception $e) {
        exit('Failed to get access token: ' . $e->getMessage());
    }
}
?>
