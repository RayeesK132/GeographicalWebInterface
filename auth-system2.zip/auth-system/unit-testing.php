<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unit Testing</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="admin-panel-container">
        <h2>Unit Testing</h2>
        <p>Below are the unit tests implemented:</p>
        <ul>
            <li><strong>Authentication Module (auth.test.js):</strong>
                <ul>
                    <li>login(): Tests login functionality.</li>
                    <li>logout(): Tests logout functionality.</li>
                    <li>isAdmin(): Tests admin role check.</li>
                </ul>
            </li>
            <li><strong>User Management (admin.test.js):</strong>
                <ul>
                    <li>handleUserApproval(): Tests user approval flow.</li>
                    <li>handleMapSettingsUpdate(): Tests map settings updates.</li>
                </ul>
            </li>
            <li><strong>API Integration (api.test.js):</strong>
                <ul>
                    <li>login(): Tests API login endpoint.</li>
                    <li>getUsers(): Tests user retrieval.</li>
                    <li>getAssets(): Tests asset retrieval.</li>
                    <li>deleteUser(): Tests user deletion.</li>
                    <li>deleteAsset(): Tests asset deletion.</li>
                </ul>
            </li>
        </ul>
        <a href="admin-dashboard.php" class="btn">Back to Dashboard</a>
    </div>
</body>
</html>
