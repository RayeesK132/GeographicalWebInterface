<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Include database connection
require 'db.php';

// Function to check if a table exists
function tableExists($pdo, $table) {
    try {
        $result = $pdo->query("SELECT 1 FROM $table LIMIT 1");
        return $result !== false;
    } catch (Exception $e) {
        return false;
    }
}

// Test database connectivity and get table stats
$dbTests = [
    'connection' => true,
    'tables' => [
        'users' => tableExists($pdo, 'users'),
        'assets' => tableExists($pdo, 'assets'),
        'logs' => tableExists($pdo, 'logs')
    ],
    'counts' => []
];

// Get record counts for each existing table
foreach ($dbTests['tables'] as $table => $exists) {
    if ($exists) {
        try {
            $stmt = $pdo->query("SELECT COUNT(*) FROM $table");
            $dbTests['counts'][$table] = $stmt->fetchColumn();
        } catch (Exception $e) {
            $dbTests['counts'][$table] = "Error: " . $e->getMessage();
        }
    } else {
        $dbTests['counts'][$table] = "Table does not exist";
    }
}

// Get database server info
try {
    $dbInfo = $pdo->getAttribute(PDO::ATTR_SERVER_VERSION);
} catch (Exception $e) {
    $dbInfo = "Could not retrieve: " . $e->getMessage();
}

// Get user information
$userData = [
    'username' => $_SESSION['username'],
    'role' => $_SESSION['role']
];

try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$_SESSION['username']]);
    $userDetails = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $userDetails = "Error retrieving user details: " . $e->getMessage();
}

// Function to render database status bar
function renderDbStatusBar() {
    global $dbTests;
    echo '<div class="status-bar">';
    echo '<p>Database Connection: ';
    if ($dbTests['connection']) {
        echo '<span class="status status-ok">Connected</span>';
    } else {
        echo '<span class="status status-error">Failed</span>';
    }
    echo '</p>';
    echo '</div>';
}

// Function to include database status styles
function dbStatusStyles() {
    echo '<style>
        .status-bar {
            background-color: #f5f5f5;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }
        .status-ok {
            color: #155724;
        }
        .status-error {
            color: #721c24;
        }
    </style>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard Test</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <?php dbStatusStyles(); ?>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
            background-color: #004A87;
            color: white;
            padding: 15px 20px;
            border-radius: 6px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .card-header {
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
            margin-bottom: 15px;
            font-weight: bold;
            font-size: 18px;
        }
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }
        .status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: bold;
        }
        .status-ok {
            background-color: #d4edda;
            color: #155724;
        }
        .status-error {
            background-color: #f8d7da;
            color: #721c24;
        }
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background-color: #004A87;
            color: white;
        }
        .btn-primary:hover {
            background-color: #003366;
        }
        .code-block {
            background-color: #f8f8f8;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 15px;
            font-family: monospace;
            white-space: pre-wrap;
            word-break: break-all;
            max-height: 200px;
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Admin Dashboard Test</h1>
            <div>
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            </div>
        </div>
        
        <!-- Database Connection Status Indicator -->
        <?php renderDbStatusBar(); ?>
        
        <h2>Database Diagnostics</h2>
        
        <div class="dashboard-grid">
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-database"></i> Database Connection
                </div>
                <div>
                    <p>Status: 
                        <?php if ($dbTests['connection']): ?>
                            <span class="status status-ok">Connected</span>
                        <?php else: ?>
                            <span class="status status-error">Failed</span>
                        <?php endif; ?>
                    </p>
                    <p>Server Version: <?php echo htmlspecialchars($dbInfo); ?></p>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-table"></i> Table Status
                </div>
                <table width="100%">
                    <tr>
                        <th>Table</th>
                        <th>Exists</th>
                        <th>Records</th>
                    </tr>
                    <?php foreach ($dbTests['tables'] as $table => $exists): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($table); ?></td>
                        <td>
                            <?php if ($exists): ?>
                                <span class="status status-ok">Yes</span>
                            <?php else: ?>
                                <span class="status status-error">No</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($dbTests['counts'][$table]); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-user"></i> Current User
                </div>
                <p><strong>Username:</strong> <?php echo htmlspecialchars($userData['username']); ?></p>
                <p><strong>Role:</strong> <?php echo htmlspecialchars($userData['role']); ?></p>
                
                <div class="card-header">
                    User Details
                </div>
                <div class="code-block">
                    <?php 
                    if (is_array($userDetails)) {
                        echo htmlspecialchars(print_r($userDetails, true));
                    } else {
                        echo htmlspecialchars($userDetails);
                    }
                    ?>
                </div>
            </div>
        </div>
        
        <div style="margin-top: 20px; text-align: center;">
            <a href="run_db_update.php" class="btn btn-primary">Database Update Tool</a>
            <a href="user-management.php" class="btn btn-primary">User Management</a>
            <a href="logout.php" class="btn btn-primary">Logout</a>
        </div>
    </div>
</body>
</html>
