<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceptance Testing</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="admin-panel-container">
        <h2>Acceptance Testing</h2>
        <p>Below are the test cases for acceptance testing:</p>
        <ul>
            <li><strong>INSPECT-001:</strong> Verify code adheres to coding standards.</li>
            <li><strong>INSPECT-002:</strong> Check for proper documentation and comments.</li>
            <li><strong>INSPECT-003:</strong> Test for correctness of algorithms and logic.</li>
            <li><strong>INSPECT-004:</strong> Validate the performance and efficiency of the code.</li>
            <li><strong>INSPECT-005:</strong> Check for security vulnerabilities.</li>
        </ul>
        <a href="admin-dashboard.php" class="btn">Back to Dashboard</a>
    </div>
</body>
</html>
