<?php
session_start();
require 'db.php';
require 'auth_config.php';
require 'functions.php';

// Use composer autoload
require __DIR__ . '/vendor/autoload.php';

use Auth0\SDK\Auth0;
use Auth0\SDK\Configuration\SdkConfiguration;

// Configure Auth0
$configuration = new SdkConfiguration(
    domain: AUTH0_DOMAIN,
    clientId: AUTH0_CLIENT_ID,
    clientSecret: AUTH0_CLIENT_SECRET,
    redirectUri: AUTH0_CALLBACK_URL,
    audience: [AUTH0_AUDIENCE],
    scope: [AUTH0_SCOPE]
);

$auth0 = new Auth0($configuration);

try {
    // Exchange authorization code for tokens
    $auth0->exchange();
    
    // Get user info from Auth0
    $user = $auth0->getUser();
    
    // If we have user data, proceed
    if ($user !== null) {
        $auth0Id = $user['sub']; // Auth0 user identifier
        $email = $user['email'] ?? '';
        $name = $user['name'] ?? '';
        
        // Check if user already exists in our database
        $stmt = $pdo->prepare("SELECT * FROM users WHERE auth0_id = :auth0_id");
        $stmt->execute(['auth0_id' => $auth0Id]);
        $existingUser = $stmt->fetch();
        
        if ($existingUser) {
            // User exists, update login session
            $_SESSION['username'] = $existingUser['username'];
            $_SESSION['user_id'] = $existingUser['id'];
            $_SESSION['role'] = $existingUser['role'];
            $_SESSION['department'] = $existingUser['department'];
            $_SESSION['job_role'] = $existingUser['job_role'];
            
            // Set permission flags
            $_SESSION['add_visible'] = $existingUser['add_visible'];
            $_SESSION['edit_visible'] = $existingUser['edit_visible'];
            $_SESSION['delete_visible'] = $existingUser['delete_visible'];
            $_SESSION['filter_visible'] = $existingUser['filter_visible'];
            
            // Log the login
            logLogin($pdo, $existingUser['username']);
            
            // Redirect to appropriate dashboard
            if ($existingUser['role'] === 'admin') {
                header('Location: admin-dashboard.php');
            } else {
                header('Location: dashboard.php');
            }
            exit();
        } else {
            // User doesn't exist, redirect to profile completion
            $_SESSION['auth0_id'] = $auth0Id;
            $_SESSION['auth0_email'] = $email;
            $_SESSION['auth0_name'] = $name;
            
            header('Location: complete-profile.php');
            exit();
        }
    } else {
        // No user data, redirect to login with error
        header('Location: login.php?error=auth0_failed');
        exit();
    }
} catch (Exception $e) {
    // Handle any errors during the authentication process
    error_log('Auth0 error: ' . $e->getMessage());
    header('Location: login.php?error=auth0_error');
    exit();
}
?>
