<?php
session_start();
require 'db.php';
require 'auth_config.php';
require 'functions.php';

// Check if we have Auth0 data
if (!isset($_SESSION['auth0_id'])) {
    header('Location: login.php');
    exit();
}

$error = '';
$auth0Id = $_SESSION['auth0_id'];
$email = $_SESSION['auth0_email'] ?? '';
$name = $_SESSION['auth0_name'] ?? '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $phone = trim($_POST['phone']);
    $department = trim($_POST['department']);
    $jobRole = trim($_POST['job_role']);
    
    if (empty($username) || empty($phone) || empty($department) || empty($jobRole)) {
        $error = "All fields are required";
    } else {
        // Check if username exists
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch();
        
        if ($user) {
            $error = "Username already exists";
        } else {
            try {
                // Create new user with Auth0 data
                $stmt = $pdo->prepare("INSERT INTO users (username, email, phone, department, job_role, auth0_id, approved) 
                                      VALUES (:username, :email, :phone, :department, :job_role, :auth0_id, 1)");
                $stmt->execute([
                    'username' => $username,
                    'email' => $email,
                    'phone' => $phone,
                    'department' => $department,
                    'job_role' => $jobRole,
                    'auth0_id' => $auth0Id
                ]);
                
                $userId = $pdo->lastInsertId();
                
                // Log the registration
                logUserRegistration($pdo, $username);
                
                // Set session variables for the new user
                $_SESSION['username'] = $username;
                $_SESSION['user_id'] = $userId;
                $_SESSION['role'] = 'user'; // Default role
                $_SESSION['department'] = $department;
                $_SESSION['job_role'] = $jobRole;
                
                // Set default permissions
                $_SESSION['add_visible'] = 0;
                $_SESSION['edit_visible'] = 0;
                $_SESSION['delete_visible'] = 0;
                $_SESSION['filter_visible'] = 0;
                
                // Clear Auth0 temp data
                unset($_SESSION['auth0_id']);
                unset($_SESSION['auth0_email']);
                unset($_SESSION['auth0_name']);
                
                // Redirect to dashboard
                header('Location: dashboard.php');
                exit();
            } catch (PDOException $e) {
                $error = "Registration failed: " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Your Profile - Bradford Council</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Header with Bradford Council Logo -->
    <header class="header">
        <div class="container">
            <div class="header-logo">
                <img src="images/bradford_council_logo.png" alt="Bradford Council Logo">
                <h1 class="header-title">Asset Management System</h1>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="form-container">
            <h2 class="form-title">Complete Your Profile</h2>
            <p>Thanks for signing in with SSO. Please provide additional information to complete your profile.</p>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" id="username" name="username" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>" readonly>
                    <small>Email from your SSO account cannot be changed</small>
                </div>
                
                <div class="form-group">
                    <label for="phone" class="form-label">Phone Number</label>
                    <input type="text" id="phone" name="phone" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="department" class="form-label">Department</label>
                    <select id="department" name="department" class="form-select" required>
                        <option value="">Select Department</option>
                        <?php foreach (DEPARTMENTS as $key => $value): ?>
                            <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="job_role" class="form-label">Job Role</label>
                    <input type="text" id="job_role" name="job_role" class="form-control" required>
                </div>
                
                <button type="submit" class="form-button">Complete Profile</button>
            </form>
        </div>
    </div>
</body>
</html>
