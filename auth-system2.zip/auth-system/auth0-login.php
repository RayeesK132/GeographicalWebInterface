<?php
require 'auth_config.php';

// We need to use composer autoloader
require __DIR__ . '/vendor/autoload.php';

use Auth0\SDK\Auth0;
use Auth0\SDK\Configuration\SdkConfiguration;

// Configure Auth0
$configuration = new SdkConfiguration(
    domain: AUTH0_DOMAIN,
    clientId: AUTH0_CLIENT_ID,
    clientSecret: AUTH0_CLIENT_SECRET,
    redirectUri: AUTH0_CALLBACK_URL,
    audience: [AUTH0_AUDIENCE],
    scope: [AUTH0_SCOPE]
);

$auth0 = new Auth0($configuration);

// Start the authentication process
$auth0->login();
?>
