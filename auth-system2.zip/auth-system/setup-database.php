<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection parameters
$host = 'localhost';
$dbname = 'auth_system';
$username = 'root';
$password = 'root';

// CSS for the page
echo "
<style>
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        margin: 0;
        padding: 20px;
        color: #333;
    }
    .container {
        max-width: 800px;
        margin: 0 auto;
        background: #f8f9fa;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    h1 {
        color: #004A87;
        border-bottom: 1px solid #ddd;
        padding-bottom: 10px;
    }
    .success {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
        padding: 15px;
        border-radius: 4px;
        margin-bottom: 15px;
    }
    .error {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
        padding: 15px;
        border-radius: 4px;
        margin-bottom: 15px;
    }
    .btn {
        display: inline-block;
        padding: 8px 16px;
        background-color: #004A87;
        color: white;
        text-decoration: none;
        border-radius: 4px;
        margin-top: 15px;
    }
    .step {
        margin-bottom: 20px;
        padding: 10px;
        background-color: #f0f0f0;
        border-radius: 4px;
    }
    .step-success {
        border-left: 4px solid #28a745;
    }
    .step-error {
        border-left: 4px solid #dc3545;
    }
</style>
";

echo "<div class='container'>";
echo "<h1>Database Setup</h1>";
echo "<p>This script will set up the database and tables needed for the Bradford Council Auth System.</p>";

// Function to display a setup step
function displayStep($number, $description, $success, $message) {
    $statusClass = $success ? 'step-success' : 'step-error';
    $statusMessage = $success ? 'Success' : 'Error';
    
    echo "<div class='step $statusClass'>";
    echo "<strong>Step $number: $description - $statusMessage</strong>";
    echo "<p>$message</p>";
    echo "</div>";
    
    return $success;
}

try {
    // Step 1: Connect to MySQL server
    $success = true;
    $message = '';
    
    try {
        $pdo_connect = new PDO("mysql:host=$host", $username, $password);
        $pdo_connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $message = "Successfully connected to MySQL server.";
    } catch (PDOException $e) {
        $success = false;
        $message = "Error connecting to MySQL: " . $e->getMessage();
    }
    
    $step1 = displayStep(1, "Connect to MySQL server", $success, $message);
    
    if (!$step1) {
        throw new Exception("Failed to connect to MySQL server. Please check your MySQL connection settings.");
    }
    
    // Step 2: Create database if it doesn't exist
    $success = true;
    $message = '';
    
    try {
        $stmt = $pdo_connect->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$dbname'");
        $dbExists = $stmt->fetchColumn();
        
        if (!$dbExists) {
            $pdo_connect->exec("CREATE DATABASE `$dbname` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $message = "Database '$dbname' created successfully.";
        } else {
            $message = "Database '$dbname' already exists.";
        }
    } catch (PDOException $e) {
        $success = false;
        $message = "Error creating database: " . $e->getMessage();
    }
    
    $step2 = displayStep(2, "Create database", $success, $message);
    
    if (!$step2) {
        throw new Exception("Failed to create the database. Please check your MySQL permissions.");
    }
    
    // Step 3: Connect to the database and create tables
    $success = true;
    $message = '';
    
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $message = "Successfully connected to the database '$dbname'.";
    } catch (PDOException $e) {
        $success = false;
        $message = "Error connecting to database: " . $e->getMessage();
    }
    
    $step3 = displayStep(3, "Connect to database", $success, $message);
    
    if (!$step3) {
        throw new Exception("Failed to connect to the database after creating it. Please check your database settings.");
    }
    
    // Step 4: Create users table
    $success = true;
    $message = '';
    
    try {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `users` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `username` varchar(50) NOT NULL,
                `password` varchar(255) NOT NULL,
                `email` varchar(100) NOT NULL,
                `role` enum('user','admin','manager','staff') NOT NULL DEFAULT 'user',
                `department` varchar(100) DEFAULT NULL,
                `active` tinyint(1) NOT NULL DEFAULT '1',
                `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `username` (`username`),
                UNIQUE KEY `email` (`email`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
        $message = "Table 'users' created successfully.";
    } catch (PDOException $e) {
        $success = false;
        $message = "Error creating users table: " . $e->getMessage();
    }
    
    $step4 = displayStep(4, "Create users table", $success, $message);
    
    // Step 5: Create assets table
    $success = true;
    $message = '';
    
    try {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `assets` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `name` varchar(100) NOT NULL,
                `asset_type` varchar(50) DEFAULT NULL,
                `latitude` decimal(10,6) DEFAULT NULL,
                `longitude` decimal(10,6) DEFAULT NULL,
                `description` text,
                `department` varchar(100) DEFAULT NULL,
                `owner` varchar(50) DEFAULT NULL,
                `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
        $message = "Table 'assets' created successfully.";
    } catch (PDOException $e) {
        $success = false;
        $message = "Error creating assets table: " . $e->getMessage();
    }
    
    $step5 = displayStep(5, "Create assets table", $success, $message);
    
    // Step 6: Create logs table
    $success = true;
    $message = '';
    
    try {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `logs` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `username` varchar(50) DEFAULT NULL,
                `action` varchar(255) NOT NULL,
                `ip_address` varchar(45) DEFAULT NULL,
                `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
        $message = "Table 'logs' created successfully.";
    } catch (PDOException $e) {
        $success = false;
        $message = "Error creating logs table: " . $e->getMessage();
    }
    
    $step6 = displayStep(6, "Create logs table", $success, $message);
    
    // Step 7: Create map_styles table
    $success = true;
    $message = '';
    
    try {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `map_styles` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `name` varchar(50) NOT NULL,
                `style_json` text NOT NULL,
                `description` varchar(255) DEFAULT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
        
        // Insert default map styles if table is empty
        $stmt = $pdo->query("SELECT COUNT(*) FROM map_styles");
        $count = $stmt->fetchColumn();
        
        if ($count == 0) {
            $styles = [
                [
                    'name' => 'Standard',
                    'style_json' => '{"baseLayer": "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", "attribution": "&copy; OpenStreetMap contributors"}',
                    'description' => 'Standard OpenStreetMap style'
                ],
                [
                    'name' => 'Satellite',
                    'style_json' => '{"baseLayer": "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", "attribution": "Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community"}',
                    'description' => 'Satellite imagery'
                ],
                [
                    'name' => 'Dark',
                    'style_json' => '{"baseLayer": "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", "attribution": "&copy; OpenStreetMap contributors, &copy; CARTO"}',
                    'description' => 'Dark theme map'
                ]
            ];
            
            $stmt = $pdo->prepare("INSERT INTO map_styles (name, style_json, description) VALUES (?, ?, ?)");
            foreach ($styles as $style) {
                $stmt->execute([$style['name'], $style['style_json'], $style['description']]);
            }
            
            $message = "Table 'map_styles' created and populated with default styles.";
        } else {
            $message = "Table 'map_styles' created successfully.";
        }
    } catch (PDOException $e) {
        $success = false;
        $message = "Error creating map_styles table: " . $e->getMessage();
    }
    
    $step7 = displayStep(7, "Create map_styles table", $success, $message);
    
    // Step 8: Create user_settings table
    $success = true;
    $message = '';
    
    try {
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `user_settings` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `user_id` int(11) NOT NULL,
                `preferred_map_style` int(11) NOT NULL DEFAULT '1',
                `default_location_lat` decimal(10,6) NOT NULL DEFAULT '53.796030',
                `default_location_lng` decimal(10,6) NOT NULL DEFAULT '-1.759390',
                `default_zoom` int(11) NOT NULL DEFAULT '13',
                PRIMARY KEY (`id`),
                UNIQUE KEY `user_id` (`user_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        ");
        $message = "Table 'user_settings' created successfully.";
    } catch (PDOException $e) {
        $success = false;
        $message = "Error creating user_settings table: " . $e->getMessage();
    }
    
    $step8 = displayStep(8, "Create user_settings table", $success, $message);
    
    // Step 9: Create default admin user
    $success = true;
    $message = '';
    
    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'");
        $adminExists = $stmt->fetchColumn();
        
        if ($adminExists == 0) {
            $defaultAdminUsername = 'admin';
            $defaultAdminPassword = password_hash('admin123', PASSWORD_DEFAULT);
            $defaultAdminEmail = 'admin@example.com';
            
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'admin')");
            $stmt->execute([$defaultAdminUsername, $defaultAdminEmail, $defaultAdminPassword]);
            
            $message = "Default admin user created:<br>Username: <strong>admin</strong><br>Password: <strong>admin123</strong><br><span style='color: red; font-weight: bold;'>Please change this password immediately after logging in!</span>";
        } else {
            $message = "Admin user already exists.";
        }
    } catch (PDOException $e) {
        $success = false;
        $message = "Error creating admin user: " . $e->getMessage();
    }
    
    $step9 = displayStep(9, "Create default admin user", $success, $message);
    
    // Display overall status
    if ($step1 && $step2 && $step3 && $step4 && $step5 && $step6 && $step7 && $step8 && $step9) {
        echo "<div class='success'>";
        echo "<h2>🎉 Database Setup Completed Successfully!</h2>";
        echo "<p>All database tables have been created. You can now use the system.</p>";
        echo "</div>";
    } else {
        echo "<div class='error'>";
        echo "<h2>⚠️ Database Setup Incomplete</h2>";
        echo "<p>Some steps failed during the setup. Please check the errors above and try again.</p>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div class='error'>";
    echo "<h2>⚠️ Setup Failed</h2>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "<a href='login.php' class='btn'>Go to Login Page</a>";
echo "</div>";
?>
