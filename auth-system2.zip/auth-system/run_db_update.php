<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start a session to check if the user is logged in as admin
session_start();

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Include database connection
require 'db.php';

// First, check if tables exist and create them if they don't
$createTableStatements = [
    // Users table - needed for admin authentication and user management
    "CREATE TABLE IF NOT EXISTS `users` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `username` varchar(50) NOT NULL,
        `password` varchar(255) NOT NULL,
        `email` varchar(100) NOT NULL,
        `role` varchar(20) NOT NULL DEFAULT 'user',
        `active` tinyint(1) NOT NULL DEFAULT 1,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `username` (`username`),
        UNIQUE KEY `email` (`email`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    
    // Assets table - needed for asset management in admin dashboard
    "CREATE TABLE IF NOT EXISTS `assets` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(100) NOT NULL,
        `owner` varchar(50) DEFAULT NULL,
        `latitude` decimal(10,6) DEFAULT NULL,
        `longitude` decimal(10,6) DEFAULT NULL,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    
    // Logs table - needed for activity tracking in admin dashboard
    "CREATE TABLE IF NOT EXISTS `logs` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `username` varchar(50) DEFAULT NULL,
        `action` varchar(255) NOT NULL,
        `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    
    // Admin settings table - for storing dashboard configuration
    "CREATE TABLE IF NOT EXISTS `admin_settings` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `setting_name` varchar(50) NOT NULL,
        `setting_value` text DEFAULT NULL,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `setting_name` (`setting_name`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
];

// Execute the create table statements first
$tableResults = [];
$tableSuccess = 0;
$tableErrors = 0;

foreach ($createTableStatements as $sql) {
    try {
        $pdo->exec($sql);
        $tableResults[] = [
            'status' => 'success',
            'message' => "Table created or already exists"
        ];
        $tableSuccess++;
    } catch (PDOException $e) {
        $tableResults[] = [
            'status' => 'error',
            'message' => "Error creating table",
            'error' => $e->getMessage()
        ];
        $tableErrors++;
    }
}

// SQL statements to update the database structure
$sql_statements = [
    // Users table updates
    "ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `department` VARCHAR(100) DEFAULT NULL",
    
    // Assets table updates
    "ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `asset_type` VARCHAR(50) DEFAULT 'generic'",
    "ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `department` VARCHAR(100) DEFAULT NULL",
    "ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `description` TEXT DEFAULT NULL",
    
    // Logs table updates
    "ALTER TABLE `logs` ADD COLUMN IF NOT EXISTS `ip_address` VARCHAR(45) DEFAULT NULL",
    
    // Make sure the active column exists in users
    "ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `active` TINYINT(1) DEFAULT 1",
    
    // Add updated_at column to users if it doesn't exist
    "ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP",
    
    // Add indexes for better performance
    "ALTER TABLE `assets` ADD INDEX IF NOT EXISTS `idx_asset_type` (`asset_type`)",
    "ALTER TABLE `assets` ADD INDEX IF NOT EXISTS `idx_department` (`department`)",
    "ALTER TABLE `assets` ADD INDEX IF NOT EXISTS `idx_owner` (`owner`)"
];

$results = [];
$success_count = 0;
$error_count = 0;

// Execute each SQL statement
foreach ($sql_statements as $sql) {
    try {
        $pdo->exec($sql);
        $results[] = [
            'status' => 'success',
            'message' => "Successfully executed: " . $sql
        ];
        $success_count++;
    } catch (PDOException $e) {
        $results[] = [
            'status' => 'error',
            'message' => "Error executing: " . $sql,
            'error' => $e->getMessage()
        ];
        $error_count++;
    }
}

// Add additional security and compliance features to the users table
try {
    // Add columns for enhanced security
    $pdo->exec("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `last_login` TIMESTAMP NULL DEFAULT NULL");
    $pdo->exec("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `login_attempts` INT NOT NULL DEFAULT 0");
    $pdo->exec("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `locked_until` TIMESTAMP NULL DEFAULT NULL");
    
    // Add password reset functionality
    $pdo->exec("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `reset_token` VARCHAR(100) DEFAULT NULL");
    $pdo->exec("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `reset_expires` TIMESTAMP NULL DEFAULT NULL");
    
    // Add email verification support
    $pdo->exec("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `email_verified` TINYINT(1) NOT NULL DEFAULT 0");
    $pdo->exec("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `verification_token` VARCHAR(100) DEFAULT NULL");
    
    // Add two-factor authentication support
    $pdo->exec("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `two_factor_enabled` TINYINT(1) NOT NULL DEFAULT 0");
    $pdo->exec("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `two_factor_secret` VARCHAR(100) DEFAULT NULL");
    
    // Add GDPR compliance features
    $pdo->exec("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `terms_accepted` TINYINT(1) NOT NULL DEFAULT 0");
    $pdo->exec("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `terms_accepted_date` TIMESTAMP NULL DEFAULT NULL");
    $pdo->exec("ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `data_processing_consent` TINYINT(1) NOT NULL DEFAULT 0");
    
    // Add index for faster login attempts monitoring
    $pdo->exec("ALTER TABLE `users` ADD INDEX IF NOT EXISTS `idx_login_security` (`username`, `login_attempts`, `locked_until`)");
    
    $results[] = [
        'status' => 'success',
        'message' => "Added enhanced security and compliance features to users table"
    ];
    $success_count++;
} catch (PDOException $e) {
    $results[] = [
        'status' => 'error',
        'message' => "Error adding security enhancements to users table",
        'error' => $e->getMessage()
    ];
    $error_count++;
}

// Check if admin user exists, create if not
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin'");
    $stmt->execute();
    $adminCount = $stmt->fetchColumn();
    
    if ($adminCount == 0) {
        // Create default admin user if none exists
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'admin')");
        $stmt->execute(['admin', 'admin@example.com', password_hash('admin123', PASSWORD_DEFAULT)]);
        $results[] = [
            'status' => 'success',
            'message' => "Created default admin user (username: admin, password: admin123)"
        ];
        $success_count++;
    }
} catch (PDOException $e) {
    $results[] = [
        'status' => 'error',
        'message' => "Error checking/creating admin user",
        'error' => $e->getMessage()
    ];
    $error_count++;
}

// Try to add full-text search if supported by MySQL version
try {
    // First, add the regular column for search text
    $pdo->exec("ALTER TABLE `assets` ADD COLUMN IF NOT EXISTS `search_text` TEXT DEFAULT NULL");
    
    // Create/update triggers to maintain the search_text column
    $pdo->exec("DROP TRIGGER IF EXISTS before_asset_insert");
    $pdo->exec("DROP TRIGGER IF EXISTS before_asset_update");
    
    // Create trigger for INSERT operations
    $pdo->exec("
        CREATE TRIGGER before_asset_insert
        BEFORE INSERT ON assets
        FOR EACH ROW
        SET NEW.search_text = CONCAT_WS(' ', NEW.name, NEW.asset_type, NEW.department, NEW.description, NEW.owner)
    ");
    
    // Create trigger for UPDATE operations
    $pdo->exec("
        CREATE TRIGGER before_asset_update
        BEFORE UPDATE ON assets
        FOR EACH ROW
        SET NEW.search_text = CONCAT_WS(' ', NEW.name, NEW.asset_type, NEW.department, NEW.description, NEW.owner)
    ");
    
    // Update existing records
    $pdo->exec("UPDATE assets SET search_text = CONCAT_WS(' ', name, asset_type, department, description, owner)");
    
    // Add fulltext index
    $pdo->exec("ALTER TABLE `assets` ADD FULLTEXT INDEX IF NOT EXISTS `idx_search` (`search_text`)");
    
    $results[] = [
        'status' => 'success',
        'message' => "Successfully added full-text search using triggers (compatible approach)"
    ];
    $success_count++;
} catch (PDOException $e) {
    $results[] = [
        'status' => 'error',
        'message' => "Could not add full-text search (this is optional)",
        'error' => $e->getMessage()
    ];
    $error_count++;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Setup and Update</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <?php dbStatusStyles(); ?>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
            background-color: #004A87;
            color: white;
            padding: 15px 20px;
            border-radius: 6px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .success-count {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .error-count {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .result-item {
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 4px;
        }
        .result-success {
            background-color: #f1f9f1;
            border-left: 4px solid #28a745;
        }
        .result-error {
            background-color: #fdf6f6;
            border-left: 4px solid #dc3545;
        }
        .error-details {
            font-family: monospace;
            background-color: #f8f8f8;
            padding: 8px;
            margin-top: 5px;
            border-radius: 4px;
            font-size: 12px;
        }
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background-color: #004A87;
            color: white;
        }
        .btn-primary:hover {
            background-color: #003366;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Database Setup and Update</h1>
        </div>
        
        <!-- Database Connection Status Indicator -->
        <?php renderDbStatusBar(); ?>
        
        <div class="success-count">
            <strong>Tables created/verified:</strong> <?php echo $tableSuccess; ?> tables
        </div>
        
        <?php if ($tableErrors > 0): ?>
        <div class="error-count">
            <strong>Errors creating tables:</strong> <?php echo $tableErrors; ?> tables
        </div>
        <?php endif; ?>
        
        <div class="success-count">
            <strong>Updates executed:</strong> <?php echo $success_count; ?> operations
        </div>
        
        <?php if ($error_count > 0): ?>
        <div class="error-count">
            <strong>Update errors:</strong> <?php echo $error_count; ?> operations
        </div>
        <?php endif; ?>
        
        <h2>Table Creation Results</h2>
        
        <?php foreach ($tableResults as $index => $result): ?>
        <div class="result-item result-<?php echo $result['status']; ?>">
            <p>
                <?php if ($result['status'] === 'success'): ?>
                    <i class="fas fa-check-circle" style="color: #28a745;"></i>
                <?php else: ?>
                    <i class="fas fa-exclamation-triangle" style="color: #dc3545;"></i>
                <?php endif; ?>
                Table #<?php echo $index + 1; ?>: <?php echo $result['message']; ?>
            </p>
            
            <?php if (isset($result['error'])): ?>
            <div class="error-details">
                <?php echo $result['error']; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        
        <h2>Column Update Results</h2>
        
        <?php foreach ($results as $result): ?>
        <div class="result-item result-<?php echo $result['status']; ?>">
            <p>
                <?php if ($result['status'] === 'success'): ?>
                    <i class="fas fa-check-circle" style="color: #28a745;"></i>
                <?php else: ?>
                    <i class="fas fa-exclamation-triangle" style="color: #dc3545;"></i>
                <?php endif; ?>
                <?php echo $result['message']; ?>
            </p>
            
            <?php if (isset($result['error'])): ?>
            <div class="error-details">
                <?php echo $result['error']; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        
        <div style="margin-top: 20px; text-align: center;">
            <a href="simple-admin.php" class="btn btn-primary">Go to Simple Admin Dashboard</a>
            <a href="user-management.php" class="btn btn-primary">Back to User Management</a>
            <a href="diagnose.php" class="btn btn-primary">Run Diagnostics</a>
        </div>
    </div>
</body>
</html>
