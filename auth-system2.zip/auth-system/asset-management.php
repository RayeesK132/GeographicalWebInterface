<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Include database connection
require 'db.php';

// Verify if the database connection is working
try {
    $testQuery = $pdo->query("SELECT 1");
    // Connection is working
} catch (PDOException $e) {
    die("Database connection error: " . $e->getMessage());
}

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Default sort column and order
$sortColumn = isset($_GET['sort']) ? $_GET['sort'] : 'name';
$sortOrder = isset($_GET['order']) ? $_GET['order'] : 'ASC';
$search = isset($_GET['search']) ? $_GET['search'] : '';
$typeFilter = isset($_GET['type']) ? $_GET['type'] : '';
$departmentFilter = isset($_GET['department']) ? $_GET['department'] : '';

// Initialize assets array to prevent undefined variable error
$assets = [];

// Build the query with filters
try {
    if (!empty($search)) {
        $query = "SELECT a.*, u.username as owner_name 
                  FROM assets a 
                  LEFT JOIN users u ON a.owner = u.username
                  WHERE (a.name LIKE :search1 
                     OR a.asset_type LIKE :search2 
                     OR a.department LIKE :search3
                     OR a.owner LIKE :search4
                     OR a.description LIKE :search5)";
        
        $params = [
            ':search1' => "%$search%",
            ':search2' => "%$search%",
            ':search3' => "%$search%",
            ':search4' => "%$search%",
            ':search5' => "%$search%"
        ];
    } else {
        // If no search term, fetch all assets
        $query = "SELECT a.*, u.username as owner_name 
                  FROM assets a 
                  LEFT JOIN users u ON a.owner = u.username
                  WHERE 1=1";
        $params = [];
    }
    
    // Add type filter if specified
    if (!empty($typeFilter)) {
        $query .= " AND a.asset_type = :asset_type";
        $params[':asset_type'] = $typeFilter;
    }
    
    // Add department filter if specified
    if (!empty($departmentFilter)) {
        $query .= " AND a.department = :department";
        $params[':department'] = $departmentFilter;
    }
    
    // Add order by clause
    $query .= " ORDER BY $sortColumn $sortOrder";
    
    $stmt = $pdo->prepare($query);
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->execute();
    $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($assets === false) {
        $error = "Error fetching assets data";
        $assets = []; // Ensure assets is an empty array
    }
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
    $assets = []; // Ensure assets is an empty array
}

// Get all asset types for filter
try {
    $stmt = $pdo->query("SELECT DISTINCT asset_type FROM assets WHERE asset_type IS NOT NULL ORDER BY asset_type");
    $assetTypes = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $assetTypes = ['generic'];
}

// Get all departments for filter
try {
    $stmt = $pdo->query("SELECT DISTINCT department FROM assets WHERE department IS NOT NULL ORDER BY department");
    $departments = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $departments = [];
}

// Handle asset actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update':
                // Update asset
                $assetId = $_POST['asset_id'];
                $name = $_POST['name'];
                $assetType = $_POST['asset_type'];
                $department = $_POST['department'];
                $description = $_POST['description'];
                $latitude = $_POST['latitude'];
                $longitude = $_POST['longitude'];
                
                try {
                    // Check if any fields are empty and handle properly
                    $emptyFields = [];
                    if (empty($department)) $emptyFields[] = 'department';
                    if (empty($description)) $emptyFields[] = 'description';
                    if (empty($latitude)) $emptyFields[] = 'latitude';
                    if (empty($longitude)) $emptyFields[] = 'longitude';
                    
                    // Construct SQL based on which fields are empty
                    $sql = "UPDATE assets SET name = ?, asset_type = ?";
                    $params = [$name, $assetType];
                    
                    if (!in_array('department', $emptyFields)) {
                        $sql .= ", department = ?";
                        $params[] = $department;
                    } else {
                        $sql .= ", department = NULL";
                    }
                    
                    if (!in_array('description', $emptyFields)) {
                        $sql .= ", description = ?";
                        $params[] = $description;
                    } else {
                        $sql .= ", description = NULL";
                    }
                    
                    if (!in_array('latitude', $emptyFields)) {
                        $sql .= ", latitude = ?";
                        $params[] = $latitude;
                    } else {
                        $sql .= ", latitude = NULL";
                    }
                    
                    if (!in_array('longitude', $emptyFields)) {
                        $sql .= ", longitude = ?";
                        $params[] = $longitude;
                    } else {
                        $sql .= ", longitude = NULL";
                    }
                    
                    $sql .= " WHERE id = ?";
                    $params[] = $assetId;
                    
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($params);
                    
                    $success = "Asset updated successfully!";
                } catch (PDOException $e) {
                    $error = "Error updating asset: " . $e->getMessage();
                }
                break;
                
            case 'delete':
                // Delete asset
                $assetId = $_POST['asset_id'];
                
                try {
                    $stmt = $pdo->prepare("DELETE FROM assets WHERE id = ?");
                    $stmt->execute([$assetId]);
                    $success = "Asset deleted successfully!";
                } catch (PDOException $e) {
                    $error = "Error deleting asset: " . $e->getMessage();
                }
                break;
                
            case 'create':
                // Create asset
                $name = $_POST['name'];
                $assetType = $_POST['asset_type'];
                $department = $_POST['department'];
                $description = $_POST['description'];
                $latitude = $_POST['latitude'];
                $longitude = $_POST['longitude'];
                $owner = $_SESSION['username'];
                
                try {
                    // Check if any fields are empty and handle properly
                    $emptyFields = [];
                    if (empty($department)) $emptyFields[] = 'department';
                    if (empty($description)) $emptyFields[] = 'description';
                    if (empty($latitude)) $emptyFields[] = 'latitude';
                    if (empty($longitude)) $emptyFields[] = 'longitude';
                    
                    // Construct column names and placeholders
                    $columns = "name, asset_type";
                    $placeholders = "?, ?";
                    $params = [$name, $assetType];
                    
                    if (!in_array('department', $emptyFields)) {
                        $columns .= ", department";
                        $placeholders .= ", ?";
                        $params[] = $department;
                    }
                    
                    if (!in_array('description', $emptyFields)) {
                        $columns .= ", description";
                        $placeholders .= ", ?";
                        $params[] = $description;
                    }
                    
                    if (!in_array('latitude', $emptyFields)) {
                        $columns .= ", latitude";
                        $placeholders .= ", ?";
                        $params[] = $latitude;
                    }
                    
                    if (!in_array('longitude', $emptyFields)) {
                        $columns .= ", longitude";
                        $placeholders .= ", ?";
                        $params[] = $longitude;
                    }
                    
                    $columns .= ", owner";
                    $placeholders .= ", ?";
                    $params[] = $owner;
                    
                    $sql = "INSERT INTO assets ($columns) VALUES ($placeholders)";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($params);
                    
                    $success = "Asset created successfully!";
                } catch (PDOException $e) {
                    $error = "Error creating asset: " . $e->getMessage();
                }
                break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asset Management - Bradford Council</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css">
    <?php dbStatusStyles(); ?>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .panel {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .panel-header {
            background-color: #004A87;
            color: white;
            padding: 15px 20px;
            font-size: 1.2em;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .panel-body {
            padding: 20px;
        }
        
        .panel-title {
            margin: 0;
        }
        
        .asset-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .asset-table th, .asset-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .asset-table th {
            background-color: #f8f9fa;
            font-weight: bold;
            cursor: pointer;
        }
        
        .asset-table th:hover {
            background-color: #e9ecef;
        }
        
        .asset-table tr:hover {
            background-color: #f1f1f1;
        }
        
        .asset-table .actions {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.2s;
        }
        
        .btn-primary {
            background-color: #004A87;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #003366;
        }
        
        .btn-success {
            background-color: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background-color: #218838;
        }
        
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c82333;
        }
        
        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        
        .search-bar {
            display: flex;
            padding: 10px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #ddd;
        }
        
        .search-bar input {
            flex: 1;
            padding: 8px 12px;
            border: 1px solid #ced4da;
            border-radius: 4px 0 0 4px;
        }
        
        .search-bar button {
            padding: 8px 15px;
            border: 1px solid #004A87;
            background-color: #004A87;
            color: white;
            border-radius: 0 4px 4px 0;
            cursor: pointer;
        }
        
        .filter-container {
            display: flex;
            padding: 10px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #ddd;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .filter-container select {
            padding: 8px 12px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            flex-grow: 1;
        }
        
        .filter-container button {
            padding: 8px 15px;
            border: 1px solid #004A87;
            background-color: #004A87;
            color: white;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .toggle-container {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            gap: 20px;
        }
        
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 30px;
        }
        
        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }
        
        .toggle-slider:before {
            position: absolute;
            content: "";
            height: 22px;
            width: 22px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }
        
        input:checked + .toggle-slider {
            background-color: #004A87;
        }
        
        input:checked + .toggle-slider:before {
            transform: translateX(30px);
        }
        
        .toggle-label {
            font-size: 14px;
            font-weight: bold;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 8px;
            width: 70%;
            max-width: 700px;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        
        .modal-title {
            margin: 0;
            font-size: 1.5em;
        }
        
        .close {
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .form-group textarea {
            min-height: 100px;
        }
        
        .form-row {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .form-row .form-group {
            flex: 1;
            margin-bottom: 0;
        }
        
        .asset-details {
            display: none;
            padding: 15px;
            background-color: #f8f9fa;
            border-top: 1px solid #ddd;
        }
        
        .detail-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
        }
        
        .detail-item {
            margin-bottom: 10px;
        }
        
        .detail-label {
            font-weight: bold;
            color: #6c757d;
            font-size: 0.9em;
        }
        
        .detail-value {
            font-size: 1.1em;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .sort-icon {
            margin-left: 5px;
        }
        
        .expand-row {
            cursor: pointer;
            font-size: 1.2em;
            color: #004A87;
        }
        
        .map-container {
            height: 300px;
            margin-bottom: 15px;
        }
        
        .coordinates {
            font-family: monospace;
            background-color: #f8f9fa;
            padding: 5px;
            border-radius: 4px;
            border: 1px solid #ddd;
            margin-top: 5px;
        }
        
        .asset-icon {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 5px;
        }
        
        .asset-type-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
            color: white;
        }
        
        .location-view {
            cursor: pointer;
            color: #004A87;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="panel">
            <div class="panel-header">
                <h2 class="panel-title">Asset Management</h2>
                <button class="btn btn-success" onclick="openCreateModal()">Add New Asset</button>
            </div>
            
            <!-- Database Connection Status Indicator -->
            <?php renderDbStatusBar(); ?>
            
            <div class="search-bar">
                <input type="text" id="searchInput" placeholder="Search by name, type, department, or description..." value="<?php echo htmlspecialchars($search); ?>">
                <button onclick="searchAssets()"><i class="fas fa-search"></i></button>
            </div>
            
            <div class="filter-container">
                <select id="typeFilter">
                    <option value="">All Asset Types</option>
                    <?php foreach ($assetTypes as $type): ?>
                        <option value="<?php echo htmlspecialchars($type); ?>" <?php echo ($type === $typeFilter) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars(ucfirst($type)); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <select id="departmentFilter">
                    <option value="">All Departments</option>
                    <?php foreach ($departments as $dept): ?>
                        <option value="<?php echo htmlspecialchars($dept); ?>" <?php echo ($dept === $departmentFilter) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dept); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <button onclick="applyFilters()">Apply Filters</button>
                <button onclick="resetFilters()" class="btn-secondary">Reset</button>
            </div>
            
            <div class="panel-body">
                <?php if (isset($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <div class="toggle-container">
                    <div>
                        <label class="toggle-switch">
                            <input type="checkbox" id="showLocation" onchange="toggleLocationColumns()">
                            <span class="toggle-slider"></span>
                        </label>
                        <span class="toggle-label">Show Location Data</span>
                    </div>
                    
                    <div>
                        <label class="toggle-switch">
                            <input type="checkbox" id="showDetails" onchange="toggleAllDetails()">
                            <span class="toggle-slider"></span>
                        </label>
                        <span class="toggle-label">Show All Details</span>
                    </div>
                </div>
                
                <table class="asset-table" id="assetTable">
                    <thead>
                        <tr>
                            <th width="40px"></th>
                            <th onclick="sortTable('name')">Name <?php echo getSortIcon('name'); ?></th>
                            <th onclick="sortTable('asset_type')">Type <?php echo getSortIcon('asset_type'); ?></th>
                            <th onclick="sortTable('department')">Department <?php echo getSortIcon('department'); ?></th>
                            <th onclick="sortTable('owner')">Owner <?php echo getSortIcon('owner'); ?></th>
                            <th class="location-column" style="display:none" onclick="sortTable('latitude')">Location <?php echo getSortIcon('latitude'); ?></th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($assets as $asset): ?>
                            <tr>
                                <td class="expand-row" onclick="toggleDetails(<?php echo $asset['id']; ?>)">
                                    <i class="fas fa-chevron-down" id="icon-<?php echo $asset['id']; ?>"></i>
                                </td>
                                <td><?php echo htmlspecialchars($asset['name']); ?></td>
                                <td>
                                    <span class="asset-type-badge" style="background-color: <?php echo getColorForAssetType($asset['asset_type']); ?>">
                                        <?php echo htmlspecialchars(ucfirst($asset['asset_type'] ?? 'Generic')); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($asset['department'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($asset['owner_name'] ?? 'N/A'); ?></td>
                                <td class="location-column" style="display:none">
                                    <?php if (!empty($asset['latitude']) && !empty($asset['longitude'])): ?>
                                        <span class="location-view" onclick="viewOnMap(<?php echo $asset['latitude']; ?>, <?php echo $asset['longitude']; ?>, '<?php echo htmlspecialchars(addslashes($asset['name'])); ?>')">
                                            <i class="fas fa-map-marker-alt"></i> View on Map
                                        </span>
                                    <?php else: ?>
                                        <span>No location data</span>
                                    <?php endif; ?>
                                </td>
                                <td class="actions">
                                    <button class="btn btn-primary" onclick="openEditModal(<?php echo htmlspecialchars(json_encode($asset)); ?>)">Edit</button>
                                    <button class="btn btn-danger" onclick="confirmDelete(<?php echo $asset['id']; ?>, '<?php echo htmlspecialchars(addslashes($asset['name'])); ?>')">Delete</button>
                                </td>
                            </tr>
                            <tr id="details-<?php echo $asset['id']; ?>" style="display:none">
                                <td colspan="7">
                                    <div class="asset-details">
                                        <div class="detail-grid">
                                            <div class="detail-item">
                                                <div class="detail-label">Asset ID</div>
                                                <div class="detail-value"><?php echo $asset['id']; ?></div>
                                            </div>
                                            <?php if (!empty($asset['description'])): ?>
                                                <div class="detail-item" style="grid-column: 1 / -1;">
                                                    <div class="detail-label">Description</div>
                                                    <div class="detail-value"><?php echo nl2br(htmlspecialchars($asset['description'])); ?></div>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($asset['latitude']) && !empty($asset['longitude'])): ?>
                                                <div class="detail-item" style="grid-column: 1 / -1;">
                                                    <div class="detail-label">Location</div>
                                                    <div class="detail-value coordinates">Lat: <?php echo $asset['latitude']; ?>, Lng: <?php echo $asset['longitude']; ?></div>
                                                    <div id="map-<?php echo $asset['id']; ?>" class="map-container"></div>
                                                    <script>
                                                        document.addEventListener('DOMContentLoaded', function() {
                                                            document.getElementById('details-<?php echo $asset['id']; ?>').addEventListener('show', function() {
                                                                setTimeout(function() {
                                                                    initMap(<?php echo $asset['id']; ?>, <?php echo $asset['latitude']; ?>, <?php echo $asset['longitude']; ?>, '<?php echo htmlspecialchars(addslashes($asset['name'])); ?>');
                                                                }, 100);
                                                            });
                                                        });
                                                    </script>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($asset['created_at'])): ?>
                                                <div class="detail-item">
                                                    <div class="detail-label">Created At</div>
                                                    <div class="detail-value">
                                                        <?php echo date('Y-m-d H:i', strtotime($asset['created_at'])); ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($asset['updated_at'])): ?>
                                                <div class="detail-item">
                                                    <div class="detail-label">Last Updated</div>
                                                    <div class="detail-value">
                                                        <?php echo date('Y-m-d H:i', strtotime($asset['updated_at'])); ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <?php if (empty($assets)): ?>
                    <p class="text-center">No assets found. Try changing your search or filters.</p>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="panel">
            <div class="panel-header">
                <h3 class="panel-title">Asset Statistics</h3>
            </div>
            <div class="panel-body">
                <div style="display: flex; flex-wrap: wrap; gap: 20px;">
                    <div style="flex: 1; min-width: 200px; max-height: 300px;">
                        <h4>Assets by Type</h4>
                        <div style="height: 250px; position: relative;">
                            <canvas id="typeChart"></canvas>
                        </div>
                    </div>
                    <div style="flex: 1; min-width: 200px; max-height: 300px;">
                        <h4>Assets by Department</h4>
                        <div style="height: 250px; position: relative;">
                            <canvas id="departmentChart"></canvas>
                        </div>
                    </div>
                    <div style="flex: 1; min-width: 200px; max-height: 300px;">
                        <h4>Asset Distribution by Owner</h4>
                        <div style="height: 250px; position: relative;">
                            <canvas id="ownerChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div style="text-align: center; margin-top: 20px;">
            <a href="admin-dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
        </div>
    </div>
    
    <!-- Map View Modal -->
    <div id="mapViewModal" class="modal">
        <div class="modal-content" style="max-width: 800px;">
            <div class="modal-header">
                <h3 class="modal-title" id="mapViewTitle">View Location</h3>
                <span class="close" onclick="closeModal('mapViewModal')">&times;</span>
            </div>
            <div id="mapViewContainer" style="height: 500px;"></div>
        </div>
    </div>
    
    <!-- Edit Asset Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Edit Asset</h3>
                <span class="close" onclick="closeModal('editModal')">&times;</span>
            </div>
            <form id="editAssetForm" method="post">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="asset_id" id="edit_asset_id">
                
                <div class="form-group">
                    <label for="edit_name">Asset Name:</label>
                    <input type="text" name="name" id="edit_name" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_asset_type">Asset Type:</label>
                        <select name="asset_type" id="edit_asset_type">
                            <?php foreach ($assetTypes as $type): ?>
                                <option value="<?php echo htmlspecialchars($type); ?>"><?php echo ucfirst(htmlspecialchars($type)); ?></option>
                            <?php endforeach; ?>
                            <option value="generic">Generic</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_department">Department:</label>
                        <select name="department" id="edit_department">
                            <option value="">-- Select Department --</option>
                            <?php foreach ($departments as $dept): ?>
                                <option value="<?php echo htmlspecialchars($dept); ?>"><?php echo htmlspecialchars($dept); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="edit_description">Description:</label>
                    <textarea name="description" id="edit_description"></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_latitude">Latitude:</label>
                        <input type="text" name="latitude" id="edit_latitude" pattern="[-+]?[0-9]*\.?[0-9]*" title="Enter a valid latitude">
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_longitude">Longitude:</label>
                        <input type="text" name="longitude" id="edit_longitude" pattern="[-+]?[0-9]*\.?[0-9]*" title="Enter a valid longitude">
                    </div>
                </div>
                
                <div id="edit_map_container" class="map-container"></div>
                
                <div style="text-align: right; margin-top: 15px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('editModal')">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Create Asset Modal -->
    <div id="createModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Create New Asset</h3>
                <span class="close" onclick="closeModal('createModal')">&times;</span>
            </div>
            <form id="createAssetForm" method="post">
                <input type="hidden" name="action" value="create">
                
                <div class="form-group">
                    <label for="create_name">Asset Name:</label>
                    <input type="text" name="name" id="create_name" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="create_asset_type">Asset Type:</label>
                        <select name="asset_type" id="create_asset_type">
                            <?php foreach ($assetTypes as $type): ?>
                                <option value="<?php echo htmlspecialchars($type); ?>"><?php echo ucfirst(htmlspecialchars($type)); ?></option>
                            <?php endforeach; ?>
                            <option value="generic">Generic</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="create_department">Department:</label>
                        <select name="department" id="create_department">
                            <option value="">-- Select Department --</option>
                            <?php foreach ($departments as $dept): ?>
                                <option value="<?php echo htmlspecialchars($dept); ?>"><?php echo htmlspecialchars($dept); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="create_description">Description:</label>
                    <textarea name="description" id="create_description"></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="create_latitude">Latitude:</label>
                        <input type="text" name="latitude" id="create_latitude" pattern="[-+]?[0-9]*\.?[0-9]*" title="Enter a valid latitude">
                    </div>
                    
                    <div class="form-group">
                        <label for="create_longitude">Longitude:</label>
                        <input type="text" name="longitude" id="create_longitude" pattern="[-+]?[0-9]*\.?[0-9]*" title="Enter a valid longitude">
                    </div>
                </div>
                
                <div id="create_map_container" class="map-container"></div>
                <p>Click on the map to set the location or enter coordinates manually.</p>
                
                <div style="text-align: right; margin-top: 15px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('createModal')">Cancel</button>
                    <button type="submit" class="btn btn-success">Create Asset</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content" style="max-width: 400px;">
            <div class="modal-header">
                <h3 class="modal-title">Confirm Delete</h3>
                <span class="close" onclick="closeModal('deleteModal')">&times;</span>
            </div>
            <p>Are you sure you want to delete the asset <strong id="delete_asset_name"></strong>?</p>
            <p>This action cannot be undone.</p>
            <form id="deleteAssetForm" method="post">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="asset_id" id="delete_asset_id">
                
                <div style="text-align: right;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('deleteModal')">Cancel</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Add error handling
        window.addEventListener('error', function(e) {
            console.error('JavaScript Error:', e.error);
        });
        
        // Ensure functions are available in global scope
        window.openCreateModal = function() {
            const modal = document.getElementById('createModal');
            if (modal) {
                modal.style.display = 'block';
                
                setTimeout(() => {
                    const lat = 53.796030; // Default to Bradford
                    const lng = -1.759390;
                    
                    if (typeof L !== 'undefined') {
                        window.createMap = L.map('create_map_container').setView([lat, lng], 15);
                        
                        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                            attribution: '&copy; OpenStreetMap contributors',
                            maxZoom: 19
                        }).addTo(window.createMap);
                        
                        // Add marker on click
                        window.createMap.on('click', function(e) {
                            const coords = e.latlng;
                            document.getElementById('create_latitude').value = coords.lat.toFixed(6);
                            document.getElementById('create_longitude').value = coords.lng.toFixed(6);
                            
                            if (window.createMarker) {
                                window.createMarker.setLatLng(coords);
                            } else {
                                window.createMarker = L.marker(coords, { draggable: true }).addTo(window.createMap);
                                window.createMarker.on('dragend', function(e) {
                                    const marker = e.target;
                                    const position = marker.getLatLng();
                                    document.getElementById('create_latitude').value = position.lat.toFixed(6);
                                    document.getElementById('create_longitude').value = position.lng.toFixed(6);
                                });
                            }
                        });
                    }
                }, 100);
            } else {
                console.error('createModal element not found');
            }
        };
        
        window.applyFilters = function() {
            const typeFilter = document.getElementById('typeFilter').value;
            const departmentFilter = document.getElementById('departmentFilter').value;
            const searchInput = document.getElementById('searchInput').value;
            
            window.location.href = `?sort=<?php echo $sortColumn; ?>&order=<?php echo $sortOrder; ?>&search=${encodeURIComponent(searchInput)}&type=${encodeURIComponent(typeFilter)}&department=${encodeURIComponent(departmentFilter)}`;
        };
        
        window.resetFilters = function() {
            window.location.href = `?sort=name&order=ASC`;
        };
    </script>
    
    <?php
    // PHP helper functions - moved outside JavaScript
    function getSortIcon($column) {
        global $sortColumn, $sortOrder;
        
        if ($sortColumn === $column) {
            return $sortOrder === 'ASC' ? '<i class="fas fa-sort-up sort-icon"></i>' : '<i class="fas fa-sort-down sort-icon"></i>';
        }
        
        return '<i class="fas fa-sort sort-icon"></i>';
    }
    
    function getColorForAssetType($type) {
        $colors = [
            'building' => '#1976D2',
            'park' => '#43A047',
            'school' => '#FF9800',
            'healthcare' => '#E53935',
            'infrastructure' => '#607D8B',
            'generic' => '#795548'
        ];
        
        return $colors[strtolower($type)] ?? '#004A87';
    }
    ?>
    
    <script>
        // Toggle location columns
        function toggleLocationColumns() {
            const locationColumns = document.querySelectorAll('.location-column');
            const showLocation = document.getElementById('showLocation').checked;
            
            locationColumns.forEach(column => {
                column.style.display = showLocation ? 'table-cell' : 'none';
            });
        }
        
        // Toggle asset details row
        function toggleDetails(assetId) {
            const detailsRow = document.getElementById(`details-${assetId}`);
            const icon = document.getElementById(`icon-${assetId}`);
            
            if (detailsRow.style.display === 'table-row') {
                detailsRow.style.display = 'none';
                icon.className = 'fas fa-chevron-down';
            } else {
                detailsRow.style.display = 'table-row';
                icon.className = 'fas fa-chevron-up';
                
                // Trigger show event for map initialization
                const event = new Event('show');
                detailsRow.dispatchEvent(event);
            }
        }
        
        // Toggle all details rows
        function toggleAllDetails() {
            const showDetails = document.getElementById('showDetails').checked;
            const assetIds = <?php echo json_encode(array_column($assets, 'id')); ?>;
            
            assetIds.forEach(assetId => {
                const detailsRow = document.getElementById(`details-${assetId}`);
                const icon = document.getElementById(`icon-${assetId}`);
                
                if (showDetails) {
                    detailsRow.style.display = 'table-row';
                    icon.className = 'fas fa-chevron-up';
                    
                    // Trigger show event for map initialization
                    const event = new Event('show');
                    detailsRow.dispatchEvent(event);
                } else {
                    detailsRow.style.display = 'none';
                    icon.className = 'fas fa-chevron-down';
                }
            });
        }
        
        // Sort table
        function sortTable(column) {
            const currentOrder = '<?php echo $sortOrder; ?>';
            const currentColumn = '<?php echo $sortColumn; ?>';
            
            let newOrder = 'ASC';
            if (column === currentColumn && currentOrder === 'ASC') {
                newOrder = 'DESC';
            }
            
            window.location.href = `?sort=${column}&order=${newOrder}&search=<?php echo urlencode($search); ?>&type=<?php echo urlencode($typeFilter); ?>&department=<?php echo urlencode($departmentFilter); ?>`;
        }
        
        // Search assets
        function searchAssets() {
            const searchInput = document.getElementById('searchInput').value;
            window.location.href = `?sort=<?php echo $sortColumn; ?>&order=<?php echo $sortOrder; ?>&search=${encodeURIComponent(searchInput)}&type=<?php echo urlencode($typeFilter); ?>&department=<?php echo urlencode($departmentFilter); ?>`;
        }
        
        // Apply filters
        function applyFilters() {
            const typeFilter = document.getElementById('typeFilter').value;
            const departmentFilter = document.getElementById('departmentFilter').value;
            const searchInput = document.getElementById('searchInput').value;
            
            window.location.href = `?sort=<?php echo $sortColumn; ?>&order=<?php echo $sortOrder; ?>&search=${encodeURIComponent(searchInput)}&type=${encodeURIComponent(typeFilter)}&department=${encodeURIComponent(departmentFilter)}`;
        }
        
        // Reset filters
        function resetFilters() {
            window.location.href = `?sort=name&order=ASC`;
        }
        
        // Initialize map for an asset
        function initMap(assetId, lat, lng, name) {
            const mapContainer = document.getElementById(`map-${assetId}`);
            
            if (!mapContainer) return;
            
            if (!mapContainer.hasAttribute('data-initialized')) {
                const map = L.map(mapContainer).setView([lat, lng], 15);
                
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; OpenStreetMap contributors',
                    maxZoom: 19
                }).addTo(map);
                
                L.marker([lat, lng]).addTo(map)
                    .bindPopup(name)
                    .openPopup();
                
                mapContainer.setAttribute('data-initialized', 'true');
            }
        }
        
        // View asset on map
        function viewOnMap(lat, lng, name) {
            const mapContainer = document.getElementById('mapViewContainer');
            document.getElementById('mapViewTitle').textContent = `View Location: ${name}`;
            
            document.getElementById('mapViewModal').style.display = 'block';
            
            setTimeout(() => {
                const map = L.map(mapContainer).setView([lat, lng], 15);
                
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; OpenStreetMap contributors',
                    maxZoom: 19
                }).addTo(map);
                
                L.marker([lat, lng]).addTo(map)
                    .bindPopup(name)
                    .openPopup();
            }, 100);
        }
        
        // Modal functions
        let editMap, createMap, editMarker, createMarker;
        
        function openEditModal(asset) {
            document.getElementById('edit_asset_id').value = asset.id;
            document.getElementById('edit_name').value = asset.name;
            document.getElementById('edit_asset_type').value = asset.asset_type || 'generic';
            document.getElementById('edit_department').value = asset.department || '';
            document.getElementById('edit_description').value = asset.description || '';
            document.getElementById('edit_latitude').value = asset.latitude || '';
            document.getElementById('edit_longitude').value = asset.longitude || '';
            
            document.getElementById('editModal').style.display = 'block';
            
            setTimeout(() => {
                const lat = parseFloat(asset.latitude) || 53.796030;
                const lng = parseFloat(asset.longitude) || -1.759390;
                
                editMap = L.map('edit_map_container').setView([lat, lng], 15);
                
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; OpenStreetMap contributors',
                    maxZoom: 19
                }).addTo(editMap);
                
                if (asset.latitude && asset.longitude) {
                    editMarker = L.marker([lat, lng], { draggable: true }).addTo(editMap);
                    
                    // Update coordinates when marker is dragged
                    editMarker.on('dragend', function(e) {
                        const marker = e.target;
                        const position = marker.getLatLng();
                        document.getElementById('edit_latitude').value = position.lat.toFixed(6);
                        document.getElementById('edit_longitude').value = position.lng.toFixed(6);
                    });
                }
                
                // Add marker on click
                editMap.on('click', function(e) {
                    const coords = e.latlng;
                    document.getElementById('edit_latitude').value = coords.lat.toFixed(6);
                    document.getElementById('edit_longitude').value = coords.lng.toFixed(6);
                    
                    if (editMarker) {
                        editMarker.setLatLng(coords);
                    } else {
                        editMarker = L.marker(coords, { draggable: true }).addTo(editMap);
                        editMarker.on('dragend', function(e) {
                            const marker = e.target;
                            const position = marker.getLatLng();
                            document.getElementById('edit_latitude').value = position.lat.toFixed(6);
                            document.getElementById('edit_longitude').value = position.lng.toFixed(6);
                        });
                    }
                });
            }, 100);
        }
        
        function openCreateModal() {
            document.getElementById('createModal').style.display = 'block';
            
            setTimeout(() => {
                const lat = 53.796030; // Default to Bradford
                const lng = -1.759390;
                
                createMap = L.map('create_map_container').setView([lat, lng], 15);
                
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; OpenStreetMap contributors',
                    maxZoom: 19
                }).addTo(createMap);
                
                // Add marker on click
                createMap.on('click', function(e) {
                    const coords = e.latlng;
                    document.getElementById('create_latitude').value = coords.lat.toFixed(6);
                    document.getElementById('create_longitude').value = coords.lng.toFixed(6);
                    
                    if (createMarker) {
                        createMarker.setLatLng(coords);
                    } else {
                        createMarker = L.marker(coords, { draggable: true }).addTo(createMap);
                        createMarker.on('dragend', function(e) {
                            const marker = e.target;
                            const position = marker.getLatLng();
                            document.getElementById('create_latitude').value = position.lat.toFixed(6);
                            document.getElementById('create_longitude').value = position.lng.toFixed(6);
                        });
                    }
                });
            }, 100);
        }
        
        function confirmDelete(assetId, assetName) {
            document.getElementById('delete_asset_id').value = assetId;
            document.getElementById('delete_asset_name').textContent = assetName;
            document.getElementById('deleteModal').style.display = 'block';
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
            
            // Clean up maps when closing modals
            if (modalId === 'editModal' && editMap) {
                editMap.remove();
                editMap = null;
                editMarker = null;
            } else if (modalId === 'createModal' && createMap) {
                createMap.remove();
                createMap = null;
                createMarker = null;
            } else if (modalId === 'mapViewModal') {
                const mapContainer = document.getElementById('mapViewContainer');
                while (mapContainer.firstChild) {
                    mapContainer.removeChild(mapContainer.firstChild);
                }
            }
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                closeModal(event.target.id);
            }
        }
        
        // Enter key in search triggers search
        document.getElementById('searchInput').addEventListener('keydown', function(event) {
            if (event.key === 'Enter') {
                searchAssets();
            }
        });
        
        // Charts
        document.addEventListener('DOMContentLoaded', function() {
            // Generate type chart data using JSON to prevent JS syntax errors
            const typeData = <?php 
                $typeData = [];
                foreach ($assets as $asset) {
                    $type = $asset['asset_type'] ?: 'Generic';
                    $typeData[$type] = ($typeData[$type] ?? 0) + 1;
                }
                echo json_encode($typeData);
            ?>;
            
            const typeCtx = document.getElementById('typeChart').getContext('2d');
            new Chart(typeCtx, {
                type: 'pie',
                data: {
                    labels: Object.keys(typeData),
                    datasets: [{
                        data: Object.values(typeData),
                        backgroundColor: [
                            '#1976D2', '#43A047', '#FF9800', '#E53935', '#607D8B', 
                            '#7B1FA2', '#FFC107', '#795548', '#00BCD4', '#9C27B0'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
            
            // Generate department chart data using JSON
            const deptData = <?php 
                $deptData = [];
                foreach ($assets as $asset) {
                    if (!empty($asset['department'])) {
                        $dept = $asset['department'];
                        $deptData[$dept] = ($deptData[$dept] ?? 0) + 1;
                    }
                }
                // Add "None" category for assets without department
                $noneCount = count(array_filter($assets, function($a) { return empty($a['department']); }));
                if ($noneCount > 0) {
                    $deptData['None'] = $noneCount;
                }
                echo json_encode($deptData);
            ?>;
            
            const deptCtx = document.getElementById('departmentChart').getContext('2d');
            new Chart(deptCtx, {
                type: 'bar',
                data: {
                    labels: Object.keys(deptData),
                    datasets: [{
                        label: 'Assets',
                        data: Object.values(deptData),
                        backgroundColor: '#004A87'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    layout: {
                        padding: {
                            top: 10,
                            bottom: 10
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            precision: 0,
                            ticks: {
                                maxTicksLimit: 8
                            }
                        },
                        x: {
                            ticks: {
                                maxRotation: 45,
                                minRotation: 0,
                                font: {
                                    size: 11
                                }
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
            
            // Generate owner chart data using JSON
            const ownerData = <?php 
                $ownerData = [];
                foreach ($assets as $asset) {
                    if (!empty($asset['owner_name'])) {
                        $owner = $asset['owner_name'];
                        $ownerData[$owner] = ($ownerData[$owner] ?? 0) + 1;
                    }
                }
                // Add "None" category for assets without owner
                $noOwnerCount = count(array_filter($assets, function($a) { return empty($a['owner_name']); }));
                if ($noOwnerCount > 0) {
                    $ownerData['None'] = $noOwnerCount;
                }
                echo json_encode($ownerData);
            ?>;
            
            // Get top 10 owners for better visibility
            const sortedOwners = Object.entries(ownerData)
                .sort((a, b) => b[1] - a[1])
                .slice(0, 10);
            
            const ownerLabels = sortedOwners.map(item => item[0]);
            const ownerCounts = sortedOwners.map(item => item[1]);
            
            const ownerCtx = document.getElementById('ownerChart').getContext('2d');
            new Chart(ownerCtx, {
                type: 'bar',
                data: {
                    labels: ownerLabels,
                    datasets: [{
                        label: 'Assets',
                        data: ownerCounts,
                        backgroundColor: '#8DC63F'
                    }]
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    maintainAspectRatio: false,
                    layout: {
                        padding: {
                            left: 10,
                            right: 10
                        }
                    },
                    scales: {
                        x: {
                            beginAtZero: true,
                            precision: 0,
                            ticks: {
                                maxTicksLimit: 6
                            }
                        },
                        y: {
                            ticks: {
                                font: {
                                    size: 11
                                }
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        });
    </script>
</body>
</html>
