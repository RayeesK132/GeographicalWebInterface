<?php
// Include the database connection
require 'db.php';

/**
 * Generic logging function
 * @param PDO $pdo Database connection
 * @param string $username User performing the action
 * @param string $action Description of the action
 */
function logAction($pdo, $username, $action) {
    $stmt = $pdo->prepare("INSERT INTO logs (username, action, timestamp) VALUES (:username, :action, NOW())");
    $stmt->execute([
        'username' => $username,
        'action' => $action
    ]);
}

/**
 * Logs a user login event
 */
function logLogin($pdo, $username) {
    logAction($pdo, $username, "User logged in");
}

/**
 * Logs a user logout event
 */
function logLogout($pdo, $username) {
    logAction($pdo, $username, "User logged out");
}

/**
 * Logs an asset addition
 */
function logAssetAdded($pdo, $username, $assetName) {
    logAction($pdo, $username, "Asset '$assetName' added");
}

/**
 * Logs an asset deletion
 */
function logAssetDeleted($pdo, $username, $assetName) {
    logAction($pdo, $username, "Asset '$assetName' deleted");
}

/**
 * Logs user registration
 */
function logUserRegistration($pdo, $username) {
    logAction($pdo, $username, "User registered");
}

/**
 * Logs when an asset is uploaded in bulk
 */
function logAssetBulkUpload($pdo, $username, $numAssets) {
    logAction($pdo, $username, "$numAssets assets uploaded via bulk upload");
}

/**
 * Logs when an asset is updated
 */
function logAssetUpdated($pdo, $username, $assetName) {
    logAction($pdo, $username, "Asset '$assetName' updated");
}

/**
 * Logs when an asset is viewed
 */
function logAssetViewed($pdo, $username, $assetName) {
    logAction($pdo, $username, "Asset '$assetName' viewed");
}

/**
 * Logs when an admin approves a user
 */
function logUserApproval($pdo, $adminUsername, $approvedUser) {
    logAction($pdo, $adminUsername, "Approved user: $approvedUser");
}

/**
 * Fetches control visibility for a given user
 */
function getControlsVisibility($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT add_visible, edit_visible, delete_visible, filter_visible FROM users WHERE id = :user_id");
    $stmt->execute(['user_id' => $user_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * Updates control visibility for a given user
 */
function setControlsVisibility($pdo, $user_id, $add_visible, $edit_visible, $delete_visible, $filter_visible) {
    $stmt = $pdo->prepare("UPDATE users SET add_visible = :add_visible, edit_visible = :edit_visible, delete_visible = :delete_visible, filter_visible = :filter_visible WHERE id = :user_id");
    $stmt->execute([
        'add_visible' => $add_visible,
        'edit_visible' => $edit_visible,
        'delete_visible' => $delete_visible,
        'filter_visible' => $filter_visible,
        'user_id' => $user_id
    ]);
}

/**
 * Log an action to the logs table
 * 
 * @param string $username The username performing the action
 * @param string $action The action description
 * @return bool Success or failure
 */
function addLog($username, $action) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("INSERT INTO logs (username, action) VALUES (?, ?)");
        return $stmt->execute([$username, $action]);
    } catch (PDOException $e) {
        error_log("Error logging action: " . $e->getMessage());
        return false;
    }
}

/**
 * Debugs a variable by writing it to a file
 * 
 * @param mixed $var The variable to debug
 * @param string $label Optional label
 */
function debug_to_file($var, $label = null) {
    $debug_file = __DIR__ . '/debug.log';
    $output = date("[Y-m-d H:i:s] ") . ($label ? "$label: " : "");
    $output .= var_export($var, true) . "\n\n";
    file_put_contents($debug_file, $output, FILE_APPEND);
}

/**
 * Validates that a decimal coordinate is valid
 * 
 * @param mixed $coord The coordinate to validate
 * @return bool Valid or not
 */
function validateCoordinate($coord) {
    // Check if it's a numeric value
    if (!is_numeric($coord)) {
        return false;
    }
    
    // Convert to float and check range
    $coord = floatval($coord);
    
    // Valid latitude is between -90 and 90
    if ($coord < -90 || $coord > 90) {
        return false;
    }
    
    return true;
}

/**
 * Sanitizes input to prevent XSS attacks
 * 
 * @param string $input The input to sanitize
 * @return string Sanitized input
 */
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

?>
