<?php
session_start();
require 'db.php';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit();
}

// Get user information
$username = $_SESSION['username'];

// Process POST request for saving assets
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $name = $_POST['name'] ?? '';
    $latitude = floatval($_POST['latitude'] ?? 0);
    $longitude = floatval($_POST['longitude'] ?? 0);
    $assetType = $_POST['asset_type'] ?? 'generic';
    $department = $_POST['department'] ?? '';
    $description = $_POST['description'] ?? '';
    
    // Validation
    if (empty($name)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Asset name is required']);
        exit();
    }
    
    if ($latitude == 0 || $longitude == 0) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Valid coordinates are required']);
        exit();
    }
    
    try {
        // Insert the asset into the database
        $stmt = $pdo->prepare("INSERT INTO assets (name, latitude, longitude, owner, asset_type, department, description) 
                              VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $name, 
            $latitude, 
            $longitude, 
            $username, 
            $assetType, 
            $department, 
            $description
        ]);
        
        $assetId = $pdo->lastInsertId();
        
        // Return success response
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'message' => 'Asset added successfully',
            'asset_id' => $assetId,
            'asset' => [
                'id' => $assetId,
                'name' => $name,
                'latitude' => $latitude,
                'longitude' => $longitude,
                'owner' => $username,
                'asset_type' => $assetType,
                'department' => $department,
                'description' => $description
            ]
        ]);
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
    exit();
}

// Handle GET request to fetch all assets
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $pdo->query("SELECT * FROM assets ORDER BY name");
        $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'assets' => $assets
        ]);
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
    exit();
}

// Invalid request method
header('Content-Type: application/json');
echo json_encode(['success' => false, 'message' => 'Invalid request method']);
?>
