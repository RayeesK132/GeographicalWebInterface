/**
 * Authentication Module Unit Tests
 * 
 * This file contains unit tests for the Authentication module
 * focusing on login, logout and role validation functionality.
 */

class AuthContextTest {
    constructor() {
        this.results = [];
        this.authContext = new AuthContext();
    }

    runTests() {
        this.testLogin();
        this.testLogout();
        this.testIsAdmin();
        return this.results;
    }

    testLogin() {
        const testCases = [
            {
                name: 'Valid login',
                username: 'admin',
                password: 'admin123',
                expectedResult: true
            },
            {
                name: 'Invalid password',
                username: 'admin',
                password: 'wrong',
                expectedResult: false
            },
            {
                name: 'Empty username',
                username: '',
                password: 'password',
                expectedResult: false
            }
        ];

        testCases.forEach(testCase => {
            try {
                const result = this.authContext.login(testCase.username, testCase.password);
                const testResult = {
                    name: `login: ${testCase.name}`,
                    status: result === testCase.expectedResult ? 'Pass' : 'Fail',
                    expected: testCase.expectedResult,
                    actual: result
                };
                this.results.push(testResult);
            } catch (error) {
                this.results.push({
                    name: `login: ${testCase.name}`,
                    status: 'Error',
                    message: error.message
                });
            }
        });
    }

    testLogout() {
        try {
            // First login
            this.authContext.login('admin', 'admin123');
            
            // Then test logout
            const result = this.authContext.logout();
            const isLoggedOut = !this.authContext.isLoggedIn;
            
            this.results.push({
                name: 'logout: User successfully logs out',
                status: isLoggedOut ? 'Pass' : 'Fail',
                expected: true,
                actual: isLoggedOut
            });
        } catch (error) {
            this.results.push({
                name: 'logout: User successfully logs out',
                status: 'Error',
                message: error.message
            });
        }
    }

    testIsAdmin() {
        const testCases = [
            {
                name: 'Admin user',
                setup: () => this.authContext.login('admin', 'admin123'),
                expectedResult: true
            },
            {
                name: 'Regular user',
                setup: () => {
                    this.authContext.login('user', 'password');
                    this.authContext.user = { role: 'user' };
                },
                expectedResult: false
            },
            {
                name: 'Not logged in',
                setup: () => this.authContext.logout(),
                expectedResult: false
            }
        ];

        testCases.forEach(testCase => {
            try {
                testCase.setup();
                const result = this.authContext.isAdmin();
                const testResult = {
                    name: `isAdmin: ${testCase.name}`,
                    status: result === testCase.expectedResult ? 'Pass' : 'Fail',
                    expected: testCase.expectedResult,
                    actual: result
                };
                this.results.push(testResult);
            } catch (error) {
                this.results.push({
                    name: `isAdmin: ${testCase.name}`,
                    status: 'Error',
                    message: error.message
                });
            }
        });
    }
}

// Mock AuthContext class for testing
class AuthContext {
    constructor() {
        this.user = null;
        this.isLoggedIn = false;
    }

    login(username, password) {
        // Simple mock implementation
        if (!username || !password) {
            return false;
        }
        
        if (username === 'admin' && password === 'admin123') {
            this.user = { username, role: 'admin' };
            this.isLoggedIn = true;
            return true;
        }
        
        if (username === 'user' && password === 'password') {
            this.user = { username, role: 'user' };
            this.isLoggedIn = true;
            return true;
        }
        
        return false;
    }

    logout() {
        this.user = null;
        this.isLoggedIn = false;
        return true;
    }

    isAdmin() {
        return this.isLoggedIn && this.user && this.user.role === 'admin';
    }
}

// Run tests
const authTests = new AuthContextTest();
const authResults = authTests.runTests();
console.log(authResults);
