<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Get all test files
$testFiles = [
    'auth.test.js' => 'Authentication Tests',
    'admin.test.js' => 'Admin Dashboard Tests',
    'api.test.js' => 'API Integration Tests'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unit Tests - Bradford Council</title>
    <link rel="stylesheet" href="../styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
            background-color: #004A87;
            color: white;
            padding: 15px 20px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        .test-section {
            margin-bottom: 30px;
            border: 1px solid #ddd;
            border-radius: 4px;
            overflow: hidden;
        }
        .test-header {
            background-color: #f8f9fa;
            padding: 10px 15px;
            border-bottom: 1px solid #ddd;
            font-weight: bold;
        }
        .test-results {
            padding: 15px;
        }
        .test-case {
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 4px;
        }
        .test-pass {
            background-color: #f1f9f1;
            border-left: 4px solid #28a745;
        }
        .test-fail {
            background-color: #fdf6f6;
            border-left: 4px solid #dc3545;
        }
        .test-error {
            background-color: #fff8e6;
            border-left: 4px solid #ffc107;
        }
        .btn {
            display: inline-block;
            padding: 8px 16px;
            background-color: #004A87;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Unit Tests</h1>
        </div>
        
        <p>This page runs JavaScript unit tests for the application. The tests run directly in your browser.</p>
        
        <div id="test-container">
            <!-- Test results will be inserted here by JavaScript -->
            <div id="loading">
                <p><i class="fas fa-spinner fa-spin"></i> Running tests...</p>
            </div>
        </div>
        
        <div style="text-align: center; margin-top: 20px;">
            <a href="../user-management.php" class="btn">Back to User Management</a>
            <a href="acceptance-testing.php" class="btn">Run Acceptance Tests</a>
        </div>
    </div>
    
    <!-- Include test files -->
    <?php foreach ($testFiles as $file => $description): ?>
    <script src="<?php echo $file; ?>"></script>
    <?php endforeach; ?>
    
    <script>
        // Function to display test results
        function displayTestResults(results, testName) {
            const container = document.getElementById('test-container');
            const loadingElement = document.getElementById('loading');
            
            if (loadingElement) {
                container.removeChild(loadingElement);
            }
            
            const section = document.createElement('div');
            section.className = 'test-section';
            
            const header = document.createElement('div');
            header.className = 'test-header';
            header.textContent = testName;
            
            const resultsDiv = document.createElement('div');
            resultsDiv.className = 'test-results';
            
            let passCount = 0;
            let failCount = 0;
            let errorCount = 0;
            
            results.forEach(result => {
                const testCase = document.createElement('div');
                let statusClass = '';
                
                if (result.status === 'Pass') {
                    statusClass = 'test-pass';
                    passCount++;
                } else if (result.status === 'Fail') {
                    statusClass = 'test-fail';
                    failCount++;
                } else {
                    statusClass = 'test-error';
                    errorCount++;
                }
                
                testCase.className = `test-case ${statusClass}`;
                
                let content = `<strong>${result.name}</strong>: ${result.status}`;
                
                if (result.expected !== undefined) {
                    content += `<br>Expected: ${result.expected}, Actual: ${result.actual}`;
                }
                
                if (result.message) {
                    content += `<br>Error: ${result.message}`;
                }
                
                testCase.innerHTML = content;
                resultsDiv.appendChild(testCase);
            });
            
            // Add summary
            const summary = document.createElement('div');
            summary.innerHTML = `<strong>Summary:</strong> ${passCount} passed, ${failCount} failed, ${errorCount} errors`;
            summary.style.marginTop = '10px';
            summary.style.padding = '10px';
            summary.style.backgroundColor = '#f8f9fa';
            summary.style.borderRadius = '4px';
            
            section.appendChild(header);
            section.appendChild(resultsDiv);
            section.appendChild(summary);
            container.appendChild(section);
        }
        
        // Wait for tests to complete and display results
        document.addEventListener('DOMContentLoaded', async () => {
            try {
                // Run auth tests
                const authTests = new AuthContextTest();
                const authResults = authTests.runTests();
                displayTestResults(authResults, 'Authentication Tests');
                
                // Run admin tests
                const adminTests = new AdminDashboardTest();
                const adminResults = adminTests.runTests();
                displayTestResults(adminResults, 'Admin Dashboard Tests');
                
                // Run API tests (async)
                const apiTests = new APIServiceTest();
                const apiResults = await apiTests.runTests();
                displayTestResults(apiResults, 'API Integration Tests');
            } catch (error) {
                console.error('Error running tests:', error);
                const container = document.getElementById('test-container');
                container.innerHTML = `<div class="test-error" style="padding: 15px;">Error running tests: ${error.message}</div>`;
            }
        });
    </script>
</body>
</html>
