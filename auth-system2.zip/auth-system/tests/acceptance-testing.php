<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Include database connection
require '../db.php';

class AcceptanceTest {
    private $results = [];
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function runTests() {
        $this->testCodingStandards();
        $this->testDocumentation();
        $this->testLogic();
        $this->testPerformance();
        $this->testSecurity();
        
        return $this->results;
    }
    
    private function testCodingStandards() {
        // Check for code indentation, naming conventions, etc.
        $files = $this->scanDirectory('../');
        $phpFiles = array_filter($files, function($file) {
            return pathinfo($file, PATHINFO_EXTENSION) === 'php';
        });
        
        $violations = 0;
        foreach ($phpFiles as $file) {
            $content = file_get_contents($file);
            
            // Check for PHP closing tags (not recommended)
            if (strpos($content, '?>') !== false) {
                $violations++;
            }
            
            // Check for inconsistent indentation
            if (preg_match('/^\t+\s+/m', $content) || preg_match('/^\s+\t+/m', $content)) {
                $violations++;
            }
        }
        
        $this->results[] = [
            'test_id' => 'INSPECT-001',
            'description' => 'Verify code adheres to coding standards',
            'status' => $violations === 0 ? 'Pass' : 'Fail',
            'details' => $violations === 0 ? 'No violations found' : "$violations violations found"
        ];
    }
    
    private function testDocumentation() {
        // Check for proper comments and documentation
        $files = $this->scanDirectory('../');
        $phpFiles = array_filter($files, function($file) {
            return pathinfo($file, PATHINFO_EXTENSION) === 'php';
        });
        
        $undocumentedFunctions = 0;
        foreach ($phpFiles as $file) {
            $content = file_get_contents($file);
            
            // Get all function definitions
            preg_match_all('/function\s+(\w+)\s*\(/m', $content, $matches);
            
            foreach ($matches[1] as $function) {
                // Check if function has docblock comment
                $pattern = '/\/\*\*[\s\S]*?\*\/[\s\n]*function\s+' . preg_quote($function) . '\s*\(/';
                if (!preg_match($pattern, $content)) {
                    $undocumentedFunctions++;
                }
            }
        }
        
        $this->results[] = [
            'test_id' => 'INSPECT-002',
            'description' => 'Check for proper documentation and comments',
            'status' => $undocumentedFunctions < 5 ? 'Pass' : 'Fail',
            'details' => "$undocumentedFunctions functions lack proper documentation"
        ];
    }
    
    private function testLogic() {
        // Test for logic errors
        $logicErrors = 0;
        
        // Test database connection
        try {
            $stmt = $this->pdo->query("SELECT 1");
            if (!$stmt) {
                $logicErrors++;
            }
        } catch (Exception $e) {
            $logicErrors++;
        }
        
        // Test table structure
        try {
            $requiredTables = ['users', 'assets', 'logs'];
            foreach ($requiredTables as $table) {
                $stmt = $this->pdo->query("SHOW TABLES LIKE '$table'");
                if ($stmt->rowCount() === 0) {
                    $logicErrors++;
                }
            }
        } catch (Exception $e) {
            $logicErrors++;
        }
        
        $this->results[] = [
            'test_id' => 'INSPECT-003',
            'description' => 'Test for correctness of algorithms and logic',
            'status' => $logicErrors === 0 ? 'Pass' : 'Fail',
            'details' => $logicErrors === 0 ? 'No logic errors found' : "$logicErrors logic errors found"
        ];
    }
    
    private function testPerformance() {
        // Test performance of database operations
        $start = microtime(true);
        
        try {
            // Test a simple query
            $this->pdo->query("SELECT * FROM users LIMIT 10");
            
            // Test a more complex join query
            $this->pdo->query("SELECT u.*, COUNT(a.id) as asset_count 
                              FROM users u 
                              LEFT JOIN assets a ON u.username = a.owner 
                              GROUP BY u.id 
                              LIMIT 10");
        } catch (Exception $e) {
            // Ignore errors for testing purposes
        }
        
        $end = microtime(true);
        $executionTime = round(($end - $start) * 1000, 2); // in milliseconds
        
        $this->results[] = [
            'test_id' => 'INSPECT-004',
            'description' => 'Validate the performance and efficiency of the code',
            'status' => $executionTime < 100 ? 'Pass' : 'Fail',
            'details' => "Execution time: $executionTime ms " . ($executionTime < 100 ? '(acceptable)' : '(too slow)')
        ];
    }
    
    private function testSecurity() {
        // Test for common security vulnerabilities
        $securityIssues = 0;
        
        $files = $this->scanDirectory('../');
        $phpFiles = array_filter($files, function($file) {
            return pathinfo($file, PATHINFO_EXTENSION) === 'php';
        });
        
        foreach ($phpFiles as $file) {
            $content = file_get_contents($file);
            
            // Check for potential SQL injection
            if (preg_match('/\$_GET|\$_POST|->query\(\s*["\']\s*SELECT|->query\(\s*["\'].*\$(?!pdo->prepare)/i', $content)) {
                $securityIssues++;
            }
            
            // Check for potential XSS vulnerabilities
            if (preg_match('/echo\s+\$_GET|echo\s+\$_POST|echo\s+\$_REQUEST|echo\s+\$_COOKIE/i', $content)) {
                $securityIssues++;
            }
        }
        
        $this->results[] = [
            'test_id' => 'INSPECT-005',
            'description' => 'Check for security vulnerabilities',
            'status' => $securityIssues === 0 ? 'Pass' : 'Fail',
            'details' => $securityIssues === 0 ? 'No security issues found' : "$securityIssues potential security issues found"
        ];
    }
    
    private function scanDirectory($dir) {
        $result = [];
        $files = scandir($dir);
        
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            
            $path = $dir . '/' . $file;
            if (is_dir($path)) {
                $result = array_merge($result, $this->scanDirectory($path));
            } else {
                $result[] = $path;
            }
        }
        
        return $result;
    }
}

// Run the acceptance tests
$acceptanceTest = new AcceptanceTest($pdo);
$testResults = $acceptanceTest->runTests();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceptance Testing - Bradford Council</title>
    <link rel="stylesheet" href="../styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
            background-color: #004A87;
            color: white;
            padding: 15px 20px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        .status-pass {
            background-color: #d4edda;
            color: #155724;
            padding: 5px 10px;
            border-radius: 4px;
        }
        .status-fail {
            background-color: #f8d7da;
            color: #721c24;
            padding: 5px 10px;
            border-radius: 4px;
        }
        .status-error {
            background-color: #fff3cd;
            color: #856404;
            padding: 5px 10px;
            border-radius: 4px;
        }
        .btn {
            display: inline-block;
            padding: 8px 16px;
            background-color: #004A87;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Acceptance Testing Results</h1>
        </div>
        
        <h2>Test Case Results</h2>
        <table>
            <thead>
                <tr>
                    <th>Test ID</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($testResults as $result): ?>
                <tr>
                    <td><?php echo $result['test_id']; ?></td>
                    <td><?php echo $result['description']; ?></td>
                    <td>
                        <span class="status-<?php echo strtolower($result['status']); ?>">
                            <?php echo $result['status']; ?>
                        </span>
                    </td>
                    <td><?php echo $result['details']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div style="text-align: center; margin-top: 20px;">
            <a href="../user-management.php" class="btn">Back to User Management</a>
        </div>
    </div>
</body>
</html>
