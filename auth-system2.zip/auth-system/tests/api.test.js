/**
 * API Service Unit Tests
 * 
 * This file contains unit tests for the API Service
 * focusing on API endpoints for authentication and data operations.
 */

class APIServiceTest {
    constructor() {
        this.results = [];
        this.apiService = new APIService('http://localhost/auth-system/api');
    }

    async runTests() {
        await this.testLogin();
        await this.testGetUsers();
        await this.testGetAssets();
        await this.testDeleteUser();
        await this.testDeleteAsset();
        return this.results;
    }

    async testLogin() {
        const testCases = [
            {
                name: 'Valid credentials',
                username: 'admin',
                password: 'admin123',
                expectedResult: true
            },
            {
                name: 'Invalid password',
                username: 'admin',
                password: 'wrong',
                expectedResult: false
            },
            {
                name: 'Empty username',
                username: '',
                password: 'password',
                expectedResult: false
            }
        ];

        for (const testCase of testCases) {
            try {
                const result = await this.apiService.login(testCase.username, testCase.password);
                const testResult = {
                    name: `login: ${testCase.name}`,
                    status: (result.success === testCase.expectedResult) ? 'Pass' : 'Fail',
                    expected: testCase.expectedResult,
                    actual: result.success
                };
                this.results.push(testResult);
            } catch (error) {
                this.results.push({
                    name: `login: ${testCase.name}`,
                    status: 'Error',
                    message: error.message
                });
            }
        }
    }

    async testGetUsers() {
        try {
            const result = await this.apiService.getUsers();
            const testResult = {
                name: 'getUsers: Retrieve user list',
                status: Array.isArray(result.data) ? 'Pass' : 'Fail',
                expected: 'Array of users',
                actual: typeof result.data
            };
            this.results.push(testResult);
        } catch (error) {
            this.results.push({
                name: 'getUsers: Retrieve user list',
                status: 'Error',
                message: error.message
            });
        }
    }

    async testGetAssets() {
        try {
            const result = await this.apiService.getAssets();
            const testResult = {
                name: 'getAssets: Retrieve asset list',
                status: Array.isArray(result.data) ? 'Pass' : 'Fail',
                expected: 'Array of assets',
                actual: typeof result.data
            };
            this.results.push(testResult);
        } catch (error) {
            this.results.push({
                name: 'getAssets: Retrieve asset list',
                status: 'Error',
                message: error.message
            });
        }
    }

    async testDeleteUser() {
        const testCases = [
            {
                name: 'Valid user ID',
                userId: 1,
                expectedResult: true
            },
            {
                name: 'Invalid user ID',
                userId: 999,
                expectedResult: false
            },
            {
                name: 'Missing user ID',
                userId: null,
                expectedResult: false
            }
        ];

        for (const testCase of testCases) {
            try {
                const result = await this.apiService.deleteUser(testCase.userId);
                const testResult = {
                    name: `deleteUser: ${testCase.name}`,
                    status: (result.success === testCase.expectedResult) ? 'Pass' : 'Fail',
                    expected: testCase.expectedResult,
                    actual: result.success
                };
                this.results.push(testResult);
            } catch (error) {
                this.results.push({
                    name: `deleteUser: ${testCase.name}`,
                    status: 'Error',
                    message: error.message
                });
            }
        }
    }

    async testDeleteAsset() {
        const testCases = [
            {
                name: 'Valid asset ID',
                assetId: 1,
                expectedResult: true
            },
            {
                name: 'Invalid asset ID',
                assetId: 999,
                expectedResult: false
            },
            {
                name: 'Missing asset ID',
                assetId: null,
                expectedResult: false
            }
        ];

        for (const testCase of testCases) {
            try {
                const result = await this.apiService.deleteAsset(testCase.assetId);
                const testResult = {
                    name: `deleteAsset: ${testCase.name}`,
                    status: (result.success === testCase.expectedResult) ? 'Pass' : 'Fail',
                    expected: testCase.expectedResult,
                    actual: result.success
                };
                this.results.push(testResult);
            } catch (error) {
                this.results.push({
                    name: `deleteAsset: ${testCase.name}`,
                    status: 'Error',
                    message: error.message
                });
            }
        }
    }
}

// Mock API Service class for testing
class APIService {
    constructor(baseUrl) {
        this.baseUrl = baseUrl;
        this.token = null;
        
        // Sample data for mocking
        this.mockUsers = [
            { id: 1, username: 'admin', role: 'admin' },
            { id: 2, username: 'user1', role: 'user' }
        ];
        
        this.mockAssets = [
            { id: 1, name: 'Building A', asset_type: 'building' },
            { id: 2, name: 'Park B', asset_type: 'park' }
        ];
    }

    async login(username, password) {
        // Mock implementation
        return new Promise(resolve => {
            setTimeout(() => {
                if (!username || !password) {
                    resolve({ success: false, message: 'Username and password required' });
                    return;
                }
                
                if (username === 'admin' && password === 'admin123') {
                    this.token = 'mock-jwt-token';
                    resolve({ success: true, token: this.token, user: this.mockUsers[0] });
                } else {
                    resolve({ success: false, message: 'Invalid credentials' });
                }
            }, 100);
        });
    }

    async getUsers() {
        return new Promise(resolve => {
            setTimeout(() => {
                resolve({
                    success: true,
                    data: this.mockUsers
                });
            }, 100);
        });
    }

    async getAssets() {
        return new Promise(resolve => {
            setTimeout(() => {
                resolve({
                    success: true,
                    data: this.mockAssets
                });
            }, 100);
        });
    }

    async deleteUser(userId) {
        return new Promise(resolve => {
            setTimeout(() => {
                if (!userId) {
                    resolve({ success: false, message: 'User ID is required' });
                    return;
                }
                
                const userIndex = this.mockUsers.findIndex(u => u.id === userId);
                if (userIndex === -1) {
                    resolve({ success: false, message: 'User not found' });
                    return;
                }
                
                this.mockUsers.splice(userIndex, 1);
                resolve({ success: true, message: 'User deleted successfully' });
            }, 100);
        });
    }

    async deleteAsset(assetId) {
        return new Promise(resolve => {
            setTimeout(() => {
                if (!assetId) {
                    resolve({ success: false, message: 'Asset ID is required' });
                    return;
                }
                
                const assetIndex = this.mockAssets.findIndex(a => a.id === assetId);
                if (assetIndex === -1) {
                    resolve({ success: false, message: 'Asset not found' });
                    return;
                }
                
                this.mockAssets.splice(assetIndex, 1);
                resolve({ success: true, message: 'Asset deleted successfully' });
            }, 100);
        });
    }
}

// Run tests
async function runAPITests() {
    const apiTests = new APIServiceTest();
    const apiResults = await apiTests.runTests();
    console.log(apiResults);
}

runAPITests();
