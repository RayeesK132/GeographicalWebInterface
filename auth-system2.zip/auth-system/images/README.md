# Images Directory

This directory contains images used by the Bradford Council Asset Management System.

Required images:
- bradford_council_logo.png - The official Bradford Council logo
