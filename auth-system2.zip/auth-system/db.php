<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection parameters
$host     = 'localhost';   // Try '127.0.0.1' if 'localhost' doesn't work
$dbname   = 'auth_system'; // This database needs to be created
$username = 'root';        // Default XAMPP username
$password = 'root';        // Default XAMPP empty password
$port     = 3306;          // Default MySQL port

// Initialize database connection info array
$dbInfo = [
    'host'     => $host,
    'database' => $dbname,
    'status'   => 'Disconnected',
    'server'   => 'Unknown',
];

// Try to connect to MySQL first without specifying a database
try {
    // First check if MySQL server is even running
    $connection = @fsockopen($host, $port, $errno, $errstr, 5);
    if (! $connection) {
        throw new PDOException("MySQL server is not running or not accessible (Error: $errstr)");
    }
    fclose($connection);

    // Create a connection to MySQL without specifying a database
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_TIMEOUT            => 5,
    ];

    $pdo_connect = new PDO("mysql:host=$host;port=$port", $username, $password, $options);

    // Check if the database exists
    $stmt     = $pdo_connect->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$dbname'");
    $dbExists = $stmt->fetchColumn();

    // If database doesn't exist, create it
    if (! $dbExists) {
        // Redirect to the database setup page
        header('Location: setup-database.php');
        exit();
    }

    // Now connect to the specific database
    $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4";
    $pdo = new PDO($dsn, $username, $password, $options);

    // Set database info for the status indicator
    $dbInfo = [
        'host'     => $host,
        'database' => $dbname,
        'status'   => 'Connected',
        'server'   => $pdo->getAttribute(PDO::ATTR_SERVER_VERSION),
    ];

} catch (PDOException $e) {
    // If we can't even connect to MySQL, show error with helpful information
    $dbInfo = [
        'host'     => $host,
        'database' => $dbname ?? 'Unknown',
        'status'   => 'Disconnected',
        'server'   => 'Error: ' . $e->getMessage(),
    ];

    echo "<div style='padding: 20px; background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; margin: 20px;'>";
    echo "<h3>Database Connection Error</h3>";
    echo "<p><strong>Error:</strong> " . $e->getMessage() . "</p>";

    if (strpos($e->getMessage(), 'refused') !== false || strpos($e->getMessage(), 'gone away') !== false) {
        echo "<p><strong>The MySQL server is not running or not accessible.</strong></p>";
        echo "<h4>How to fix:</h4>";
        echo "<ol>";
        echo "<li>Open XAMPP Control Panel</li>";
        echo "<li>Click 'Start' next to MySQL</li>";
        echo "<li>If MySQL won't start, check the logs</li>";
        echo "</ol>";
        echo "<p><a href='mysql_fix.php' style='display: inline-block; padding: 10px 15px; background-color: #28a745; color: white; text-decoration: none; border-radius: 4px;'>Run MySQL Diagnostic Tool</a></p>";
    } else {
        echo "<p><strong>Troubleshooting steps:</strong></p>";
        echo "<ol>";
        echo "<li>Make sure your MySQL server is running (check XAMPP control panel)</li>";
        echo "<li>Verify that the username '$username' has permission to access MySQL</li>";
        echo "<li>Confirm your password is correct (currently set as empty)</li>";
        echo "</ol>";
    }

    echo "<p>Would you like to try setting up the database?</p>";
    echo "<a href='setup-database.php' style='display: inline-block; padding: 10px 15px; background-color: #007bff; color: white; text-decoration: none; border-radius: 4px;'>Setup Database</a>";
    echo " <a href='mysql_fix.php' style='display: inline-block; padding: 10px 15px; background-color: #28a745; color: white; text-decoration: none; border-radius: 4px;'>Run MySQL Diagnostic Tool</a>";
    echo "</div>";
    exit();
}

// Function to render the database status bar - ONLY define if not already defined
if (! function_exists('renderDbStatusBar')) {
    function renderDbStatusBar()
    {
        global $dbInfo;

        $statusClass = $dbInfo['status'] === 'Connected' ? 'connected' : 'disconnected';
        $statusIcon  = $dbInfo['status'] === 'Connected' ? 'fa-check-circle' : 'fa-exclamation-circle';

        echo '
        <div class="db-status-bar">
            <div class="db-status-indicator ' . $statusClass . '">
                <i class="fas ' . $statusIcon . '"></i>
                <span>Database: ' . $dbInfo['status'] . '</span>
            </div>
            <div class="db-info">
                <span><strong>Server:</strong> ' . htmlspecialchars($dbInfo['server']) . '</span>
                <span><strong>Database:</strong> ' . htmlspecialchars($dbInfo['database']) . '</span>
            </div>
        </div>';
    }
}

// CSS for the database status indicator - ONLY define if not already defined
if (! function_exists('dbStatusStyles')) {
    function dbStatusStyles()
    {
        echo '
        <style>
        /* Database Status Bar Styles */
        .db-status-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #ddd;
        }

        .db-status-indicator {
            display: flex;
            align-items: center;
            font-weight: bold;
        }

        .db-status-indicator i {
            margin-right: 6px;
            font-size: 16px;
        }

        .db-status-indicator.connected {
            color: #28a745;
        }

        .db-status-indicator.disconnected {
            color: #dc3545;
        }

        .db-info {
            display: flex;
            gap: 20px;
            font-size: 14px;
            color: #666;
        }
        </style>
        ';
    }
}
