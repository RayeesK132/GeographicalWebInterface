<?php
session_start();

// Check if user is logged in as admin
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Create error log file if it doesn't exist
$error_log_file = __DIR__ . '/error.log';
if (!file_exists($error_log_file)) {
    file_put_contents($error_log_file, "Error Log Created: " . date('Y-m-d H:i:s') . "\n");
}

// Function to log errors
function logError($message, $type = 'ERROR') {
    global $error_log_file;
    $timestamp = date('Y-m-d H:i:s');
    $user = isset($_SESSION['username']) ? $_SESSION['username'] : 'Unknown';
    $log_message = "[$timestamp] [$type] [$user] $message\n";
    file_put_contents($error_log_file, $log_message, FILE_APPEND);
}

// Check if we're being asked to clear the log
if (isset($_GET['clear']) && $_GET['clear'] == 1) {
    file_put_contents($error_log_file, "Log cleared: " . date('Y-m-d H:i:s') . "\n");
    header('Location: error_log.php?cleared=1');
    exit();
}

// Display the log file
$log_content = file_exists($error_log_file) ? file_get_contents($error_log_file) : 'No log file found';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error Log - Bradford Council Asset System</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .log-container {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
            max-height: 600px;
            overflow-y: auto;
            font-family: monospace;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        .controls {
            margin-bottom: 20px;
        }
        .controls a {
            display: inline-block;
            margin-right: 10px;
            padding: 8px 16px;
            background-color: #004A87;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .controls a:hover {
            background-color: #003366;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Error Log</h1>
        
        <?php if (isset($_GET['cleared'])): ?>
            <div class="alert alert-success">Log has been cleared.</div>
        <?php endif; ?>
        
        <div class="controls">
            <a href="admin-dashboard.php">Back to Dashboard</a>
            <a href="error_log.php?clear=1" onclick="return confirm('Are you sure you want to clear the error log?')">Clear Log</a>
        </div>
        
        <div class="log-container">
            <?php echo htmlspecialchars($log_content); ?>
        </div>
    </div>
</body>
</html>
