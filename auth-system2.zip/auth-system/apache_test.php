<?php
// This file helps verify that Apache is working correctly with .htaccess

echo "<h1>Apache and .htaccess Test</h1>";

// Check if mod_rewrite is enabled
echo "<h2>Checking mod_rewrite:</h2>";
if (in_array('mod_rewrite', apache_get_modules())) {
    echo "<p style='color: green;'>✓ mod_rewrite is enabled.</p>";
} else {
    echo "<p style='color: red;'>✗ mod_rewrite is NOT enabled. You may need to enable it in httpd.conf.</p>";
    echo "<p>Steps to enable mod_rewrite:</p>";
    echo "<ol>";
    echo "<li>Open <code>C:\xampp\apache\conf\httpd.conf</code> in a text editor</li>";
    echo "<li>Find the line <code>#LoadModule rewrite_module modules/mod_rewrite.so</code></li>";
    echo "<li>Remove the # at the beginning to uncomment it</li>";
    echo "<li>Restart Apache using XAMPP Control Panel</li>";
    echo "</ol>";
}

// Check if .htaccess files are being processed
echo "<h2>Checking .htaccess processing:</h2>";

// Check AllowOverride setting
echo "<p>For .htaccess files to work, 'AllowOverride All' must be set in your Apache configuration.</p>";
echo "<p>If you're seeing this page without errors, Apache is processing .htaccess files correctly.</p>";

echo "<h2>XAMPP Information:</h2>";
echo "<ul>";
echo "<li>PHP Version: " . phpversion() . "</li>";
echo "<li>Server Software: " . $_SERVER['SERVER_SOFTWARE'] . "</li>";
echo "<li>Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "</li>";
echo "</ul>";

echo "<h2>Next Steps:</h2>";
echo "<ul>";
echo "<li><a href='mysql_check.php'>Run MySQL Diagnostics</a></li>";
echo "<li><a href='user-management.php'>Go to User Management</a></li>";
echo "<li><a href='setup-database.php'>Setup Database</a></li>";
echo "</ul>";
?>
