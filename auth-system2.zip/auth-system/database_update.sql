-- SQL to update database structure

-- First, let's alter the users table to add the department column if it doesn't exist
ALTER TABLE `users` 
ADD COLUMN IF NOT EXISTS `department` VARCHAR(100) DEFAULT NULL;

-- Now, let's alter the assets table to add the asset_type column if it doesn't exist
ALTER TABLE `assets` 
ADD COLUMN IF NOT EXISTS `asset_type` VARCHAR(50) DEFAULT 'generic';

-- Check for other potentially missing columns in assets table
ALTER TABLE `assets`
ADD COLUMN IF NOT EXISTS `department` VARCHAR(100) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS `description` TEXT DEFAULT NULL;

-- Add IP address to logs table if it's missing
ALTER TABLE `logs`
ADD COLUMN IF NOT EXISTS `ip_address` VARCHAR(45) DEFAULT NULL;

-- Make sure the active column exists in users (some systems use approved instead)
ALTER TABLE `users`
ADD COLUMN IF NOT EXISTS `active` TINYINT(1) DEFAULT 1;

-- Add updated_at column to users if it doesn't exist
ALTER TABLE `users`
ADD COLUMN IF NOT EXISTS `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Add indexes for better performance
ALTER TABLE `assets` 
ADD INDEX IF NOT EXISTS `idx_asset_type` (`asset_type`),
ADD INDEX IF NOT EXISTS `idx_department` (`department`),
ADD INDEX IF NOT EXISTS `idx_owner` (`owner`);

-- Alternative approach for search functionality without generated columns
-- Add a regular search_text column that will be updated via triggers or application code
ALTER TABLE `assets`
ADD COLUMN IF NOT EXISTS `search_text` TEXT DEFAULT NULL;

-- Create basic indexes on individual columns for search
ALTER TABLE `assets`
ADD FULLTEXT INDEX IF NOT EXISTS `idx_name` (`name`),
ADD FULLTEXT INDEX IF NOT EXISTS `idx_description` (`description`);

-- Create trigger to update search_text when an asset is inserted or updated
-- Note: DROP the existing triggers first to avoid errors
DROP TRIGGER IF EXISTS before_asset_insert;
DROP TRIGGER IF EXISTS before_asset_update;

-- Create trigger for INSERT operations
DELIMITER //
CREATE TRIGGER before_asset_insert
BEFORE INSERT ON assets
FOR EACH ROW
BEGIN
    SET NEW.search_text = CONCAT_WS(' ', NEW.name, NEW.asset_type, NEW.department, NEW.description, NEW.owner);
END//
DELIMITER ;

-- Create trigger for UPDATE operations
DELIMITER //
CREATE TRIGGER before_asset_update
BEFORE UPDATE ON assets
FOR EACH ROW
BEGIN
    SET NEW.search_text = CONCAT_WS(' ', NEW.name, NEW.asset_type, NEW.department, NEW.description, NEW.owner);
END//
DELIMITER ;

-- Update existing records to populate search_text
UPDATE assets SET search_text = CONCAT_WS(' ', name, asset_type, department, description, owner);

-- Add fulltext index on the search_text column
ALTER TABLE `assets`
ADD FULLTEXT INDEX IF NOT EXISTS `idx_search_text` (`search_text`);
