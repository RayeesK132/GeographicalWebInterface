<?php
session_start();
require 'db.php';
require 'auth_config.php';
require 'functions.php';

// Check if user is already logged in
if (isset($_SESSION['username'])) {
    header('Location: dashboard.php');
    exit();
}

$error = '';
$successMessage = '';

// Standard form signup processing
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $department = trim($_POST['department']);
    $jobRole = trim($_POST['job_role']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    
    // Validate form data
    if (empty($username) || empty($email) || empty($phone) || empty($password) || empty($confirmPassword) || empty($department) || empty($jobRole)) {
        $error = "All fields are required";
    } elseif ($password !== $confirmPassword) {
        $error = "Passwords do not match";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters long";
    } else {
        // Check if username or email already exists
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username OR email = :email");
        $stmt->execute(['username' => $username, 'email' => $email]);
        $user = $stmt->fetch();
        
        if ($user) {
            $error = "Username or email already exists";
        } else {
            // Generate verification code
            $verificationCode = bin2hex(random_bytes(16));
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
            
            try {
                // Insert new user
                $stmt = $pdo->prepare("INSERT INTO users (username, password, email, phone, department, job_role, verification_code, approved) VALUES (:username, :password, :email, :phone, :department, :job_role, :verification_code, 0)");
                $stmt->execute([
                    'username' => $username,
                    'password' => $hashedPassword,
                    'email' => $email,
                    'phone' => $phone,
                    'department' => $department,
                    'job_role' => $jobRole,
                    'verification_code' => $verificationCode
                ]);
                
                // Log the registration
                logUserRegistration($pdo, $username);
                
                // Send verification email
                sendVerificationEmail($email, $username, $verificationCode);
                
                $successMessage = "Registration successful! Please check your email to verify your account.";
            } catch (PDOException $e) {
                $error = "Registration failed: " . $e->getMessage();
            }
        }
    }
}

// Send verification email function
function sendVerificationEmail($email, $username, $verificationCode) {
    // Implementation of email sending
    // This could use PHPMailer or other email library
    $to = $email;
    $subject = "Verify Your Account";
    $verificationLink = "http://localhost/auth-system/verify-email.php?code=" . $verificationCode;
    
    $message = "
    <html>
    <head>
        <title>Email Verification</title>
    </head>
    <body>
        <div style='max-width: 600px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif;'>
            <div style='background-color: #004A87; padding: 20px; text-align: center;'>
                <img src='http://localhost/auth-system/images/bradford_council_logo.png' alt='Bradford Council Logo' style='max-width: 200px;'>
            </div>
            <div style='padding: 20px; background-color: #f8f8f8;'>
                <h2 style='color: #004A87;'>Verify Your Email Address</h2>
                <p>Dear $username,</p>
                <p>Thank you for registering with Bradford Council Asset Management System. Please click the button below to verify your email address:</p>
                <div style='text-align: center; margin: 30px 0;'>
                    <a href='$verificationLink' style='background-color: #004A87; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;'>Verify Email</a>
                </div>
                <p>If the button above doesn't work, please copy and paste the following link into your web browser:</p>
                <p><a href='$verificationLink'>$verificationLink</a></p>
                <p>Thank you,<br>Bradford Council Asset Management Team</p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    // Set content-type header for sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: Bradford Council <noreply@bradford.gov.uk>" . "\r\n";
    
    // Send email
    mail($to, $subject, $message, $headers);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Bradford Council</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <!-- Header with Bradford Council Logo -->
    <header class="header">
        <div class="container">
            <div class="header-logo">
                <img src="images/bradford_council_logo.png" alt="Bradford Council Logo">
                <h1 class="header-title">Asset Management System</h1>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="form-container">
            <h2 class="form-title">Sign Up</h2>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <?php if ($successMessage): ?>
                <div class="alert alert-success"><?php echo $successMessage; ?></div>
            <?php endif; ?>

            <!-- Regular Signup Form -->
            <form method="POST">
                <div class="form-group">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" id="username" name="username" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" id="email" name="email" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="phone" class="form-label">Phone Number</label>
                    <input type="text" id="phone" name="phone" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="department" class="form-label">Department</label>
                    <select id="department" name="department" class="form-select" required>
                        <option value="">Select Department</option>
                        <?php foreach (DEPARTMENTS as $key => $value): ?>
                            <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="job_role" class="form-label">Job Role</label>
                    <input type="text" id="job_role" name="job_role" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="confirmPassword" class="form-label">Confirm Password</label>
                    <input type="password" id="confirmPassword" name="confirmPassword" class="form-control" required>
                </div>
                
                <button type="submit" class="form-button">Sign Up</button>
            </form>
            
            <div style="text-align: center; margin: 20px 0;">
                <p>- OR -</p>
            </div>
            
            <!-- Auth0 Login Button -->
            <a href="auth0-login.php" class="auth0-login">
                <i class="fas fa-lock"></i> Sign Up with Single Sign-On
            </a>
            
            <p style="text-align: center; margin-top: 20px;">
                Already have an account? <a href="login.php" style="color: var(--bradford-blue);">Login</a>
            </p>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Form validation
            const form = document.querySelector('form');
            form.addEventListener('submit', function(e) {
                const password = document.getElementById('password').value;
                const confirmPassword = document.getElementById('confirmPassword').value;
                
                if (password !== confirmPassword) {
                    e.preventDefault();
                    alert('Passwords do not match!');
                }
                
                if (password.length < 8) {
                    e.preventDefault();
                    alert('Password must be at least 8 characters long!');
                }
            });
        });
    </script>
</body>
</html>
