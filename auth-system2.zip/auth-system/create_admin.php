<?php
    // Enable error reporting for debugging
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    // Include database connection
    require 'db.php';

    // Define admin credentials
    $username = 'admin';
    $password = 'admin123'; // This will be hashed
    $email    = 'admin@example.com';
    $role     = 'admin';

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    try {
        // Check if admin already exists
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $adminExists = $stmt->fetchColumn();

        if ($adminExists) {
            // Admin exists, update the password
            $stmt = $pdo->prepare("UPDATE users SET password = ?, email = ?, role = 'admin', active = 1 WHERE username = ?");
            $stmt->execute([$hashedPassword, $email, $username]);
            $message = "Admin account updated successfully!";
            $status  = "success";
        } else {
            // Create new admin account
            $stmt = $pdo->prepare("INSERT INTO users (username, password, email, role, active) VALUES (?, ?, ?, 'admin', 1)");
            $stmt->execute([$username, $hashedPassword, $email]);
            $message = "Admin account created successfully!";
            $status  = "success";
        }
    } catch (PDOException $e) {
        $message = "Error: " . $e->getMessage();
        $status  = "error";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Admin Account</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .details {
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .btn {
            display: inline-block;
            padding: 8px 16px;
            background-color: #004A87;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <h1>Admin Account Creation Tool</h1>

    <div class="message                                                                                                                                                                                         <?php echo $status; ?>">
        <?php echo $message; ?>
    </div>

    <div class="details">
        <h2>Admin Credentials</h2>
        <p><strong>Username:</strong>                                                                                                                                                                                                                                                                                                         <?php echo htmlspecialchars($username); ?></p>
        <p><strong>Password:</strong>                                                                                                                                                                                                                                                                                                         <?php echo htmlspecialchars($password); ?> (plain text - will be hashed in database)</p>
        <p><strong>Email:</strong>                                                                                                                                                                                                                                                                                 <?php echo htmlspecialchars($email); ?></p>
        <p><strong>Role:</strong>                                                                                                                                                                                                                                                                         <?php echo htmlspecialchars($role); ?></p>
    </div>

    <div>
        <p>You can now use these credentials to log into the system.</p>
        <a href="login.php" class="btn">Go to Login Page</a>
    </div>
</body>
</html>
