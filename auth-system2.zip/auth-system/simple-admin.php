<?php
// Force error display
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Basic authentication - much simpler than normal
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    if (isset($_POST['login']) && isset($_POST['username']) && isset($_POST['password'])) {
        try {
            require 'db.php';
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND role = 'admin'");
            $stmt->execute([$_POST['username']]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && password_verify($_POST['password'], $user['password'])) {
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                // Redirect to reload page after login
                header('Location: ' . $_SERVER['PHP_SELF']);
                exit;
            } else {
                $error = "Invalid admin credentials";
            }
        } catch (Exception $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
    
    // Display login form
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Simple Admin Login</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
            .container { max-width: 400px; margin: 50px auto; background: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .form-group { margin-bottom: 15px; }
            label { display: block; margin-bottom: 5px; }
            input[type="text"], input[type="password"] { width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ddd; border-radius: 4px; }
            button { padding: 10px 15px; background: #004A87; color: white; border: none; border-radius: 4px; cursor: pointer; }
            .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin-bottom: 15px; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Admin Login</h1>
            <?php if (isset($error)): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            <form method="post">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" name="login">Login</button>
            </form>
            <p><a href="diagnose.php">Run Diagnostics</a> | <a href="run_db_update.php">Setup Database</a></p>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// At this point, user is logged in as admin
// Include database connection
require 'db.php';

// Try to connect to database
$dbConnected = false;
try {
    $pdo->query("SELECT 1");
    $dbConnected = true;
} catch (Exception $e) {
    $dbError = $e->getMessage();
}

// Simple function to check if a table exists
function tableExists($pdo, $table) {
    try {
        $result = $pdo->query("SHOW TABLES LIKE '$table'");
        return $result->rowCount() > 0;
    } catch (Exception $e) {
        return false;
    }
}

// Simple function to count records
function countRecords($pdo, $table) {
    try {
        return $pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
    } catch (Exception $e) {
        return "Error";
    }
}

// Function to render database status bar
function renderDbStatusBar() {
    global $dbConnected, $dbError;
    echo '<div class="card">';
    echo '<h2 class="card-title">Database Connection Status</h2>';
    echo '<p>Database Connection: ';
    if ($dbConnected) {
        echo '<span class="status status-ok">Connected</span>';
    } else {
        echo '<span class="status status-error">Failed: ' . htmlspecialchars($dbError) . '</span>';
    }
    echo '</p>';
    echo '</div>';
}

// Function to include database status styles
function dbStatusStyles() {
    echo '<style>';
    echo '.status { display: inline-block; padding: 5px 10px; border-radius: 20px; font-size: 14px; }';
    echo '.status-ok { background: #d4edda; color: #155724; }';
    echo '.status-error { background: #f8d7da; color: #721c24; }';
    echo '</style>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <?php dbStatusStyles(); ?>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
        .container { max-width: 900px; margin: 0 auto; background: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header { background: #004A87; color: white; padding: 15px; border-radius: 5px; margin-bottom: 20px; display: flex; justify-content: space-between; }
        .btn { display: inline-block; padding: 8px 16px; background: #004A87; color: white; text-decoration: none; border-radius: 4px; margin-right: 10px; }
        .card { border: 1px solid #ddd; border-radius: 5px; padding: 15px; margin-bottom: 20px; }
        .card-title { border-bottom: 1px solid #ddd; padding-bottom: 10px; margin-top: 0; }
        table { width: 100%; border-collapse: collapse; }
        table th, table td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Simple Admin Dashboard</h1>
            <div>
                Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>
            </div>
        </div>
        
        <!-- Database Connection Status Indicator -->
        <?php renderDbStatusBar(); ?>
        
        <div class="card">
            <h2 class="card-title">System Status</h2>
            <p>PHP Version: <?php echo phpversion(); ?></p>
        </div>
        
        <?php if ($dbConnected): ?>
        <div class="card">
            <h2 class="card-title">Database Tables</h2>
            <table>
                <tr>
                    <th>Table</th>
                    <th>Status</th>
                    <th>Records</th>
                </tr>
                <tr>
                    <td>users</td>
                    <td>
                        <?php if (tableExists($pdo, 'users')): ?>
                            <span class="status status-ok">Exists</span>
                        <?php else: ?>
                            <span class="status status-error">Missing</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo tableExists($pdo, 'users') ? countRecords($pdo, 'users') : '-'; ?></td>
                </tr>
                <tr>
                    <td>assets</td>
                    <td>
                        <?php if (tableExists($pdo, 'assets')): ?>
                            <span class="status status-ok">Exists</span>
                        <?php else: ?>
                            <span class="status status-error">Missing</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo tableExists($pdo, 'assets') ? countRecords($pdo, 'assets') : '-'; ?></td>
                </tr>
                <tr>
                    <td>logs</td>
                    <td>
                        <?php if (tableExists($pdo, 'logs')): ?>
                            <span class="status status-ok">Exists</span>
                        <?php else: ?>
                            <span class="status status-error">Missing</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo tableExists($pdo, 'logs') ? countRecords($pdo, 'logs') : '-'; ?></td>
                </tr>
            </table>
        </div>
        
        <?php if (tableExists($pdo, 'users')): ?>
        <div class="card">
            <h2 class="card-title">User Management</h2>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                </tr>
                <?php
                try {
                    $users = $pdo->query("SELECT id, username, email, role FROM users LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($users as $user) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($user['id']) . "</td>";
                        echo "<td>" . htmlspecialchars($user['username']) . "</td>";
                        echo "<td>" . htmlspecialchars($user['email']) . "</td>";
                        echo "<td>" . htmlspecialchars($user['role']) . "</td>";
                        echo "</tr>";
                    }
                } catch (Exception $e) {
                    echo "<tr><td colspan='4'>Error fetching users: " . htmlspecialchars($e->getMessage()) . "</td></tr>";
                }
                ?>
            </table>
        </div>
        <?php endif; ?>
        
        <?php endif; ?>
        
        <div style="margin-top: 20px;">
            <a href="run_db_update.php" class="btn">Database Setup</a>
            <a href="diagnose.php" class="btn">Run Diagnostics</a>
            <a href="user-management.php" class="btn">User Management</a>
            <a href="logout.php" class="btn">Logout</a>
        </div>
    </div>
</body>
</html>
