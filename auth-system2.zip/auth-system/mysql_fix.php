<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MySQL Troubleshooter</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
            max-width: 1000px;
            margin: 0 auto;
        }
        h1, h2, h3 {
            color: #004A87;
        }
        .step {
            background-color: #f8f9fa;
            border-left: 4px solid #004A87;
            padding: 15px;
            margin-bottom: 20px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
            padding: 15px;
            margin-bottom: 15px;
        }
        .warning {
            background-color: #fff3cd;
            color: #856404;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin-bottom: 15px;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
            padding: 15px;
            margin-bottom: 15px;
        }
        code {
            background-color: #f8f9fa;
            padding: 2px 4px;
            border-radius: 4px;
        }
        .btn {
            display: inline-block;
            padding: 8px 16px;
            background-color: #004A87;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 15px;
        }
        img {
            max-width: 100%;
            height: auto;
            border: 1px solid #ddd;
            margin: 15px 0;
        }
    </style>
</head>
<body>
    <h1>MySQL Connection Troubleshooter</h1>';

echo '<div class="step">
    <h2>Step 1: Checking XAMPP MySQL Status</h2>';

// Define possible paths to XAMPP control executable
$xamppControlPaths = [
    'C:\\xampp\\xampp-control.exe',
    'C:\\Program Files\\xampp\\xampp-control.exe',
    'C:\\Program Files (x86)\\xampp\\xampp-control.exe'
];

$xamppControlFound = false;
foreach ($xamppControlPaths as $path) {
    if (file_exists($path)) {
        echo "<p>✅ Found XAMPP Control Panel at: <code>$path</code></p>";
        $xamppControlFound = true;
        break;
    }
}

if (!$xamppControlFound) {
    echo '<p>❌ Could not locate XAMPP Control Panel executable automatically.</p>';
}

echo '<h3>How to start MySQL:</h3>
    <ol>
        <li>Open XAMPP Control Panel</li>
        <li>Click the "Start" button next to MySQL</li>
        <li>Wait until the status turns green</li>
        <li>If it fails to start, check the logs</li>
    </ol>
    
    <img src="https://www.apachefriends.org/images/xampp-control-panel.jpg" alt="XAMPP Control Panel Example">
</div>';

echo '<div class="step">
    <h2>Step 2: Checking MySQL Connection</h2>';

// Try to connect to MySQL
$host = 'localhost';
$username = 'root';
$password = '';
$port = 3306;

echo "<p>Attempting to connect to MySQL at <code>$host:$port</code> with username <code>$username</code>...</p>";

// First, check if we can connect to the port
$connection = @fsockopen($host, $port, $errno, $errstr, 5);
if (!$connection) {
    echo "<div class='error'>
        <h3>❌ Connection Failed</h3>
        <p>Could not connect to MySQL server: $errstr ($errno)</p>
        <p><strong>The MySQL server is not running or not accessible.</strong></p>
        
        <h4>Common issues:</h4>
        <ol>
            <li>MySQL service is not started in XAMPP</li>
            <li>Another program is using port 3306</li>
            <li>MySQL service is crashing on startup</li>
        </ol>
        
        <h4>Solutions:</h4>
        <ol>
            <li>Start MySQL from XAMPP Control Panel</li>
            <li>Check MySQL error logs at: <code>C:\\xampp\\mysql\\data\\mysql_error.log</code> or <code>C:\\xampp\\mysql\\data\\[your-computer-name].err</code></li>
            <li>If MySQL won't start, try the repair options below</li>
        </ol>
    </div>";
} else {
    echo "<div class='success'><p>✅ Successfully connected to port 3306! MySQL server appears to be running.</p></div>";
    fclose($connection);
    
    // Now try a real MySQL connection
    try {
        $dbh = new PDO("mysql:host=$host;port=$port", $username, $password);
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "<div class='success'>
            <p>✅ Successfully authenticated with MySQL server!</p>
            <p>MySQL version: " . $dbh->getAttribute(PDO::ATTR_SERVER_VERSION) . "</p>
        </div>";
    } catch (PDOException $e) {
        echo "<div class='error'>
            <h3>❌ MySQL Authentication Failed</h3>
            <p>" . $e->getMessage() . "</p>
            
            <h4>Common issues:</h4>
            <ol>
                <li>Incorrect username or password</li>
                <li>MySQL user restrictions</li>
            </ol>
            
            <h4>Solutions:</h4>
            <ol>
                <li>Verify your credentials in db.php (standard XAMPP: username='root', password='')</li>
                <li>Reset MySQL root password (see instructions below)</li>
            </ol>
        </div>";
    }
}

echo '</div>';

echo '<div class="step">
    <h2>Step 3: MySQL Repair Options</h2>
    
    <h3>Option 1: Restart MySQL service</h3>
    <ol>
        <li>Open XAMPP Control Panel</li>
        <li>Click "Stop" next to MySQL if it\'s running</li>
        <li>Wait a moment, then click "Start"</li>
    </ol>
    
    <h3>Option 2: Check port conflicts</h3>
    <p>If another service is using port 3306, MySQL won\'t be able to start.</p>
    <ol>
        <li>Open Command Prompt as Administrator</li>
        <li>Run: <code>netstat -ano | findstr :3306</code></li>
        <li>If you see results, another program is using port 3306</li>
        <li>You can change MySQL\'s port in <code>C:\\xampp\\mysql\\bin\\my.ini</code> (look for "port=")</li>
    </ol>
    
    <h3>Option 3: Reset MySQL</h3>
    <p><strong>Warning: This can lead to data loss if not done carefully!</strong></p>
    <ol>
        <li>Stop all XAMPP services</li>
        <li>Backup your databases from <code>C:\\xampp\\mysql\\data\\</code></li>
        <li>Open XAMPP Control Panel and click on "Config" next to MySQL</li>
        <li>Select "my.ini" to edit the configuration file</li>
        <li>Look for "skip-grant-tables" line - if it exists, make sure it\'s uncommented</li>
        <li>If it doesn\'t exist, add <code>skip-grant-tables</code> under the [mysqld] section</li>
        <li>Save the file and try starting MySQL again</li>
    </ol>
    
    <h3>Option 4: Reinstall XAMPP (last resort)</h3>
    <ol>
        <li>Backup your website files and databases</li>
        <li>Uninstall XAMPP completely</li>
        <li>Download a fresh copy from <a href="https://www.apachefriends.org/download.html" target="_blank">https://www.apachefriends.org/download.html</a></li>
        <li>Install the new version</li>
        <li>Restore your website files and import your databases</li>
    </ol>
</div>';

echo '<div class="step">
    <h2>Step 4: phpMyAdmin Specific Fixes</h2>
    
    <p>If MySQL is running but phpMyAdmin still shows connection errors:</p>
    
    <h3>Check phpMyAdmin configuration</h3>
    <ol>
        <li>Open <code>C:\\xampp\\phpMyAdmin\\config.inc.php</code></li>
        <li>Look for the following lines and make sure they match your MySQL configuration:
<pre>
/* Authentication type */
$cfg[\'Servers\'][$i][\'auth_type\'] = \'cookie\';
/* Server parameters */
$cfg[\'Servers\'][$i][\'host\'] = \'localhost\';
$cfg[\'Servers\'][$i][\'compress\'] = false;
$cfg[\'Servers\'][$i][\'AllowNoPassword\'] = true;
</pre></li>
        <li>Save the file and try accessing phpMyAdmin again</li>
    </ol>
</div>';

echo '<div class="step">
    <h2>Need Further Help?</h2>
    <p>If you\'ve tried all the steps above and still can\'t connect to MySQL:</p>
    <ol>
        <li>Check detailed MySQL logs in <code>C:\\xampp\\mysql\\data\\</code></li>
        <li>Try using a different MySQL client like MySQL Workbench</li>
        <li>Consider posting on the <a href="https://community.apachefriends.org/" target="_blank">XAMPP forums</a> with your error messages</li>
    </ol>
    
    <a href="user-management.php" class="btn">Return to User Management</a>
</div>';

echo '</body></html>';
?>
