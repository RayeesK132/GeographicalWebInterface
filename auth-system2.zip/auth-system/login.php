<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require 'db.php';

// Initialize variables
$error = '';
$username = isset($_GET['username']) ? $_GET['username'] : '';
$auto_login = isset($_GET['auto']) && $_GET['auto'] == 1;

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Validate input
    if (empty($username) || empty($password)) {
        $error = "Please enter both username and password";
    } else {
        try {
            // Prepare statement to prevent SQL injection
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            
            // Check if user exists and password is valid
            if ($user && password_verify($password, $user['password'])) {
                // Check if user is active
                if ($user['active'] == 1) {
                    // Check if user is approved (handle case where column doesn't exist)
                    $isApproved = true;
                    if (isset($user['approved'])) {
                        $isApproved = $user['approved'] == 1;
                    }
                    
                    if ($isApproved) {
                        // Set session variables
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['username'] = $user['username'];
                        $_SESSION['role'] = $user['role'];
                        
                        // Update last login time if column exists
                        try {
                            $stmt = $pdo->prepare("SHOW COLUMNS FROM users LIKE 'last_login'");
                            $stmt->execute();
                            if ($stmt->rowCount() > 0) {
                                $updateStmt = $pdo->prepare("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?");
                                $updateStmt->execute([$user['id']]);
                            }
                        } catch (PDOException $e) {
                            // Silently fail - not critical
                        }
                        
                        // Log the login action if logs table exists
                        try {
                            $stmt = $pdo->prepare("SHOW TABLES LIKE 'logs'");
                            $stmt->execute();
                            if ($stmt->rowCount() > 0) {
                                $logStmt = $pdo->prepare("INSERT INTO logs (username, action) VALUES (?, ?)");
                                $logStmt->execute([$user['username'], 'User logged in']);
                            }
                        } catch (PDOException $e) {
                            // Silently fail - not critical
                        }
                        
                        // Redirect based on role
                        if ($user['role'] === 'admin') {
                            header('Location: admin-dashboard.php');
                        } else {
                            header('Location: dashboard.php');
                        }
                        exit();
                    } else {
                        $error = "Your account is pending approval";
                    }
                } else {
                    $error = "Your account is inactive. Please contact an administrator";
                }
            } else {
                $error = "Invalid username or password";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}

// Auto login functionality (for admin-created accounts)
if ($auto_login && !empty($username)) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if ($user) {
            // Check if user is active
            if ($user['active'] == 1) {
                // Check if user is approved (handle case where column might not exist)
                $isApproved = true;
                if (isset($user['approved'])) {
                    $isApproved = $user['approved'] == 1;
                }
                
                if ($isApproved) {
                    // Auto-login message
                    $auto_message = "This is an auto-login link. You can now set your password.";
                } else {
                    $error = "Your account requires approval before you can log in";
                }
            } else {
                $error = "This account is inactive";
            }
        } else {
            $error = "User not found";
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Bradford Council</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <?php if (function_exists('dbStatusStyles')) dbStatusStyles(); ?>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        
        .login-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 30px;
            width: 100%;
            max-width: 400px;
        }
        
        .logo {
            text-align: center;
            margin-bottom: 20px;
        }
        
        .logo img {
            max-width: 150px;
        }
        
        h1 {
            text-align: center;
            color: #004A87;
            margin-bottom: 20px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: bold;
        }
        
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .button {
            width: 100%;
            padding: 12px;
            background-color: #004A87;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }
        
        .button:hover {
            background-color: #003366;
        }
        
        .links {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
        }
        
        .links a {
            color: #004A87;
            text-decoration: none;
        }
        
        .links a:hover {
            text-decoration: underline;
        }
        
        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
            text-align: center;
        }
        
        .auto-message {
            background-color: #cce5ff;
            color: #004085;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <img src="logo.png" alt="Bradford Council Logo">
        </div>
        <h1>Login</h1>
        
        <?php if (function_exists('renderDbStatusBar')): ?>
            <?php renderDbStatusBar(); ?>
        <?php endif; ?>
        
        <?php if (isset($error) && !empty($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if (isset($auto_message)): ?>
            <div class="auto-message"><?php echo $auto_message; ?></div>
        <?php endif; ?>
        
        <form method="post" action="login.php">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <button type="submit" class="button">Login</button>
        </form>
        
        <div class="links">
            <a href="signup.php">Sign Up</a> | <a href="forgot-password.php">Forgot Password</a>
        </div>
    </div>
</body>
</html>
