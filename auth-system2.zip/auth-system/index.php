<?php
// Check if admin is already created
session_start();

// If user is already logged in, redirect to appropriate dashboard
if (isset($_SESSION['username'])) {
    if ($_SESSION['role'] === 'admin') {
        header('Location: admin-dashboard.php');
    } else {
        header('Location: dashboard.php');
    }
    exit();
}

// If user is not logged in, redirect to login page
header('Location: login.php');
exit();
?>
