<?php
session_start();
require 'db.php';
require_once 'functions.php';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Authentication required']);
    exit();
}

// Get user's role
$role = $_SESSION['role'] ?? 'user';
$username = $_SESSION['username'];

// Handle asset fetching
if (isset($_GET['action']) && $_GET['action'] === 'getAssets') {
    $professionalArea = filter_input(INPUT_GET, 'professionalArea', FILTER_SANITIZE_STRING);
    
    try {
        $query = "SELECT * FROM assets";
        $params = [];
        
        // Add professional area filter if specified
        if ($professionalArea && $professionalArea !== 'General') {
            $query .= " WHERE department = ? OR asset_type = ?";
            $params[] = $professionalArea;
            $params[] = strtolower($professionalArea);
        }
        
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'assets' => $assets]);
        exit();
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        exit();
    }
}

// Handle asset management operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);
    
    switch ($action) {
        case 'addAsset':
            addAsset();
            break;
        case 'updateAsset':
            updateAsset();
            break;
        case 'deleteAsset':
            deleteAsset();
            break;
        default:
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            exit();
    }
}

// Function to add a new asset
function addAsset() {
    global $pdo, $username;
    
    try {
        // Get and sanitize input
        $name = $_POST['name'] ?? '';
        $latitude = floatval($_POST['latitude'] ?? 0);
        $longitude = floatval($_POST['longitude'] ?? 0);
        $assetType = $_POST['asset_type'] ?? 'generic';
        $department = $_POST['department'] ?? '';
        $description = $_POST['description'] ?? '';
        
        // Validate required fields
        if (empty($name) || $latitude == 0 || $longitude == 0) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Missing required fields']);
            exit();
        }
        
        // Insert asset into database
        $stmt = $pdo->prepare("INSERT INTO assets (name, latitude, longitude, owner, asset_type, department, description) 
                             VALUES (?, ?, ?, ?, ?, ?, ?)");
        $result = $stmt->execute([$name, $latitude, $longitude, $username, $assetType, $department, $description]);
        
        if (!$result) {
            throw new Exception("Failed to insert the asset");
        }
        
        // Log the action
        $assetId = $pdo->lastInsertId();
        logAction($username, "Added new asset: $name (ID: $assetId)");
        
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true, 
            'message' => 'Asset added successfully', 
            'id' => $assetId,
            'debug' => [
                'name' => $name,
                'lat' => $latitude,
                'lng' => $longitude,
                'type' => $assetType
            ]
        ]);
        exit();
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false, 
            'message' => 'Error: ' . $e->getMessage(),
            'debug' => error_get_last()
        ]);
        exit();
    }
}

// Function to update an existing asset
function updateAsset() {
    global $pdo, $username, $role;
    
    try {
        // Get and sanitize input
        $id = intval($_POST['id'] ?? 0);
        $name = $_POST['name'] ?? '';
        $assetType = $_POST['asset_type'] ?? '';
        $department = $_POST['department'] ?? '';
        $description = $_POST['description'] ?? '';
        
        // Validate required fields
        if ($id == 0 || empty($name)) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Missing required fields']);
            exit();
        }
        
        // Check if user has permission to edit this asset
        $stmt = $pdo->prepare("SELECT owner FROM assets WHERE id = ?");
        $stmt->execute([$id]);
        $asset = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$asset) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Asset not found']);
            exit();
        }
        
        // Only allow asset owners or admins to edit
        if ($asset['owner'] !== $username && $role !== 'admin') {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'You do not have permission to edit this asset']);
            exit();
        }
        
        // Update asset in database
        $stmt = $pdo->prepare("UPDATE assets SET name = ?, asset_type = ?, department = ?, description = ? WHERE id = ?");
        $result = $stmt->execute([$name, $assetType, $department, $description, $id]);
        
        if (!$result) {
            throw new Exception("Failed to update the asset");
        }
        
        // Log the action
        logAction($username, "Updated asset ID: $id");
        
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Asset updated successfully']);
        exit();
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        exit();
    }
}

// Function to delete an asset
function deleteAsset() {
    global $pdo, $username, $role;
    
    try {
        // Get and sanitize input
        $id = intval($_POST['id'] ?? 0);
        
        // Validate required fields
        if ($id == 0) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Missing asset ID']);
            exit();
        }
        
        // Check if user has permission to delete this asset
        $stmt = $pdo->prepare("SELECT owner FROM assets WHERE id = ?");
        $stmt->execute([$id]);
        $asset = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$asset) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Asset not found']);
            exit();
        }
        
        // Only allow asset owners or admins to delete
        if ($asset['owner'] !== $username && $role !== 'admin') {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'You do not have permission to delete this asset']);
            exit();
        }
        
        // Delete asset from database
        $stmt = $pdo->prepare("DELETE FROM assets WHERE id = ?");
        $result = $stmt->execute([$id]);
        
        if (!$result) {
            throw new Exception("Failed to delete the asset");
        }
        
        // Log the action
        logAction($username, "Deleted asset ID: $id");
        
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Asset deleted successfully']);
        exit();
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        exit();
    }
}

// Helper function to log actions
function logAction($username, $action) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("INSERT INTO logs (username, action) VALUES (?, ?)");
        $stmt->execute([$username, $action]);
    } catch (PDOException $e) {
        // Silently fail - logging should not block main functionality
    }
}
?>
