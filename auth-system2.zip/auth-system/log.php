<?php
// Simple logging function for the auth system
require_once 'db.php';

function logAction($user, $action, $details = '') {
    global $pdo;
    
    try {
        // Log to database if possible
        if ($pdo) {
            // Check if logs table exists, if not create it
            $stmt = $pdo->query("SHOW TABLES LIKE 'system_logs'");
            if ($stmt->rowCount() == 0) {
                // Create logs table
                $pdo->exec("
                    CREATE TABLE system_logs (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        user VARCHAR(255),
                        action TEXT,
                        details TEXT,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ");
            }
            
            // Insert log entry
            $stmt = $pdo->prepare("INSERT INTO system_logs (user, action, details) VALUES (?, ?, ?)");
            $stmt->execute([$user, $action, $details]);
        }
    } catch (Exception $e) {
        // If database logging fails, fall back to file logging
        $log_message = date('Y-m-d H:i:s') . " - [$user] $action";
        if ($details) {
            $log_message .= " - $details";
        }
        $log_message .= "\n";
        
        // Write to log file
        $log_file = __DIR__ . '/system.log';
        file_put_contents($log_file, $log_message, FILE_APPEND | LOCK_EX);
    }
}

// Helper function to get logs from database
function getLogs($limit = 100) {
    global $pdo;
    
    try {
        if ($pdo) {
            $stmt = $pdo->prepare("SELECT * FROM system_logs ORDER BY timestamp DESC LIMIT ?");
            $stmt->execute([$limit]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (Exception $e) {
        return [];
    }
    
    return [];
}
?> 