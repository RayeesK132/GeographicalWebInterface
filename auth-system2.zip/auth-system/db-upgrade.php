<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Include database connection with improved error handling
require 'db.php';

try {
    // Test the connection with a simple query
    $testQuery = $pdo->query("SELECT 1");
    if (!$testQuery) {
        throw new PDOException("Database connection exists but failed to execute query");
    }
} catch (PDOException $e) {
    echo "<div style='padding: 20px; background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb;'>";
    echo "<h3>Database Connection Error</h3>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "<p>Please make sure the database is properly set up.</p>";
    echo "</div>";
    exit();
}

// Initialize messages arrays
$success_messages = [];
$error_messages = [];

// Function to check if a table exists
function tableExists($pdo, $table) {
    try {
        $result = $pdo->query("SELECT 1 FROM $table LIMIT 1");
        return $result !== false;
    } catch (Exception $e) {
        return false;
    }
}

// Function to check if a column exists in a table
function columnExists($pdo, $table, $column) {
    try {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM $table LIKE ?");
        $stmt->execute([$column]);
        $result = $stmt->fetch();
        return !empty($result);
    } catch (Exception $e) {
        return false;
    }
}

// Process upgrade if requested
if (isset($_POST['upgrade'])) {
    // Users table upgrades
    if (!tableExists($pdo, 'users')) {
        try {
            $pdo->exec("CREATE TABLE `users` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `username` varchar(50) NOT NULL,
                `password` varchar(255) NOT NULL,
                `email` varchar(100) NOT NULL,
                `role` varchar(20) NOT NULL DEFAULT 'user',
                `active` tinyint(1) NOT NULL DEFAULT '1',
                `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `username` (`username`),
                UNIQUE KEY `email` (`email`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
            $success_messages[] = "Created users table successfully.";
            
            // Create default admin user if table was just created
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'admin')");
            $stmt->execute(['admin', 'admin@example.com', password_hash('admin123', PASSWORD_DEFAULT)]);
            $success_messages[] = "Created default admin user (username: admin, password: admin123).";
            
        } catch (PDOException $e) {
            $error_messages[] = "Error creating users table: " . $e->getMessage();
        }
    } else {
        $success_messages[] = "Users table already exists.";
    }
    
    // Add department column to users if it doesn't exist
    if (tableExists($pdo, 'users') && !columnExists($pdo, 'users', 'department')) {
        try {
            $pdo->exec("ALTER TABLE users ADD COLUMN department VARCHAR(100) DEFAULT NULL");
            $success_messages[] = "Added department column to users table.";
        } catch (PDOException $e) {
            $error_messages[] = "Error adding department column: " . $e->getMessage();
        }
    }
    
    // Assets table upgrades
    if (!tableExists($pdo, 'assets')) {
        try {
            $pdo->exec("CREATE TABLE `assets` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `name` varchar(100) NOT NULL,
                `asset_type` varchar(50) DEFAULT 'generic',
                `description` text,
                `department` varchar(100) DEFAULT NULL,
                `latitude` decimal(10,6) DEFAULT NULL,
                `longitude` decimal(10,6) DEFAULT NULL,
                `owner` varchar(50) DEFAULT NULL,
                `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
            $success_messages[] = "Created assets table successfully.";
        } catch (PDOException $e) {
            $error_messages[] = "Error creating assets table: " . $e->getMessage();
        }
    } else {
        $success_messages[] = "Assets table already exists.";
        
        // Check and add columns for assets table
        $asset_columns = [
            'asset_type' => "ALTER TABLE assets ADD COLUMN asset_type VARCHAR(50) DEFAULT 'generic'",
            'department' => "ALTER TABLE assets ADD COLUMN department VARCHAR(100) DEFAULT NULL",
            'description' => "ALTER TABLE assets ADD COLUMN description TEXT"
        ];
        
        foreach ($asset_columns as $column => $sql) {
            if (!columnExists($pdo, 'assets', $column)) {
                try {
                    $pdo->exec($sql);
                    $success_messages[] = "Added $column column to assets table.";
                } catch (PDOException $e) {
                    $error_messages[] = "Error adding $column column: " . $e->getMessage();
                }
            }
        }
    }
    
    // Logs table upgrades
    if (!tableExists($pdo, 'logs')) {
        try {
            $pdo->exec("CREATE TABLE `logs` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `username` varchar(50) DEFAULT NULL,
                `action` varchar(255) NOT NULL,
                `ip_address` varchar(45) DEFAULT NULL,
                `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
            $success_messages[] = "Created logs table successfully.";
        } catch (PDOException $e) {
            $error_messages[] = "Error creating logs table: " . $e->getMessage();
        }
    } else {
        $success_messages[] = "Logs table already exists.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Upgrade - Bradford Council</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <?php dbStatusStyles(); ?>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        
        .container {
            max-width: 900px;
            margin: 20px auto;
            padding: 20px;
        }
        
        .panel {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .panel-header {
            background-color: #004A87;
            color: white;
            padding: 15px 20px;
            font-size: 1.2em;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .panel-body {
            padding: 20px;
        }
        
        .panel-title {
            margin: 0;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.2s;
        }
        
        .btn-primary {
            background-color: #004A87;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #003366;
        }
        
        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        
        .table-status {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .table-status th, .table-status td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .table-status th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        
        .status-icon {
            font-size: 18px;
        }
        
        .status-ok {
            color: #28a745;
        }
        
        .status-warning {
            color: #ffc107;
        }
        
        .status-error {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="panel">
            <div class="panel-header">
                <h2 class="panel-title">Database Structure Upgrade</h2>
            </div>
            
            <!-- Database Connection Status Indicator -->
            <?php renderDbStatusBar(); ?>
            
            <div class="panel-body">
                <?php if (!empty($success_messages)): ?>
                    <div class="alert alert-success">
                        <h4>Upgrade Results:</h4>
                        <ul>
                            <?php foreach ($success_messages as $message): ?>
                                <li><?php echo $message; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($error_messages)): ?>
                    <div class="alert alert-danger">
                        <h4>Errors:</h4>
                        <ul>
                            <?php foreach ($error_messages as $message): ?>
                                <li><?php echo $message; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <h3>Current Database Status</h3>
                
                <table class="table-status">
                    <thead>
                        <tr>
                            <th>Table/Feature</th>
                            <th>Status</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Users Table -->
                        <tr>
                            <td>Users Table</td>
                            <td>
                                <?php if (tableExists($pdo, 'users')): ?>
                                    <i class="fas fa-check-circle status-icon status-ok"></i>
                                <?php else: ?>
                                    <i class="fas fa-times-circle status-icon status-error"></i>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (tableExists($pdo, 'users')): ?>
                                    Table exists
                                <?php else: ?>
                                    Table needs to be created
                                <?php endif; ?>
                            </td>
                        </tr>
                        
                        <!-- Department Column -->
                        <tr>
                            <td>Department Column</td>
                            <td>
                                <?php if (tableExists($pdo, 'users') && columnExists($pdo, 'users', 'department')): ?>
                                    <i class="fas fa-check-circle status-icon status-ok"></i>
                                <?php elseif (tableExists($pdo, 'users')): ?>
                                    <i class="fas fa-exclamation-triangle status-icon status-warning"></i>
                                <?php else: ?>
                                    <i class="fas fa-times-circle status-icon status-error"></i>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (tableExists($pdo, 'users') && columnExists($pdo, 'users', 'department')): ?>
                                    Column exists
                                <?php elseif (tableExists($pdo, 'users')): ?>
                                    Column needs to be added
                                <?php else: ?>
                                    Users table required first
                                <?php endif; ?>
                            </td>
                        </tr>
                        
                        <!-- Assets Table -->
                        <tr>
                            <td>Assets Table</td>
                            <td>
                                <?php if (tableExists($pdo, 'assets')): ?>
                                    <i class="fas fa-check-circle status-icon status-ok"></i>
                                <?php else: ?>
                                    <i class="fas fa-times-circle status-icon status-error"></i>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (tableExists($pdo, 'assets')): ?>
                                    Table exists
                                <?php else: ?>
                                    Table needs to be created
                                <?php endif; ?>
                            </td>
                        </tr>
                        
                        <!-- Asset Type Column -->
                        <tr>
                            <td>Asset Type Column</td>
                            <td>
                                <?php if (tableExists($pdo, 'assets') && columnExists($pdo, 'assets', 'asset_type')): ?>
                                    <i class="fas fa-check-circle status-icon status-ok"></i>
                                <?php elseif (tableExists($pdo, 'assets')): ?>
                                    <i class="fas fa-exclamation-triangle status-icon status-warning"></i>
                                <?php else: ?>
                                    <i class="fas fa-times-circle status-icon status-error"></i>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (tableExists($pdo, 'assets') && columnExists($pdo, 'assets', 'asset_type')): ?>
                                    Column exists
                                <?php elseif (tableExists($pdo, 'assets')): ?>
                                    Column needs to be added
                                <?php else: ?>
                                    Assets table required first
                                <?php endif; ?>
                            </td>
                        </tr>
                        
                        <!-- Logs Table -->
                        <tr>
                            <td>Logs Table</td>
                            <td>
                                <?php if (tableExists($pdo, 'logs')): ?>
                                    <i class="fas fa-check-circle status-icon status-ok"></i>
                                <?php else: ?>
                                    <i class="fas fa-times-circle status-icon status-error"></i>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (tableExists($pdo, 'logs')): ?>
                                    Table exists
                                <?php else: ?>
                                    Table needs to be created
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
                
                <form method="post" style="margin-top: 20px;">
                    <input type="hidden" name="upgrade" value="1">
                    <div style="text-align: center;">
                        <button type="submit" class="btn btn-primary">Run Database Upgrade</button>
                        <a href="user-management.php" class="btn btn-secondary" style="margin-left: 10px;">Back to User Management</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
